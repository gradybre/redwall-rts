extends Node
## Routes system signals into the active HUD, and player actions out through the command queue.
##
## This is the one place signals drive behaviour: every connection made here ends at a HUD
## control. Game logic calls systems directly instead, and every ECONOMIC player action leaves
## through `ui_command_bridge.gd` as an ARCH-CMD-001 command -- never as a store write.
##
## ---------------------------------------------------------------------------------------
## THE WORLD OPENS PAUSED, AND STAYS PAUSED UNTIL THE PLAYER RESUMES. UI-SET-103: "Generation
## succeeds into paused world inspection with PLAYER pause; the first Resume starts tick
## advancement." `start_game()` leaves the clock running at 1x, because it is the clock's owner
## and knows nothing about inspection; so the FIRST transition into PLAYING re-holds the PLAYER
## reason here, once, and `_player_has_resumed` records that the player has taken over. After
## that this file never pauses the world again -- a second automatic pause would fight the
## player for the pause button.
##
## The pause is applied through `GameManager`, which owns the clock. Nothing here writes a tick,
## a speed or a pause bit itself. ARCH-CMD-002's scheduler event queue is task 04.1's and does
## not exist yet, so this uses the existing IMMEDIATE pause and speed setters and says so.
##
## ---------------------------------------------------------------------------------------
## THE TIME SOURCE IS INJECTABLE, AND THE AUTOLOAD IS THE DEFAULT. A suite that had to pause the
## real `GameManager` autoload to test the paused-start rule would leave the whole runner in a
## state the next suite inherits. `bind_time_source()` lets a test drive its own clock owner;
## production passes nothing and gets the singleton.

const HudScript := preload("res://scripts/ui/hud.gd")
const GameManagerScript := preload("res://scripts/systems/game_manager.gd")
const UiCommandBridge := preload("res://scripts/ui/ui_command_bridge.gd")
const UiWorldSession := preload("res://scripts/ui/ui_world_session.gd")
const UiShell := preload("res://scripts/ui/ui_shell.gd")
const UiNotices := preload("res://scripts/ui/ui_notices.gd")
const WorldInitScript := preload("res://scripts/core/world_init.gd")
const IntMath := preload("res://scripts/core/int_math.gd")
const ResidentsScript := preload("res://scripts/core/residents.gd")
const StarterColonyScript := preload("res://scripts/core/starter_colony.gd")
const NeedsScript := preload("res://scripts/core/needs.gd")
const UiResidentCard := preload("res://scripts/ui/ui_resident_card.gd")
const EntityDirectoryScript := preload("res://scripts/core/entity_directory.gd")


## GameManager's PLAYING state, restated so the paused-start rule does not depend on an import
## order. `GameManagerScript.GameState.PLAYING` is the same value; this is the readable form.
const STATE_PLAYING: int = 1

const REFUSE_NONE: StringName = &""
const REFUSE_NO_TIME_SOURCE: StringName = &"UI_NO_TIME_SOURCE"
const REFUSE_NOT_STARTED: StringName = &"UI_CLOCK_NOT_STARTED"
const REFUSE_NO_SETTLEMENT: StringName = &"UI_NO_SETTLEMENT"

## UI-SET-103, the New Settlement modal whose Create action this router performs.
const NEW_SETTLEMENT_ID: int = 103
## UI-SET-031's roster command and UI-SET-006's population counter, which both open the roster.
const ROSTER_ID: int = 31
const POPULATION_ID: int = 6
## GDD §4.3's FORAGING skill index, the one this milestone's detail row reports.
const FORAGING_SKILL: int = 0

## The source every notice about world generation names, so the expanded view can say WHERE the
## condition came from. These are the names of the modules that actually raise them.
const GENERATION_SOURCE: String = "UI-SET-103 New settlement"
const STOCK_SOURCE: String = "Settlement stores"
const CLOCK_SOURCE: String = "Simulation clock"
const ROSTER_SOURCE: String = "UI-SET-069 Resident roster"
const COMMAND_SOURCE: String = "Command queue"
## The recovery §4 gives UI-SET-085's "recovery action" column for the conditions whose owner
## publishes one. A condition with no published recovery gets none; `ui_notices.gd` states the
## absence rather than inventing an instruction.
const GENERATION_RECOVERY: String = "Use New settlement again to generate a world."
const CLOCK_RECOVERY: String = "Lower the game speed, or let the simulation catch up."

## The validation codes these conditions group on under §7's repeat rule. Each names the
## condition, not the message, so a changed sentence does not split one condition into two rows.
const STOCK_EMPTY_CODE: String = "ECONOMY_STOCK_EMPTY"
const CLOCK_OVERLOAD_CODE: String = "CLOCK_OVERLOADED"
const NO_WORLD_CODE: String = "UI_NO_WORLD_GENERATED"
const ROSTER_STALE_CODE: String = "UI_ROSTER_ROW_IS_STALE"
## The row's directory slot is live again, but holds a DIFFERENT entity than the row named.
## This is the condition a bare-slot roster could not see: `is_alive(slot)` is true and the
## panel would have opened on the replacement. ARCH-UI-002 makes it a refusal instead.
const ROSTER_REUSED_CODE: String = "UI_ROSTER_SLOT_REUSED"
## The reference still validates, but the persistent id at that slot is not the one the row
## cached -- the directory columns were replaced under the open roster.
const ROSTER_IDENTITY_CODE: String = "UI_ROSTER_IDENTITY_CHANGED"
## A living resident whose row this store would not publish a persistent id for.
const REFUSE_ROSTER_IDENTITY: StringName = &"UI_ROSTER_NO_IDENTITY"
## What an unbound roster row holds where a persistent id would be. Never a real id:
## `entity_directory.gd` issues from 1, and answers 0 for a stale reference.
const NO_PERSISTENT_ID: int = 0

var _hud: HudScript = null
var _time_source: GameManagerScript = null
var _bridge: UiCommandBridge = UiCommandBridge.new()
var _session: UiWorldSession = UiWorldSession.new()
## True once the player has resumed the world themselves. The opening pause is applied once.
var _player_has_resumed: bool = false
var _opening_pause_applied: bool = false
var _last_refusal: StringName = REFUSE_NONE
## What each roster row IS, as three packed columns of the same length, indexed by row.
##
## ARCH-UI-002: "View commands use generation-validated persistent identity, never render
## instance slots." A bare slot column cannot honour that. A slot alone survives its resident:
## when the directory reallocates it, `is_alive(slot)` is true again and a click on the OLD row
## opens the NEW resident -- B's needs, health and name under A's heading, with no refusal. So
## each row carries the full DIRECTORY `EntityRef` (`entity_directory.gd`'s `_generation` on the
## directory slot -- not inventory's container or lot spaces, and not navigation's route space)
## AND the never-reused persistent id, and a click validates both before resolving anything.
##
## Allocated once at `UiShell.ROSTER_POOL` and never resized; `refresh_roster()` overwrites.
var _roster_ref_slot: PackedInt32Array = PackedInt32Array()
var _roster_ref_generation: PackedInt32Array = PackedInt32Array()
var _roster_persistent_id: PackedInt32Array = PackedInt32Array()
## How many of those rows are bound. The rest hold the null ref `(-1, 0)` and no id.
var _roster_count: int = 0
## UI-SET-036's composer. Built once: its five need rows are reused on every selection.
var _card: UiResidentCard = UiResidentCard.new()


func _init() -> void:
	"""Allocate the roster identity columns once, at construction.

	NOT in `_ready()`: this router is built off-tree by its suite and by `hud.tscn`'s loader
	alike, and a column that only exists once the node entered the tree would be empty for the
	first. Three `resize()` calls happen here and nowhere else -- never inside a refresh.
	"""
	_roster_ref_slot.resize(UiShell.ROSTER_POOL)
	_roster_ref_generation.resize(UiShell.ROSTER_POOL)
	_roster_persistent_id.resize(UiShell.ROSTER_POOL)
	_clear_roster_identity()


func _ready() -> void:
	"""Stay alive through pauses, connect system signals, and report readiness."""
	process_mode = Node.PROCESS_MODE_ALWAYS
	EconomySystem.stocks_changed.connect(_on_stocks_changed)
	EconomySystem.stock_depleted.connect(_on_stock_depleted)
	GameManager.state_changed.connect(_on_state_changed)
	GameManager.speed_changed.connect(_on_speed_changed)
	GameManager.day_advanced.connect(_on_day_advanced)
	GameManager.clock_diagnostic.connect(_on_clock_diagnostic)
	_bind_settlement()
	print("[UIManager] ready")


func _bind_settlement() -> void:
	"""Point the command bridge at the running settlement's ARCH-CMD-001 queue.

	Every zone, policy, cancellation and naming action the interface offers is submitted to that
	one queue, so a UI action and a replayed command travel the same path.
	"""
	if SettlementSystem == null:
		return
	_bridge.bind_queue(SettlementSystem.commands())


func register_hud(hud: HudScript) -> void:
	"""Bind the active HUD, give its shell the bridge and session, and push current state in."""
	if hud == null:
		push_error("UIManager.register_hud() was given null; the HUD will not update.")
		return
	_hud = hud
	var shell: UiShell = hud.shell()
	if shell != null:
		_bind_shell(shell)
	_refresh_hud()


func _bind_shell(shell: UiShell) -> void:
	"""Give the shell everything it may hold, and listen for the actions it cannot perform.

	The shell gets the command bridge, the New Settlement session and the ARCH-SYS-023 snapshot.
	It does NOT get a store: generation and selection need stores, so the shell asks for them by
	signal and this router, which owns the settlement reference, does the work.
	"""
	shell.bind_bridge(_bridge)
	shell.bind_session(_session)
	if SettlementSystem != null:
		shell.bind_presentation(SettlementSystem.presentation())
	if not shell.shell_action.is_connected(_on_shell_action):
		shell.shell_action.connect(_on_shell_action)
	if not shell.tile_picked.is_connected(_on_tile_picked):
		shell.tile_picked.connect(_on_tile_picked)
	if not shell.resident_row_picked.is_connected(_on_resident_row_picked):
		shell.resident_row_picked.connect(_on_resident_row_picked)


func _on_shell_action(element_id: int) -> void:
	"""Perform the one shell action that needs the settlement's stores: New Settlement."""
	if element_id == NEW_SETTLEMENT_ID:
		create_world()
		return
	if element_id == ROSTER_ID or element_id == POPULATION_ID:
		refresh_roster()


func create_world() -> bool:
	"""UI-SET-103's Create: discard the current settlement and create §5.1's world AND cohort.

	THE COHORT AND THEN ITS WORLD, in that order (R-INIT-ID-001). This generated the world and no residents,
	so pressing Create emptied the settlement it had just made and the HUD read
	"Residents 0" against a fully generated map. Decision 0071 fixed boot; the UI kept the
	poorer path.

	The session still generates, because it owns the published map, the attempt report and
	the generator's own refusal codes -- calling `create_generated_settlement()` instead
	bypassed all three and broke two tests that had every right to fail. The cohort is
	spawned after it, and a cohort refusal fails the WHOLE action rather than leaving a
	generated map with nobody on it.

	The reset is the PLAYER'S OWN DISCARD and happens first, because `world_init.gd` refuses to
	publish over live rows it does not own -- a settlement's residents are exactly that. One
	consequence is stated rather than hidden: if generation then refuses, the previous world is
	already gone and the settlement is left EMPTY, not restored. The refusal says so.
	"""
	if SettlementSystem == null:
		return _refuse(REFUSE_NO_SETTLEMENT)
	var report: UiWorldSession.Report = _session.last_report()
	var ok: bool = _session.create_with_cohort_into(SettlementSystem.directory(),
		SettlementSystem.ecology().resource_nodes(), SettlementSystem.ecology().forage(),
		SettlementSystem.ecology().fishing(), SettlementSystem.rng(),
		SettlementSystem.crop_weather().farming(), SettlementSystem.ecology().orchard_hive(),
		SettlementSystem.jobs(), SettlementSystem.commands(), report,
		SettlementSystem.reset, SettlementSystem.create_placed_cohort_on)
	if not ok and report.error == UiWorldSession.REFUSE_COHORT:
		report.error = SettlementSystem.last_refusal()
	ok = _materialize_after_create(ok, report)
	_reconcile_economy_after_create(ok)
	_report_generation(ok, report)
	if ok:
		refresh_roster()
	return ok


func _materialize_after_create(ok: bool, report: UiWorldSession.Report) -> bool:
	"""Decision 0533: Create's colony step. A refusal empties the settlement, as boot's does.

	The session has published a world and its cohort by now. A world without its colony is not a
	§5.1 settlement, so a refused colony fails the whole action: the settlement is reset to
	empty -- what boot's `_abandon_transaction()` leaves -- and the session forgets the map it
	published, so no panel reads a world whose rows the reset destroyed.
	"""
	if not ok:
		return false
	if SettlementSystem.adopt_generated_world(_session.world()) \
			and SettlementSystem.materialize_starter_colony():
		return true
	var code: StringName = SettlementSystem.last_refusal()
	SettlementSystem.reset()
	return _session.refuse_published_world(report, code,
		"the world was generated but its starter colony could not be placed.")


func _reconcile_economy_after_create(ok: bool) -> void:
	"""Rebind EconomySystem to the new colony, or drop stores whose owners Create destroyed.

	Runs BEFORE the HUD repaint in `_report_generation()`, so the first figures the player sees
	after Create are the new settlement's. A refused Create that never reached the session's reset
	keeps the running settlement and its stores; one that did reset leaves stores owned by rows
	that no longer exist, and #7 says stale ownership is rejected, so they are closed. The stores
	reopen in the settlement's own inventory, which EconomySystem adopts first (decision 0534).
	"""
	if EconomySystem == null:
		return
	if ok:
		EconomySystem.reset()
		var binding: StarterColonyScript.StoreBinding = StarterColonyScript.StoreBinding.new()
		if not SettlementSystem.starter_store_binding_into(binding) \
				or not EconomySystem.bind_inventory(SettlementSystem.inventory()) \
				or not EconomySystem.open_and_seed_starter_stores(binding):
			push_error("Create: the starter stores could not open: %s / %s"
				% [SettlementSystem.last_refusal(), EconomySystem.last_refusal()])
		EconomySystem.bind_residents(SettlementSystem.residents())
	elif not _economy_owners_live():
		EconomySystem.reset()


func _economy_owners_live() -> bool:
	"""True when EconomySystem has no store, or its pantry's owner is a live Building here."""
	if not EconomySystem.stores_open():
		return true
	var owner_ref: Vector2i = EconomySystem.inventory().container_owner(EconomySystem.pantry())
	return SettlementSystem.directory().is_valid_of_kind(owner_ref,
		EntityDirectoryScript.KIND_BUILDING)


func _report_generation(ok: bool, report: UiWorldSession.Report) -> void:
	"""Put the generator's own counts, or its own refusal code, in front of the player.

	R-UI-ALERT-001 names this condition in terms: severity `Error`, compact title "Generation
	failed", "the exact detailed reason, validation code and recovery stay in the notice
	record". The sentence below is the generator's own and is passed through unaltered; the
	code is the generator's own `report.error`. Nothing here shortens either.
	"""
	if not _has_hud():
		return
	var shell: UiShell = _hud.shell()
	if ok:
		## MERGE, 2026-09-11: the sentence is R-INIT-ID-001's, which added the cohort count;
		## the routing is R-UI-ALERT-001's, which gives the notice its authored category. The
		## sentence itself is passed through unaltered, exactly as it was before.
		shell.raise_notice(UiNotices.CATEGORY_SETTLEMENT_CREATED,
			"Settlement generated: %d resource nodes, %d basins, %d fish stocks, %d residents, seed %d."
			% [report.resource_nodes, report.basins, report.fish_stocks,
				SettlementSystem.population(), report.accepted_seed],
			GENERATION_SOURCE, "", "")
		shell.set_refusal_display("")
	else:
		_report_generation_failure(shell, report)
	_refresh_hud()


func _report_generation_failure(shell: UiShell, report: UiWorldSession.Report) -> void:
	"""Raise the generation refusal as an Error notice AND fill UI-SET-085's error panel.

	Both, not one: §4 gives UI-SET-085 "Error code+plain reason+recovery action" for a fault,
	and the ruling gives the alert card an authored summary that discloses the same record. The
	message is written once and used by both, so the two displays cannot drift apart.
	"""
	var message: String = "Generation refused (%s): %s The settlement is now empty." \
		% [report.error, report.detail]
	shell.raise_notice(UiNotices.CATEGORY_GENERATION_FAILED, message, GENERATION_SOURCE,
		String(report.error), GENERATION_RECOVERY)
	shell.set_refusal_display(message)


func refresh_roster() -> bool:
	"""Fill UI-SET-069's rows from the living residents, or report that there are none.

	§4 binds a resident row to "Name/anonymous label+species+role+mood+health+current job". Four
	of those six have a store today; role and current job do not, and are left out rather than
	filled with a plausible word. Each row records the resident's generation-checked reference
	AND persistent id, because REQ-UX-013 and ARCH-UI-002 require resolving persistent identity
	rather than a render index -- or, as this file used to, a bare reusable slot.
	"""
	if not _has_hud() or SettlementSystem == null:
		return _refuse(REFUSE_NO_SETTLEMENT)
	var residents: ResidentsScript = SettlementSystem.residents()
	var needs: NeedsScript = SettlementSystem.needs()
	_clear_roster_identity()
	var labels: PackedStringArray = PackedStringArray()
	for slot: int in ResidentsScript.RESIDENT_CAPACITY:
		if _roster_count >= UiShell.ROSTER_POOL:
			break
		if not residents.is_alive(slot):
			continue
		if not _bind_roster_row(_roster_count, residents, slot):
			_clear_roster_identity()
			return _refuse(REFUSE_ROSTER_IDENTITY)
		labels.append(_roster_label(residents, needs, slot))
		_roster_count += 1
	_hud.shell().set_roster(labels, residents.living_count())
	_last_refusal = REFUSE_NONE
	return true


func _clear_roster_identity() -> void:
	"""Return every row to the null reference `(-1, 0)` and no persistent id, without resizing.

	`(-1, 0)` is GDD §4.1's own null reference and validates like any other -- as false. An
	unbound row therefore refuses a click by the same path a stale one does, with no separate
	"is this row real" flag that could disagree with the columns beside it.
	"""
	_roster_ref_slot.fill(EntityDirectoryScript.NULL_SLOT)
	_roster_ref_generation.fill(EntityDirectoryScript.NULL_GENERATION)
	_roster_persistent_id.fill(NO_PERSISTENT_ID)
	_roster_count = 0


func _bind_roster_row(row_index: int, residents: ResidentsScript, slot: int) -> bool:
	"""Cache one row's `(slot, generation)` reference and its persistent id. Refuses; never guesses.

	Both come from the stores, neither is derived from the other, and a row is bound only when
	both arrive. A living resident the store will not publish a persistent id for leaves the row
	unbound and fails the whole refresh -- writing `NO_PERSISTENT_ID` into a bound row would be a
	sentinel that later compares equal to a stale reference's answer of 0.
	"""
	var ref: Vector2i = residents.ref_of(slot)
	if ref == EntityDirectoryScript.NULL_REF:
		return false
	var persistent: IntMath.IntResult = residents.persistent_id_of(slot)
	if not persistent.ok or persistent.value <= NO_PERSISTENT_ID:
		return false
	_roster_ref_slot[row_index] = ref.x
	_roster_ref_generation[row_index] = ref.y
	_roster_persistent_id[row_index] = persistent.value
	return true


func _roster_label(residents: ResidentsScript, needs: NeedsScript, slot: int) -> String:
	"""One row's visible text: the facts a store actually publishes for that resident.

	UXV-024's "identity line and secondary status": the name leads, then species and health.

	Health is formatted by `ui_resident_card.gd` and NOT by a second copy of the same rule here.
	That matters for one reason: the card's version distinguishes a refused read from a real
	zero, and a duplicate of it in this file would be an unreachable branch nothing could test
	-- `refresh_roster()` only calls this for a slot it has already found alive.
	"""
	return "%s  %s  %s" % [UiResidentCard.heading_text(residents, slot),
		UiResidentCard.species_text(residents, slot),
		UiResidentCard.health_text(needs, slot)]


func _on_resident_row_picked(row_index: int) -> void:
	"""Open UI-SET-036 on the resident that row IS, validated through the directory first.

	The order matters and is the whole fix: the cached reference is validated BEFORE any row is
	resolved, so a reallocated slot can never be read at all. A row that fails validation
	refuses in the open and selects nothing; it does not fall through to a blank panel, and it
	does not quietly show whoever holds that slot now.
	"""
	if not _has_hud() or row_index < 0 or row_index >= _roster_count:
		return
	var residents: ResidentsScript = SettlementSystem.residents()
	var ref: Vector2i = Vector2i(_roster_ref_slot[row_index], _roster_ref_generation[row_index])
	var identity: StringName = _roster_identity_refusal(residents, row_index, ref)
	if identity != REFUSE_NONE:
		_report_stale_row(row_index, identity)
		return
	var resolved: IntMath.IntResult = residents.slot_of_ref(ref)
	if not resolved.ok:
		_report_stale_row(row_index, StringName(resolved.error))
		return
	if not residents.is_alive(resolved.value):
		_report_stale_row(row_index, StringName(ROSTER_STALE_CODE))
		return
	_show_resident_detail(residents, SettlementSystem.needs(), ref, resolved.value)


func _roster_identity_refusal(residents: ResidentsScript, row_index: int,
		ref: Vector2i) -> StringName:
	"""Why row `row_index` no longer names the resident it was built for, or REFUSE_NONE.

	Two independent guards, and neither subsumes the other. The generation rejects a reference
	whose slot was destroyed OR handed to a different entity -- `ref_of_slot()` separates those
	two so the notice can say which happened instead of calling both "stale". The persistent id
	then rejects a slot that still validates but no longer belongs to the same individual, which
	is what a restored set of directory columns leaves behind under an already open roster.
	"""
	var directory: EntityDirectoryScript = residents.directory()
	if not directory.is_valid_of_kind(ref, EntityDirectoryScript.KIND_RESIDENT):
		if directory.ref_of_slot(ref.x) == EntityDirectoryScript.NULL_REF:
			return StringName(ROSTER_STALE_CODE)
		return StringName(ROSTER_REUSED_CODE)
	if directory.get_persistent_id(ref) != _roster_persistent_id[row_index]:
		return StringName(ROSTER_IDENTITY_CODE)
	return REFUSE_NONE


func _report_stale_row(row_index: int, code: StringName) -> void:
	"""Refuse the click in the open: an Error notice naming the row, and the retained code.

	UI-SET-085 wants the exact code, the plain reason and a recovery action. The sentence is
	deliberate about what did NOT happen -- "nothing was selected" -- because the defect this
	replaces was silent, and a player who saw the panel change would have had no way to know the
	row had gone stale underneath them.
	"""
	_hud.shell().raise_notice(UiNotices.CATEGORY_ROSTER_STALE,
		"That roster row no longer names the resident it was built for; nothing was selected.",
		"%s row %d" % [ROSTER_SOURCE, row_index], String(code),
		"Open the roster again to rebuild its rows.")
	_refuse(code)


func _show_resident_detail(residents: ResidentsScript, needs: NeedsScript, ref: Vector2i,
		slot: int) -> void:
	"""Fill UI-SET-036 in UXV-019's order: identity, health, five needs, activity and skills.

	Takes BOTH the validated reference and the row it resolved to. The reference is what the
	panel selects and what the need rows are captured through; the slot is only an index into
	columns the caller has already proved belong to that reference. Nothing here revalidates,
	and nothing here re-derives the reference from the slot -- `ref_of(slot)` would answer for
	whoever holds the row now, which is the substitution this whole path exists to prevent.

	THE OLD LINE WAS `Hunger 7500 of 10000`, and it broke two requirements at once. UXV-020
	forbids exposing a basis-point figure as the player-facing value, and UXV-021 fixes the
	visible label as `Fullness` -- the store's hunger column is SATISFACTION, so a high number
	is a well-fed resident. `ui_resident_card.gd` does every conversion; nothing is derived here.
	"""
	var shell: UiShell = _hud.shell()
	shell.set_detail_display(UiResidentCard.heading_text(residents, slot),
		UiResidentCard.identity_text(residents, needs, slot),
		UiResidentCard.skill_text(residents, slot, FORAGING_SKILL))
	shell.set_detail_health(UiResidentCard.health_text(needs, slot))
	shell.set_detail_activity(UiResidentCard.activity_text(needs,
		SettlementSystem.jobs(), slot))
	_fill_need_rows(shell, residents, needs, ref)
	_fill_species_emblem(shell, residents, slot)
	shell.select_resident(ref, "")
	shell.set_detail_open(true)


func _fill_need_rows(shell: UiShell, residents: ResidentsScript, needs: NeedsScript,
		ref: Vector2i) -> bool:
	"""UXV-020's five rows: exact percent, 8 px track and per-simulated-hour change each.

	A refusal from the card leaves the rows EMPTY and raises the refusal, rather than printing
	four rows and one plausible fifth. `needs.gd` publishes an effective rate for hunger only,
	so the other four rows carry the card's explicit "Rate unavailable" -- see its header.

	NEED-RATE-R01's ref-first entry point, not the slot-keyed convenience beside it: the five
	rows are captured at one boundary from the same validated reference the panel selected, so
	the card cannot re-resolve a slot that changed hands between the click and the capture.
	"""
	if not _card.fill_needs_for(residents.directory(), residents, needs, ref):
		shell.raise_notice(UiNotices.CATEGORY_ROSTER_STALE,
			"That resident's needs could not be read (%s)." % _card.last_refusal(),
			ROSTER_SOURCE, String(_card.last_refusal()),
			"Open the roster again to rebuild its rows.")
		return _refuse(REFUSE_NO_SETTLEMENT)
	for index: int in _card.row_count():
		var row: UiResidentCard.Row = _card.row(index)
		shell.set_need_row(index, row.label, row.value_text, row.rate_text, row.basis_points,
			row.accessible)
	_last_refusal = REFUSE_NONE
	return true


func _fill_species_emblem(shell: UiShell, residents: ResidentsScript, slot: int) -> void:
	"""ART-UI-06: the generic species medallion beside the name, and the note saying what it is.

	ART-LOCK-001 delivers four medallions -- mouse, mole, otter, squirrel. A resident of any
	other species gets NO emblem and the readable species text alone; borrowing the mouse
	roundel for everyone is the failure the lock names. The note is written either way, because
	UXV-019 requires the mark to be identified as generic whenever one is shown, and the age
	statement is true of every resident.
	"""
	var species: String = UiResidentCard.species_text(residents, slot)
	var key: StringName = StringName(species)
	var path: String = UiResidentCard.emblem_path(key, shell.detail_emblem_pixels())
	if not path.is_empty():
		shell.set_detail_emblem(path, UiResidentCard.emblem_description(key))
	shell.set_detail_note("%s  %s" % [UiResidentCard.EMBLEM_NOTE,
		UiResidentCard.AGE_UNAVAILABLE])


func _on_tile_picked(tile_index: int) -> void:
	"""Resolve the picked tile against the published map and open UI-SET-036 on it."""
	if not _has_hud():
		return
	var shell: UiShell = _hud.shell()
	if not _session.has_world():
		shell.raise_notice(UiNotices.CATEGORY_NO_WORLD,
			"No world has been generated yet, so no tile can be inspected.",
			GENERATION_SOURCE, NO_WORLD_CODE, GENERATION_RECOVERY)
		return
	_select_tile(shell, tile_index)


func _select_tile(shell: UiShell, tile_index: int) -> void:
	"""Point the zone tool at the picked tile's basin and describe the tile in the detail panel."""
	var world: WorldInitScript = _session.world()
	var basin_index: IntMath.IntResult = world.basin_index_at(tile_index)
	var terrain: IntMath.IntResult = world.terrain_at(tile_index)
	var title: String = "Tile %d,%d - %s" % [WorldInitScript.tile_x_of(tile_index),
		WorldInitScript.tile_z_of(tile_index),
		WorldInitScript.TERRAIN_KEYS[terrain.value] if terrain.ok else &"unknown"]
	if not basin_index.ok or basin_index.value == WorldInitScript.NO_BASIN:
		shell.set_detail_display(title, "No ecology basin here.", "")
		shell.set_detail_open(true)
		return
	var danger: IntMath.IntResult = world.basin_danger_of(basin_index.value)
	shell.select_basin(world.basin_ref_of(basin_index.value), danger.value if danger.ok else 0)
	shell.set_detail_display(title, "Basin: %s" % WorldInitScript.BASIN_KEYS[basin_index.value],
		"Danger band %d" % (danger.value if danger.ok else 0))
	shell.set_detail_open(true)


func unregister_hud() -> void:
	"""Drop the HUD reference when its scene is leaving the tree."""
	_hud = null


func bind_time_source(source: GameManagerScript) -> void:
	"""Use an explicit clock owner instead of the autoload. Tests bind their own."""
	_time_source = source


func push_alert(text: String) -> void:
	"""Show a transient message in the top-centre alert zone."""
	if _has_hud():
		_hud.show_alert(text)


func push_refusal(code: StringName) -> void:
	"""Show an exact refusal code and its plain reading, and retain it as an Error notice.

	The error panel is UI-SET-085's job and is unchanged. The notice is what makes the refusal
	RETRIEVABLE afterwards: UI-SET-085 is cleared by the next accepted action, and a player who
	looked away should still be able to read why the last one was refused.
	"""
	if not _has_hud():
		return
	var sentence: String = _bridge.refusal_sentence(code)
	_hud.show_refusal(sentence)
	_hud.shell().raise_notice(UiNotices.CATEGORY_ACTION_REFUSED, sentence, COMMAND_SOURCE,
		String(code), "")


func _time() -> GameManagerScript:
	"""The bound clock owner, or the GameManager autoload when none was injected."""
	if _time_source != null:
		return _time_source
	return GameManager as GameManagerScript


func apply_opening_pause() -> bool:
	"""Hold UI-SET-103's PLAYER pause for the opening inspection, exactly once.

	Refuses before `start_game()`, because `pause_game()` does nothing on an unstarted clock and
	reporting success would claim an inspection pause that is not held.
	"""
	var manager: GameManagerScript = _time()
	if manager == null:
		return _refuse(REFUSE_NO_TIME_SOURCE)
	if manager.get_state() == GameManagerScript.GameState.BOOT:
		return _refuse(REFUSE_NOT_STARTED)
	manager.pause_game()
	_opening_pause_applied = true
	_last_refusal = REFUSE_NONE
	return true


func player_has_resumed() -> bool:
	"""True once the player has released the opening pause themselves."""
	return _player_has_resumed


func opening_pause_applied() -> bool:
	"""True once the opening inspection pause has been held for this world."""
	return _opening_pause_applied


func command_bridge() -> UiCommandBridge:
	"""The bridge every economic player action travels through."""
	return _bridge


func world_session() -> UiWorldSession:
	"""The UI-SET-103 New Settlement session."""
	return _session


func _has_hud() -> bool:
	"""True when a HUD is bound and has not been freed out from under us.

	A plain null check is not enough: a freed Object still compares != null.
	"""
	return _hud != null and is_instance_valid(_hud)


func _refresh_hud() -> void:
	"""Push every current value into a freshly registered HUD."""
	if not _has_hud():
		return
	_refresh_counters()
	_refresh_status()
	_refresh_world()


func _refresh_counters() -> void:
	"""Push every top-left counter this milestone can honestly derive.

	Five of the seven are supplied. `Food-days` is now among them: task 2.10 gave GDD §5.8 its
	divisor, so EconomySystem computes the figure whenever a residents store is bound and
	returns the unpopulated marker when one is not. Every value crosses this boundary EXACTLY as
	the system produced it -- the two text counters are forwarded verbatim and the three integer
	counters are forwarded unscaled, because a number invented or adjusted here would be
	indistinguishable on screen from one the simulation actually derived.

	`Fuel-days` stays unpopulated: its daily heating demand has no input in any implemented
	system (see EconomySystem.fuel_days_missing_input()). `Beds` stays unpopulated too: the
	starter colony's twelve beds now stand (decision 0533), but no UI step routes a bed figure
	here yet, and UI-SET-007 says what it waits on rather than showing a number nobody wired. `Residents` is now supplied
	from the residents store's own living count when one is bound.
	"""
	if not _has_hud():
		return
	_hud.set_counter_text(&"Food-days", EconomySystem.food_days_text())
	_hud.set_counter_text(&"Fuel-days", EconomySystem.fuel_days_text())
	_hud.set_counter(&"Ready NP", EconomySystem.ready_nutrition_points(), "NP")
	_hud.set_counter(&"Wood", EconomySystem.stock_units(&"wood"), "U")
	_hud.set_counter(&"Stone", EconomySystem.stock_units(&"stone"), "U")
	_refresh_population()


func _refresh_population() -> void:
	"""Push UI-SET-006's living count, or leave it unpopulated when no cohort is bound.

	A generated world has terrain, trees, ore and fish and NOBODY LIVING IN IT: task 06 owns the
	resident fixture. Zero residents is the truth in that world and is printed as zero; an
	ABSENT residents store is a different statement and stays unpopulated.
	"""
	if not EconomySystem.has_residents():
		_hud.set_counter_text(&"Residents", HudScript.UNPOPULATED)
		return
	# UI-C3-R01 §2: living population renders as "N / 256", not a bare count. The cap is read
	# from the residents store rather than written as a literal, so a GDD §4.1 change moves it
	# here without a second edit. hud.gd renders byte for byte by contract, so the unit has to
	# arrive from the owner that knows it -- adding it there would make the renderer derive.
	var living: int = EconomySystem.residents().living_count()
	_hud.set_counter_text(&"Residents", "%d / %d" % [living, ResidentsScript.RESIDENT_LIVING_CAP])


func _refresh_status() -> void:
	"""Repaint the top-right state, speed and date readout, and the pause label, from the clock."""
	if not _has_hud():
		return
	var manager: GameManagerScript = _time()
	_hud.set_status(manager.get_state_name(), manager.get_speed(), manager.get_calendar_text())
	_hud.set_pause(manager.is_paused(), ", ".join(manager.get_pause_reason_names()))


func _refresh_world() -> void:
	"""Repaint UI-SET-021 with what the published map actually holds, or that none is published."""
	if not _has_hud():
		return
	var shell: UiShell = _hud.shell()
	if shell == null:
		return
	if not _session.has_world():
		shell.set_minimap_display("No world generated")
		return
	shell.set_minimap_display("%d x %d tiles, seed %d" % [WorldInitScript.MAP_TILES_X,
		WorldInitScript.MAP_TILES_Z, _session.world().published_seed().value])


func _on_stocks_changed() -> void:
	"""Repaint the top-left counters after a committed change to the stores."""
	_refresh_counters()


func _on_stock_depleted(item_key: StringName) -> void:
	"""Raise an alert when the last unit of an item leaves the stores.

	The item is named in the message and carried as the notice's SOURCE, so §7's repeat rule
	groups two depletions of the same item onto one card and two different items onto two.
	"""
	if not _has_hud():
		return
	_hud.shell().raise_notice(UiNotices.CATEGORY_STOCK_EMPTY, "Out of %s!" % item_key,
		"%s (%s)" % [STOCK_SOURCE, item_key], STOCK_EMPTY_CODE, "")


func _on_state_changed(new_state: int) -> void:
	"""Refresh the status readout, and hold UI-SET-103's opening pause the first time only."""
	_refresh_status()
	if new_state != STATE_PLAYING:
		return
	if not _opening_pause_applied:
		apply_opening_pause()
		_refresh_status()
		return
	_player_has_resumed = true


func _on_speed_changed(_speed: int) -> void:
	"""Refresh the status readout after a speed change, including an overload step-down."""
	_refresh_status()


func _on_day_advanced(_absolute_day: int) -> void:
	"""Refresh the date readout when the offset calendar crosses into a new day."""
	_refresh_status()


func _on_clock_diagnostic(message: String) -> void:
	"""Surface a scheduler overload warning or diagnostic pause, with the clock's own wording.

	`sim_clock.gd` writes the sentence, including the owed tick count, and it reaches the notice
	record byte for byte; the card shows the authored "Clock overloaded" summary instead when
	the composition has no room for the sentence.
	"""
	if not _has_hud():
		return
	_hud.shell().raise_notice(UiNotices.CATEGORY_CLOCK_OVERLOAD, message, CLOCK_SOURCE,
		CLOCK_OVERLOAD_CODE, CLOCK_RECOVERY)


func last_refusal() -> StringName:
	"""The code of the most recent refusal, or the empty StringName after a successful call."""
	return _last_refusal


func _refuse(code: StringName) -> bool:
	"""Record an explicit refusal code and return false."""
	_last_refusal = code
	return false

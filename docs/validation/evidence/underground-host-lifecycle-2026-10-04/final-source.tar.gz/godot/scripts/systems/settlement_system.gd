extends Node
## The settlement simulation loop: owner of the core stores, driven by completed fixed ticks.
##
## ARCH-MIG-006 step 6, wiring half. `scripts/core/` already holds needs, schedules, priorities,
## jobs, work, reservations and the entity directory, each tested in isolation; until now NOTHING
## IN THE RUNNING GAME CALLED THEM. This node is the production caller: it composes the stores
## once, and runs the §5 pipeline stages that have an implemented owner, once per COMPLETED
## SIMULATION TICK.
##
## ---------------------------------------------------------------------------------------
## THE CLOCK DRIVES THIS, NOT `_process`. `GameManager` folds host microseconds into
## `scripts/core/sim_clock.gd`, which drains whole ticks and calls back once per completed tick
## with that tick's index. This node has no `_process`, reads no `delta`, and cannot run a
## fraction of a tick. REQ-SET-011: a tick is a tick, so 2x and 4x run more of exactly this
## function and nothing else, and REQ-SET-004's pause freezes it for free -- a paused clock
## accumulates no debt, so `run_tick()` is simply never called, while camera, selection and UI
## keep their own frames because the scene tree is never paused.
##
## ---------------------------------------------------------------------------------------
## STAGE ORDER IS `systems_architecture.md` §5's TABLE, NOT CONVENIENCE. Of the 23 systems in
## that table, TEN are dispatched here (ARCH-SYS-008 only in part). ARCH-SYS-017 is deliberately
## NOT counted among the ten: it is not a separate call, and three earlier revisions of this
## header disagreed about whether to include it -- one said THREE while listing four, another said
## FIVE and SIX for the same milestone under different conventions, and the third ended "That is
## the sixth" after excluding 017 from a list of six, which named nothing at all. The count below
## is of DISPATCHED CALL SITES, and the list IS the count. `tick_stage_count()` publishes the EIGHT
## of them that are on the per-tick path, so the list and the code cannot drift apart silently:
##
##   ARCH-SYS-002 CommandCommit      -> `command_dispatch.commit_tick_into()` every tick, FIRST
##   ARCH-SYS-003 IntervalIntegrator -> `residents.tick_needs_all()` every tick, after commit
##   ARCH-SYS-004 StockAge           -> `stock_age.run_hour_into()` EVERY HOUR CROSSING, on the
##                                     tick path, and REQ-SET-007's FIRST daily leg at midnight
##   ARCH-SYS-005 Ecology            -> `ecology.run_day_into()`   MIDNIGHT ONLY, never per tick
##   ARCH-SYS-006 CropWeather        -> `crop_weather.run_hour_into()` EVERY HOUR CROSSING, on
##                                     the tick path, AND `run_day_into()` at MIDNIGHT after 005
##   ARCH-SYS-009 JobPlanner         -> `job_planner.run_tick_into()` every tick, AND
##                                     `run_day_boundary()` at MIDNIGHT after 006
##   ARCH-SYS-008 NeedIntent (PART)  -> `schedule.resolve_into()`  activity resolution only
##   ARCH-SYS-010 JobSelector        -> `jobs.evaluate()`/`assign_worker()`
##   ARCH-SYS-013 ProductiveWork     -> `work.tick_solo_into()` / `tick_party_into()`
##   ARCH-SYS-023 PresentationExtract-> `presentation.capture()`  every tick, LAST
##
## ARCH-SYS-001's STORE IS NOW COMPOSED, AND IT IS STILL NOT A TICK STAGE. `transforms.gd` is
## built here over THIS settlement's directory and `transforms()` publishes it; INIT-POSE-R01's
## starter placement writes §5.1's twelve poses ONCE, inside the generation transaction. There is
## no per-tick TransformSnapshot call and no second `_process` movement loop: nothing moves, so
## there is no tick-start history to roll. When ARCH-SYS-012 Movement is composed it becomes the
## SOLE per-tick writer of this same instance. `tick_stage_count()` is unchanged at EIGHT.
##
## TWO OF THOSE NINE ARE OUT OF THE TABLE'S ORDER, AND BOTH ARE SAID SO RATHER THAN GLOSSED:
##
##   * ARCH-SYS-009 RUNS BEFORE ARCH-SYS-008, not after it. The table reads 008, 009, 010; this
##     node runs 009, then a FUSED 008/010 pass in which each resident's activity is resolved
##     immediately before that resident is offered a job. The fusion is what stops eligibility
##     step 2 reading a stale hour, and the two stages have NO DATA DEPENDENCY -- the planner reads
##     FarmPlot rows and HarvestZone designations, resolution reads needs and the calendar hour.
##     What the table's order is actually FOR is satisfied exactly: R06-JOB-008 requires demand to
##     be reconciled "before selection", and it is.
##   * ARCH-SYS-017 CareHealth RUNS IN ARCH-SYS-003's SLOT, WHICH IS FOURTEEN PLACES EARLY. THIS
##     IS AN ORDERING DEBT, not a naming convenience, and it is stated here in full because the
##     previous revision left it implicit. `needs.gd` integrates health, cold exposure and the
##     incapacitation/death transitions INSIDE the needs sweep, so they are computed at position 3
##     rather than at the table's position 17. The table's own stated constraint -- "before
##     lifecycle and progression" -- still holds, because neither ARCH-SYS-019 nor ARCH-SYS-020
##     exists. WHAT IS ACTUALLY LOST is everything between the two positions: cold exposure cannot
##     see THIS tick's ARCH-SYS-016 RoomHeat result (the Room store now exists, but nothing
##     integrates heat into it), and injury care cannot see THIS tick's ARCH-SYS-013 care work
##     (no care request store). Both inputs are absent today,
##     so the debt is currently unobservable -- and it becomes a real one-tick lag the moment
##     either store lands. Repaying it means a separate CareHealth call, which is a change to
##     `needs.gd`, a file this task does not own.
##
## ARCH-SYS-006 IS ONE STAGE WITH TWO CADENCES, not two stages: its §5 row reads "Hourly crop
## integration; midnight after Ecology" and both halves belong to `crop_weather.gd`. The hourly
## half sits in the table's own position, after ARCH-SYS-003 and before the selectors; the daily
## half is REQ-SET-007's third leg and runs after ARCH-SYS-005's, never before it.
##
## ARCH-SYS-017 CareHealth is therefore not a tenth entry in the list above; it is run, not
## skipped, and the paragraph above states exactly what running it early does and does not cost.
##
## ARCH-SYS-002 IS FIRST BECAUSE §5 SAYS "after snapshot, before selectors", and ARCH-SYS-001
## TransformSnapshot is not DISPATCHED even though its store now exists: no entity moves, so
## there is no snapshot to take, and nothing precedes the commit here.
## A player edit committed at the top of tick k is therefore visible to the SAME tick's selection
## and work stages, which is what "before selectors" buys.
##
## WHAT ARCH-SYS-002 NOW DOES, AND WHAT IT STILL DOES NOT. It drains `commands.gd`'s ordered
## next-tick queue and commits each drained record through `command_dispatch.gd`. In THIS node's
## composition that now reaches ALL SEVEN implemented kinds. Four of them -- CANCEL_JOB,
## NAME_RESIDENT, SET_ACTIVITY_SCHEDULE and SET_JOB_PRIORITIES -- always did, because this node
## composes the resident-side stores, and APPOINT_WARDEN (decision 0511) reaches the same
## `residents.gd` for the same reason. DESIGNATE_ZONE and SET_POLICY refused COMMAND_STORE_NOT_BOUND
## until task 04.4, because they need `forage.gd` and `job_planner.gd`; `_bind_ecology_to_commands()`
## is the named handoff task 04.2 reserved for it and it runs during composition, so a player's
## zone and policy edits now reach real stores in the running game. The remaining seventeen
## ARCH-CMD-003 kinds refuse COMMAND_UNSUPPORTED_FEATURE and name their missing owner.
##
## ONE PLAYER COMMAND CANNOT PRODUCE TWO DESIGNATIONS. `command_dispatch.gd` records
## ARCH-CMD-001's `(player_id, sequence_high, sequence_low)` on the zone each DESIGNATE_ZONE
## creates and refuses COMMAND_DUPLICATE_INTENT for a repeat of the same identity. That guard is
## in the dispatcher rather than here, and its header records the measurement that motivated it.
##
## ARCH-CMD-002's SPEED/PAUSE SCHEDULER EVENTS NOW EXIST, IN THEIR OWN QUEUE, AND ARE NOT
## COMMITTED BY THIS STAGE. `scripts/core/scheduler_events.gd` implements R07-SCHED-001 under
## decision 0054, and it applies its events at the BOUNDARY PUMP between ticks -- not inside a
## tick, and not through `command_dispatch.gd`. That is the whole point: an economic command is
## due at `completed_tick + 1`, so routing a pause through this stage would make the unpause wait
## for the very tick the pause prevents. The pump's owner is whoever drives the host frame; this
## node drives a single simulation tick and must not pump inside one. Blocker U2 is closed in
## process; what remains open is persistence, which is task 09's save module, not this file's.
##
## EVERY OTHER STAGE IS ABSENT BECAUSE ITS OWNING STORE DOES NOT EXIST, and none of them is
## faked here:
##   ARCH-SYS-001 TransformSnapshot   THE STORE IS NOW COMPOSED -- `transforms()` -- and §5.1's
##                                    twelve hold authoritative roots under INIT-POSE-R01. What
##                                    is still missing is anything that MOVES: no per-tick
##                                    snapshot is taken because current and previous cannot
##                                    differ while no mover exists.
##   ARCH-SYS-004 StockAge            RUNS NOW -- see the dispatched list above and decision
##                                    0085. It is not in this absent list any more. What is
##                                    still missing is WHICH STORE a container is: GDD §5.8's
##                                    four store factors belong to §5.9 buildings and furniture,
##                                    and no Building store exists, so `stock_age.gd` holds an
##                                    explicit declaration the building layer will write and
##                                    counts every undeclared container every hour.
##   ARCH-SYS-006 CropWeather         RUNS NOW -- see the dispatched list above and decision
##                                    0047. It is not in this absent list any more.
##   ARCH-SYS-007 ImmigrationDeparture no candidate store; `needs.gd` leaves `departure_days`
##                                    explicitly unwritten pending a complete mood.
##   ARCH-SYS-009 JobPlanner          RUNS NOW -- see the dispatched list above. It is not in
##                                    this absent list any more.
##   ARCH-SYS-011 Navigation          no pathfinder, no navigation graph, no route cache.
##   ARCH-SYS-012 Movement            the Transform store now exists; no pathfinder, no route and
##                                    no mover do. `movement.gd` is not composed here and nothing
##                                    calls `advance()` in the running game.
##   ARCH-SYS-014 BatchCompletion     no BatchState, no recipe store, no passive-wait flag.
##   ARCH-SYS-015 LogisticsCommit     no completion or transfer plans to commit.
##   ARCH-SYS-016 RoomHeat            THE BUILDING, ROOM AND FURNITURE STORE IS NOW COMPOSED --
##                                    `buildings()` -- so "no store" is no longer the reason and
##                                    is not repeated here. What is still missing is §5.9's
##                                    CONNECTED HEAT SERVICE: a fueled hearth heats every valid
##                                    room "connected by open boundaries or interior doors within
##                                    that building, up to 120 total interior tiles per hearth"
##                                    (BAL-RATIO-010), allocated by hearth id then room id. That
##                                    is room-to-room connectivity and an impermeable-partition
##                                    model, and `buildings.gd`'s header says in terms that
##                                    connectivity, enclosure and "heated" are NOT derived there.
##                                    So the store answers how many hearths and how many interior
##                                    tiles exist, and nothing answers which tiles a given hearth
##                                    reaches. `economy_system.gd`'s fuel-days therefore stays
##                                    unpopulated, with a narrower stated reason than before.
##   ARCH-SYS-018 SocialMood          MoodMemory storage is blocked by U6 (no owner-major index
##                                    formula), so the memory total stays 0 and `needs.gd`
##                                    computes mood from the five needs alone.
##   ARCH-SYS-019 Lifecycle           no create/destroy/arrival/departure intents exist to
##                                    commit; the only lifecycle event in the game is the §5.1
##                                    world-cohort-and-pose creation below, which is not a
##                                    per-tick intent. INIT-POSE-R01 defines `i = persistent_id-1`
##                                    for ids 1..12 ONLY: immigration, births, rescue release,
##                                    load, teleportation and scenario variants each need their
##                                    own placement contract, and a later arrival belongs at
##                                    §5.1's map exit (64,126), never on the assembly row.
##   ARCH-SYS-020 Progression         no Progress store and no completed recipes or feasts.
##   ARCH-SYS-021 ForecastNotice      `economy_system.gd` recomputes its summary synchronously on
##                                    every committed change; its hourly half has nothing to
##                                    change while no lot ages and no policy exists.
##   ARCH-SYS-022 CheckpointHash      no save stream and no canonical digest yet.
##   ARCH-SYS-023 PresentationExtract RUNS NOW -- see the dispatched list above and the float
##                                    paragraph below. It is not in this absent list any more.
##
## REQ-SET-007's daily order is "age stocks, update ecology, advance crops/weather, process
## immigration/departures, then evaluate progression IN THAT ORDER", and `run_day_boundary()`
## runs exactly ONE of those five legs plus the season handover between the first two. What it
## does, in the requirement's order:
##
##   age stocks              RUN, and this is what decision 0085 added: `scripts/core/stock_age.gd`
##                           (ARCH-SYS-004) folds GDD §5.8's effective storage age into every lot
##                           in every DECLARED container, and expires the lots whose shelf life
##                           is over. Its cadence is the HOUR crossing, not the day, so at
##                           midnight this leg has usually already run on the tick path and the
##                           boundary records it rather than aging a second time (ARCH-TICK-002).
##                           It reads the ELAPSED interval's season, which is the first half of
##                           ARCH-TICK-003 and the reason it must precede the handover below.
##   [season handover]       RUN. ARCH-TICK-003 places it exactly between aging and ecology
##                           ("aging uses the season in the elapsed interval; ecology uses the
##                           new calendar day's season"), and REQ-SET-143's x1.20 winter hunger
##                           multiplier lives in `needs.gd` with the calendar season as its
##                           only input.
##   update ecology          RUN, and this is what task 03 increment 9 added:
##                           `scripts/core/ecology.gd` (ARCH-SYS-005) advances the fish stocks,
##                           the forage patches and their ruled quota midnight, every live hive
##                           and the exhausted resource nodes whose regrowth date has arrived.
##   advance crops/weather   RUN, and this is what task 03 increment 10 added:
##                           `scripts/core/crop_weather.gd` (ARCH-SYS-006) settles the completed
##                           day's REQ-SET-087 blight, advances every orchard block by that
##                           completed day, schedules and discloses §5.10's weather for the day
##                           now beginning, applies REQ-SET-086's evaporate-then-rain moisture,
##                           clears the tending flags, and makes decision 0044's FARM-side
##                           pollination refresh for any hive eligibility crossing the ecology
##                           leg above just committed. Its HOURLY half is on the tick path.
##   immigration/departures  NOT RUN. ARCH-SYS-007 has no candidate store.
##   evaluate progression    NOT RUN. ARCH-SYS-020 has no Progress store.
##
## THE LEG THAT DOES NOT RUN IS NOT FAKED AND THE ORDER IS NOT ASSUMED. `daily_leg_at()` and
## `daily_leg_count()` publish the legs the most recent boundary ACTUALLY EXECUTED, in the order
## it executed them, so "ecology runs after the season handover and nothing else runs" is a test
## rather than a comment. NO CONSTANT IS INVENTED: the season comes from `sim_clock.gd`'s offset
## calendar, the multiplier from `needs.gd`, and every ecology number from the four stores.
##
## ---------------------------------------------------------------------------------------
## ARCH-SYS-023 IS WHERE A `float` BECOMES LEGAL, AND NOWHERE ELSE IN THIS LOOP. AGENTS.md fixes
## integer arithmetic for all authoritative state; `presentation_extract.gd` is the presentation
## side of that boundary and is the ONLY module this node composes that produces a float at all.
## It captures fourteen COMMITTED INTEGERS once per tick and interpolates between the last two
## captures for a renderer, at an integer alpha the renderer supplies. Three properties this node
## depends on, each enforced there and each tested:
##   * IT WRITES NO STORE. Its only inputs are readers; it holds no reference this node's stores
##     can be reached through, and it is dispatched LAST so it never photographs a half-run tick.
##   * NO MUTABLE HANDLE ESCAPES IT. `presentation()` hands out an object whose every read fills
##     a record the CALLER owns. A UI holding it holds fourteen numbers and cannot edit one.
##   * HIDING A LAYER CHANGES WHAT IS REPORTED, NOT WHAT IS TRUE. A hidden layer's fields refuse;
##     the captured value, the next capture and every authoritative column are untouched.
## A refused capture is COUNTED in `refused_extract_count()` and never fatal: a missed frame is a
## presentation fault, and the simulation it failed to photograph is still correct.
##
## ---------------------------------------------------------------------------------------
## THE JOB QUEUE IS EMPTY IN AN *UNGENERATED, UNCOMMANDED* SETTLEMENT, AND THAT IS NOW THE WHOLE
## OF THE CLAIM. `job_planner.gd` (ARCH-SYS-009, decisions 0039/0040/0041/0051) IS COMPOSED HERE and
## runs every tick. What it creates, exactly:
##
##   WHAT NOW CREATES WORK IN THE RUNNING GAME:
##     * R06-JOB-001/002 REPEAT FORAGE HARVEST, from a PLAYER COMMAND. A committed DESIGNATE_ZONE
##       over a generated ecology basin creates the designation and enables its standing demand,
##       and the very next planner tick publishes a QUEUED FORAGE Job against real stock. That is
##       the whole intent-to-job path task 04.4 exists to close, and it is now one call chain.
##     * R06-JOB-007's daily 1-WU FARM tending service for each GROWING FarmPlot.
##     * R06-JOB-004's sowing first-plant, once something confirms a planting.
##     * R06-JOB-006's daily 20-WU KEEP hive service, for each operational, non-abandoned Hive on
##       a spring/summer/autumn service day (decision 0051). It needs NO player command: it is
##       condition-driven, so a colonised apiary produces work on the very next planner tick. The
##       planner is given ARCH-SYS-005's OWN hive store, asserted above, so the rows it services
##       are the rows `ecology.gd` advances. WINTER CREATES NO TENDING-LABOR JOB; it records a
##       feed-delivery demand as state, and no delivery job exists for it.
##     * DEMO-CONTAIN-R01's demolition work (decision 0537): one BUILD Job per admitted demolition
##       or piece removal, posted by `_reconcile_removal_work()` in this same planner slot.
##   WHAT STILL CREATES NONE: REQ-SET-073 ripe harvest and REQ-SET-085 withered clearing (both
##     keep their own route and are NOT rerouted through the planner); fishing cycles
##     (R06-JOB-003, no Expedition store); rotation advance (R06-JOB-005, `field_policy.gd`
##     requests a crop and creates no Job, nothing delivers that request, and NOTHING COMPLETES
##     THE HARVEST OR CLEARING JOBS THAT WOULD CLOSE A CYCLE -- decision 0051 §5); the hive's
##     winter FEED DELIVERY (no hive-owned destination container and no hauling producer; the
##     container store itself exists); and every production order, recipe, construction, care
##     request and hauling policy, none of which has a store.
##
## AN *UNGENERATED* SETTLEMENT'S QUEUE IS STILL 0, AND `world_init.gd` IS NOW COMPOSED HERE.
## `create_generated_settlement()` (decision 0071, reordered by R-INIT-ID-001 / decision 0075) runs
## §5.1's cohort and REQ-SET-009's world as one transaction -- the twelve residents first, on
## persistent ids 1-12, and the world from 13 -- so the running game has trees, ore, four forage
## basins, the estuary, a seeded RNG AND twelve residents whose ids are the GDD's own.
## The two blockers that kept the generator out of this node are both gone:
## decision 0052 gave its seventeen item ids an authored source (resolved by key from the compiled
## catalog, so this node still invents none of them), and this node is now the caller. A queue of
## 0 after generation means no player command has arrived, which is the honest remaining reason.
##
## NOTHING HERE WRITES JOB_STATE_WORK. A planner-published job is QUEUED; ARCH-SYS-010 may bind a
## worker and make it RESERVED; RESERVED -> TRAVEL -> WORK is ARCH-SYS-011/012's and does not
## exist. Task 04.4 says in terms that no delivered output is expected before task 05.
##
## `job_queue_length()` reports the real number, and the selection and work stages run over it
## honestly. A fabricated job would make the loop look busy and would measure a fiction; that has
## not changed.
##
## Two further gaps mean the job pipeline could not complete a job even if one existed, and both
## belong to files this task does not own:
##   * `jobs.gd` implements eligibility steps 1-6 of 7. STEP 7, "legal destination", is not
##     implemented and the `estimated_path_cells` sort term is not implemented, because no
##     pathfinder exists.
##   * `assign_worker()` moves a job to JOB_STATE_RESERVED. RESERVED -> TRAVEL -> WORK is the
##     completion of travel, which is ARCH-SYS-011/012's work. Nothing here writes JOB_STATE_WORK,
##     because inventing that transition would be inventing the movement layer. The work stage
##     ticks whatever is genuinely in JOB_STATE_WORK and nothing else.
##
## ---------------------------------------------------------------------------------------
## THE ECOLOGY IS OWNED, DRIVEN AND -- ONCE GENERATED -- FULL. `ecology.gd` composes the four
## ecology stores over THIS settlement's directory, and `run_day_boundary()` drives it at every
## real midnight. Until `create_generated_settlement()` runs, `count()`, `zone_count()`,
## `habitat_count()` and `hive_count()` are all 0 and the stage honestly does nothing; after it
## runs they hold §5.1's tree cover, both ore deposits, the four forage basins and the estuary's
## three habitats, and the midnight leg advances real stock. Nothing is placed here to make the
## day look busy: every row comes from `world_init.gd`, which owns the geometry and the counts.
## `ecology()` is the accessor the generator and the tests reach the stores through, and
## ARCH-SYS-006 and ARCH-SYS-009 borrow the same object rather than a copy.
##
## THE CROP LAYER IS OWNED, DRIVEN AND EMPTY IN THE SAME THREE SENSES. `crop_weather.gd` composes
## the FarmPlot store and the single Weather row over this settlement's directory, `run_tick()`
## drives its hourly leg at every hour crossing and `run_day_boundary()` drives its daily leg at
## every real midnight. THE WEATHER IS REAL FROM DAY 1 -- `create_initial_settlement()` opens the
## opening day's baseline, which the offset calendar's first midnight (day 2) would otherwise
## leave 18 hours late -- and THE FIELDS STAY EMPTY EVEN AFTER GENERATION, because §5.1 lists no
## starter FarmPlot and `world_init.gd` therefore creates none: a plot arrives with a player FARM
## designation. `farming().count()` is 0, so the hourly leg honestly integrates nothing.
## `crop_weather()`, `farming()` and `weather()` are the accessors the generator and tests use.
##
## ---------------------------------------------------------------------------------------
## THE BUILDING, ROOM AND FURNITURE STORE IS NOW CONSTRUCTED, AND IT IS EMPTY. `buildings.gd`
## (decision 0080) landed complete and NOTHING CALLED `Buildings.new()`; its author named the
## exact line and left it, because this file was another agent's. `_init()` now makes that call
## with THIS settlement's directory, which is the whole of the change and the whole of what it
## buys. Precisely what a shared directory buys, and nothing more:
##   * `Furniture.user` can name a resident. `set_furniture_user()` validates the reference
##     through `directory()`, so a bed's occupant is a row `residents()` actually owns; with two
##     directories it could only ever have been a foreign reference this store must refuse.
##   * `world_init.gd`'s world entities and a placed building draw slots from ONE allocator, so
##     R-INIT-ID-001's persistent-id sequence stays one sequence.
##   * `reset()` releases the building rows' directory slots. `clear()` destroys only the rows
##     this store holds and leaves a SHARED directory alone (its
##     `test_a_shared_directory_is_not_cleared_by_this_store` pins that), which is why placing
##     the call in `_clear_stores()` alongside the ecology's is safe and leaks no slot.
##
## THE STARTER COLONY IS NOW REAL (INIT-C live apply, DEMO-CONTAIN-R01 step D3, decision 0533).
## `create_generated_settlement()` publishes the world and then, still inside its one transaction,
## creates the World directory row and materialises `starter_structures.gd`'s validated plan
## through `starter_colony.gd`: §5.9's hall, four open stockpiles, well and workbench, the hall's
## dormitory/kitchen/common/pantry rooms and its thirty-one floor furniture, all ACTIVE at tier 1
## and rotation 0, placed through `buildings.gd`'s ordinary doors and then re-read against the
## plan. So `live_building_count()` is 7, `live_room_count()` 4, `live_furniture_count()` 31 and
## `live_furniture_of_kind(bed)` 12 after generation -- measured rows, not a fixture. The eight
## partition/door EDGES, room validity and building condition are NOT applied; decision 0533 and
## `starter_colony.gd`'s header say why. UI-SET-103's Create reaches the same apply through
## `materialize_starter_colony()`, which `ui_manager.gd` calls after its own publication.
##
## THE GROUND-PILE COMPOSER IS COMPOSED HERE AND OUTLIVES NOTHING IT SERVES (decision 0532's
## obligation). `ground_piles.gd` is built in `_init()` over this settlement's inventory, buildings
## and stock-age stores and kept in `_ground_piles` for the node's whole life, because Inventory
## and Buildings each hold it only weakly. It is Inventory's site authority for
## `create_ground_pile()` and Buildings' placement authority, so `place_building()` refuses a
## footprint over a live pile by name (BUILDING_FOOTPRINT_OVER_GROUND_PILE, 0532's M4). Its World
## binding is made each time the starter colony is materialised, from the row created there.
##
## NO STAGE IS ADDED TO THE TICK. The store is structural state edited by placement and
## demolition, not integrated per tick, and ARCH-SYS-016 RoomHeat -- the one §5 stage that would
## read it -- still has no connected-heat model (see the absent-stage list above). `run_tick()`
## and `run_day_boundary()` are byte-for-byte the same dispatch they were.
##
## ---------------------------------------------------------------------------------------
## THE CONSTRUCTION STORE IS COMPOSED OVER THE SAME BUILDING STORE, AND IT IS EMPTY.
## `construction.gd` holds REQ-SET-124-128/137's project lifecycle -- delivery before work,
## consumption when work begins, the 100%/80% cancellation refund and the 50% demolition return.
## It is constructed as `Construction.new(_buildings)` and therefore BORROWS this settlement's one
## Building store and, through it, this settlement's one directory: a project's subject is a row
## `buildings()` actually owns, and `Building.construction` names a project `construction()`
## actually owns. A `Construction` built with its own allocator would refuse every real building.
##
## `live_project_count()` is 0 after `create_generated_settlement()`: the starter colony is
## placed ACTIVE (decision 0533), not as blueprints, and nothing here opens a project.
## ALSO ADDS NO TICK STAGE. REQ-SET-124's delivery and build jobs for NEW construction are still
## absent. Only a removal's work reaches this store from a Job: D6 (decision 0537, below) credits
## a demolition or piece-removal BUILD Job's accepted milli-WU through `add_work_mwu_into()` inside
## ARCH-SYS-013's own slot, so `tick_stage_count()` is still 8 and every stage keeps its name.
##
## ---------------------------------------------------------------------------------------
## `request_demolition()` IS REQ-SET-128'S COMPOSED GATE PLUS BLOCKER 1's *ADMIT* (decision 0534).
## INV-GOODS-R01 puts the goods half of REQ-SET-128 exactly here, because this is the only place
## `buildings()`, `construction()` and `inventory()` meet over one directory. `preview_demolition()`
## runs five ordered stages and CHANGES NO STATE IN ANY OF THEM:
##
##   1. SUBJECT. A stale ref, a building that is not ACTIVE, or one already carrying a project.
##   2. ENDPOINT PROOF. Walk the building, each of its rooms, each furniture in those rooms, and
##      the project bound to each of those subjects; every ref must be live in the directory, and
##      a project's `material_container` must name a LIVE inventory container -- or, when it
##      names none, the project must have had nothing delivered to it. A binding that cannot be
##      proved is MISSING_CONTAINMENT_CONTRACT and NOT an empty result.
##   3. GOODS. `inventory().containers_by_owner_into()` per distinct endpoint owner, plus each
##      project's material container by handle, de-duplicated by container slot. Every live lot
##      is counted ONCE whatever its `reserved_milli`, and a container's `reserved_mass_g` is
##      reported SEPARATELY as an outstanding capacity claim.
##   4. OCCUPANTS, RECHECKED AFTER stage 2 and from `construction()`'s own counters.
##   5. FOOTPRINT CONTAINMENT (DEMO-CONTAIN-R01 #3a/#3c/#5/#7). The footprint, door tiles
##      included, is marked once; every container the owner scan reached must be anchored ON it,
##      and every container anchored on it must be one of those or a ground pile, whose goods
##      join stage 3's totals. An anchored ownerless container refuses (#7). Satchels are unplaced
##      and never seen here (#3d). Placement is read through `container_anchor_tile_into()`.
##
## *ADMIT* RUNS ONLY ON A PASSING PREVIEW, IN THE SAME CALL. It proves the store transition
## (`construction().demolition_open_refusal()`), the admission record, the absence of a caller's
## inventory transaction and an output plan -- the lowest surviving store with room for the whole
## 50% return, else a rolled-back ground-pile placement (#9) -- BEFORE its first write. Then it
## reserves that capacity and publishes the demolition project inside one inventory transaction,
## records the admission and advances the building's destination revision in
## `demolition_admissions()`. The return and the work include every piece of furniture: 50% of
## each piece's bill, its package derived from its type, and a quarter of its WU (decision 0536,
## Brendan's rulings on 0535). Only a piece with a live project of its own refuses, at the end of
## the preview.
## `cancel_demolition()` is the only cancellation: it releases that claim BEFORE retiring the
## project, because construction cannot see Inventory; `close_refund()` refuses a demolition by
## name (decision 0536), so `close_demolition_refund()` is the coordinator's own door.
##
## `complete_demolition()` IS #6's ONE NO-YIELD COMMIT (decision 0535). Once the project's work is
## done it proves, writing nothing: the coordinator's own admitted project and its held claim,
## stages 2-5 again, the furniture rule, and the return's placement (rolled back). Then it writes
## in #6's order -- (1) every affected container destroyed, (2) every piece of furniture, (3) rooms,
## (4) the building, (5) the 50% return into the released claim's store or onto ground piles,
## (6) the project retired -- with (1) and (5) and the claim's release in ONE inventory
## transaction, and the admission record released (destination revision +1) before the building
## row goes. Every refusal before the record's release writes nothing and leaves the project
## PHASE_WORK_DONE: commit-pending, retried at no cost; later ones are unreachable guards.
##
## ONE PIECE CAN BE TAKEN OUT OF A STANDING BUILDING (decision 0536, Brendan's P2):
## `preview_furniture_removal()`, `request_furniture_removal()`, `complete_furniture_removal()` and
## `cancel_furniture_removal()` are the same admit and commit with the piece as subject, recorded
## against its building's admission row (one admission per building). A shelf in a pantry room
## takes its 50000 g out of the building's main store, refusing when that would overflow (#3b).
##
## D6: THE WORK IS A BUILD JOB, AND "EVACUATE, THEN DEMOLISH" IS A RECORDED ORDER (decision 0537).
## Every admitted removal gets one BUILD Job (`demolition_work.gd`), posted by
## `_reconcile_removal_work()` in ARCH-SYS-009's slot -- before selection -- whenever an admission
## marks it dirty and on every hour crossing. ARCH-SYS-013 credits the Job's accepted milli-WU to
## the project in the same tick, proved first so nothing is consumed that the project cannot
## take; when the Job completes, the walk ends and the coordinator's own commit runs. A commit
## that refuses stays commit-pending and is retried hourly. `order_evacuate_then_demolish()`
## records the order when admission is refused for goods or a claim (stages 3 and 5) and the same
## hourly reconcile retries *admit* once every container on the footprint reports empty. NO HAUL
## JOB IS POSTED: physical hauling is task 06.4 and does not exist (no satchel, no movement, and
## INV-GOODS-R01 forbids the gate teleporting goods), so the order waits for whatever empties the
## stores. And nothing writes JOB_STATE_WORK yet (below), so in the running game a removal Job
## is offered and reserved but never worked; the bridge is exercised by tests that stand in for
## arrival exactly as the existing productive-work tests do.
##
## EVERY REFUSAL IS READ-ONLY, WHICH IS ASSERTED IN BYTES. Every path returns a
## `DemolitionReport` carrying exact counts and the exact stranded lot refs, and a refusal leaves
## Building, Construction, Inventory, the directory and the admission record byte-identical.
##
## THE WORLD SEED IS NO LONGER MISSING. `rng()` is composed here UNSEEDED and stays that way in a
## settlement nobody generated; `create_generated_settlement()` seeds it, because `world_init.gd`
## owns REQ-SET-009's `World.seed` and seeds all nine streams as part of publishing. §5.10's
## forced first spring consumes zero draws, so even an ungenerated settlement's first season runs
## and only its SECOND season's first midnight refuses `RNG_NOT_SEEDED`. A GENERATED settlement
## does not: it runs a full simulated year of weather. No seed is defaulted or invented here.
##
## ---------------------------------------------------------------------------------------
## THE STOCK LAYER IS OWNED, DRIVEN AND EMPTY, in the same three senses as the crop layer.
## `inventory.gd` is composed here with the §4.3 catalog registered into it, `stock_age.gd`
## (ARCH-SYS-004) is composed over it, and `run_tick()` drives its hourly leg at every hour
## crossing. §5.1's starter stock is placed INTO THIS STORE by `economy_system.gd`, which adopts
## it through `bind_inventory()` before opening the colony's stores (decision 0534, closing
## decision 0087's two-inventory split), so the demolition gate and section 7 see those lots.
## The five starter stores carry no StockAge declaration yet, so they are counted undeclared and
## not aged; declaring store classes stays with the building layer.
##
## THE RESERVATION POOL IS OWNED AND EMPTY. `reservations.gd` exists to hold job input claims
## (REQ-SET-030's all-or-nothing reservation), and there are no jobs. It is composed and cleared
## with the rest of the settlement so it is one settlement's state rather than a detached object,
## and it holds zero rows. Nothing here claims, renews or releases anything.
##
## ---------------------------------------------------------------------------------------
## ALLOCATION ON THE TICK PATH, named rather than claimed away. Per tick this node allocates
## nothing of its own: the Calendar, the IntResult and the TickResult are instance scratch, and
## every column is packed and sized once. It calls three functions that allocate INSIDE modules
## this task does not own, each their published contract:
##   * `residents.tick_needs_all()` ONE OpResult per tick for the whole sweep (needs.gd header).
##   * `schedule.resolve_into()` three IntResults inside `needs.gd`, per resident RESOLVED, and a
##     resident resolves once per 30 ticks (schedule.gd header).
##   * `jobs.evaluate()`    one OpResult plus ~27 IntResults per PASS, and a resident passes once
##     per 30 ticks (jobs.gd header, which names 27 as the floor available to it).
##   * `jobs.live_job_at()` one IntResult per live job per tick. `jobs.gd` publishes no `_into`
##     form of it. THIS IS THE ONE THAT WOULD MATTER, and today it costs nothing because there
##     are no jobs; when a job source lands, `jobs.gd` needs a non-allocating live-index reader.
##     Reported, not worked around, and not fixed by editing a file this task does not own.
##   * `stock_age.run_hour_into()` ZERO on 23 ticks in 24, for the same reason as the crop hour
##     below, and zero on the 24th unless a lot ACTUALLY EXPIRES -- the sweep walks packed
##     columns and writes through `inventory.gd`'s `_into` forms into instance scratch. An
##     expiring lot costs four OpResults inside `inventory.gd`, once in that lot's life.
##   * `crop_weather.run_hour_into()` ZERO on 23 ticks in 24, because `is_hour_boundary()` is a
##     modulo and returns before anything else runs. On the 24th it allocates nothing either,
##     unless a plot actually takes frost or actually withers; `crop_weather.gd`'s own header
##     itemises which store calls allocate on which hour and why.
##   * `job_planner.run_tick_into()` ZERO of its own (that file's header states it): the drain,
##     the 1/30 owner slice and the 1/30 designation slice all run through `_reconcile_owner()`,
##     which returns an int. A tick on which it actually PUBLISHES a job allocates inside
##     `jobs.gd` and `forage.gd`, per job, which is their published contract.
##   * `presentation.capture()` ZERO. Both frames and both flag columns are sized once, the
##     calendar is instance scratch, and every field is a scalar read.
##
## ARCH-SYS-005 IS NOT ON THE TICK PATH AT ALL, AND ARCH-SYS-006 IS ON IT ONLY HOURLY.
## `ecology.gd` is called from `run_day_boundary()` and never from `run_tick()`, so its per-day
## cost -- one OpResult per store sweep, plus one per resource node actually regrown, all named in
## that file's header -- lands once per SIMULATED DAY, which at 1x is once per 18000 ticks.
## `crop_weather.gd`'s DAILY leg lands there too. Its HOURLY leg is the only thing this milestone
## adds to the per-tick path, and on a non-crossing tick that is one addition and one modulo.
##
## ---------------------------------------------------------------------------------------
## STOCK-SEED-R01'S CRITICAL PAUSE AND ITS ONE REVALIDATED RETRY LIVE HERE, AND THIS IS THE
## GAP `stock_age.gd`'S HEADER GAP 4 NAMED. That module counts and names a refusal with every
## collaborating store left byte identical and invents neither a pause nor a retry ledger,
## because ARCH-SYS-001 makes this file's dispatcher the owner. What this file now does:
##
##   * THE PAUSE IS THE EXISTING ONE. `sim_clock.gd` has held a CRITICAL bit in its reason mask
##     since task 02, `scheduler_events.gd` owns its producers, and REQ-SET-008's overload
##     ladder already raises it. NO SECOND PAUSE CONCEPT IS CREATED. The hold is submitted with
##     `submit_safety_hold_into(SimClock.CRITICAL)` -- the queue's own INTERNAL-producer path:
##     reserve-eligible, so ordinary traffic cannot crowd it out, and coalescing, so a repeat
##     consumes no sequence. Submitted from inside tick k it is stamped k while the clock still
##     reads k-1, so the barrier applies it AFTER k commits. This node never pumps the queue.
##   * WHICH FAILURES REACH IT. The ruling's "arithmetic, ledger or schema failure" is exactly
##     two sets: `stock_age.gd`'s three preflight refusals (INVENTORY_NOT_BOUND,
##     ITEM_CATALOG_NOT_BOUND, INVENTORY_TRANSACTION_OPEN), and any hour with
##     `refused_lots > 0` -- every path that increments that count is a checked-arithmetic
##     refusal, an inventory `begin()` refusal or a poisoned `commit()`. INVALID_TICK,
##     NOT_AN_HOUR_BOUNDARY and HOUR_ALREADY_RUN are NOT integrity faults: they mean the hour
##     was never owed and changed nothing, and they stay counted and non-fatal as before.
##   * THE RETRY IS EXACTLY ONCE BECAUSE THE ENTITLEMENT IS KEYED TO THE TRANSACTION AND SPENT
##     BEFORE THE ATTEMPT. Not a per-sweep counter (which would grant a fresh retry every hour
##     to the same unrecovered fault) and not a latch that never clears (which would turn one
##     bad hour into a permanently degraded system). A fault at a LATER hour is a different
##     expiry transaction and earns its own single retry; the faulted hour never gets a second.
##   * THE RETRY IS REVALIDATED, NOT REPLAYED. Nothing about the failed attempt is captured.
##     `run_hour_into()` is called again on the FAULTED tick and re-runs the preflight,
##     re-resolves the catalog ids by key, re-decodes both calendars and re-reads every declared
##     container and lot from live state. A fault still present refuses again, which is what
##     stops the retry being a busy-loop against the same bad snapshot.
##   * WHEN THE RETRY ALSO FAILS the simulation HALTS: every LATER `run_tick()` refuses
##     STOCK_AGE_INTEGRITY_HALT, runs no stage, and re-asserts the hold. The tick that declares
##     the halt still commits, because ARCH-SYS-003's sweep for it has already committed and the
##     queued hold lands at the barrier after the tick regardless. Continuing past that would
##     silently skip an hour of §5.8 aging. The only exit is `reset()`; there is deliberately no
##     "clear the fault" call, because that is the escape hatch that lets the skipped hour
##     through after all.
##
## THE TWO THINGS THIS COULD NOT DO, both named rather than faked:
##   1. A PER-LOT FAULT GETS THE PAUSE BUT NO RETRY. `stock_age.gd` reports `refused_lots` and
##      `last_lot_refusal` and NAMES NO LOT REF, and publishes no per-lot expiry entry point, so
##      there is no handle to revalidate and re-commit. Re-running the hour is forbidden by the
##      ruling itself ("does not rerun completed hourly work") and by StockAge's own hour latch.
##      Re-deriving the conversion here would duplicate the transformation ARCH-SYS-004 owns.
##      So such a fault raises the pause and halts at once. Closing it needs two additions to
##      `stock_age.gd`, which is another owner's file: a `last_refused_lot()` reader and a
##      `retry_refused_lot_into(lot_ref, out)` that re-derives quantity, item, masses and age
##      and re-runs that one expiry transaction without touching the hour latch.
##   2. CRITICAL IS A SHARED BIT. REQ-SET-008's overload ladder produces it too and
##      `sim_clock.gd` offers no sub-reason space or hold count, so `acknowledge_without_catchup()`
##      clears an integrity hold and this file's clear can lift an overload hold. What is done
##      about it here is the only thing that can be: `_refuse_while_halted()` re-submits the hold
##      on every refused tick, so a wrongly cleared integrity pause costs one refused tick rather
##      than resuming an unsafe world.
##
## NO TICK STAGE IS ADDED. The retry runs inside TICK_STAGE_STOCK_AGE's existing measurement
## window, so `tick_stage_count()` is still 8 and its test needs no bump.
##
## REFUSAL, NOT SENTINELS. Every operation returns a bool with the reason in `last_refusal()`, or
## an `IntMath.IntResult` whose `.ok` must be inspected. `mean_tick_usec()` REFUSES before the
## first tick rather than answering 0, because 0 microseconds is a plausible-looking measurement.

const EntityDirectoryScript := preload("res://scripts/core/entity_directory.gd")
const NeedsScript := preload("res://scripts/core/needs.gd")
const ResidentsScript := preload("res://scripts/core/residents.gd")
const PrioritiesScript := preload("res://scripts/core/priorities.gd")
const ScheduleScript := preload("res://scripts/core/schedule.gd")
const JobsScript := preload("res://scripts/core/jobs.gd")
const WorkScript := preload("res://scripts/core/work.gd")
const ReservationsScript := preload("res://scripts/core/reservations.gd")
const CommandsScript := preload("res://scripts/core/commands.gd")
const CommandDispatchScript := preload("res://scripts/core/command_dispatch.gd")
const EcologyScript := preload("res://scripts/core/ecology.gd")
const JobPlannerScript := preload("res://scripts/core/job_planner.gd")
const PresentationExtractScript := preload("res://scripts/core/presentation_extract.gd")
const CropWeatherScript := preload("res://scripts/core/crop_weather.gd")
const FarmingScript := preload("res://scripts/core/farming.gd")
## Reached for `season_of_day()` alone: ARCH-SYS-005 owns the §5.6 calendar and the cohort
## preflight asks it which season the opening day is in rather than deriving a second answer.
const OrchardHiveScript := preload("res://scripts/core/orchard_hive.gd")
const WeatherScript := preload("res://scripts/core/weather.gd")
const RngScript := preload("res://scripts/core/rng.gd")
const SimClockScript := preload("res://scripts/core/sim_clock.gd")
const SchedulerEventsScript := preload("res://scripts/core/scheduler_events.gd")
const WorldInitScript := preload("res://scripts/core/world_init.gd")
const TransformsScript := preload("res://scripts/core/transforms.gd")
## Reached for the two authored ore-deposit footprints alone: INIT-POSE-R01 requires the assembly
## row proved clear of the static resource footprints, and decision 0029 owns their coordinates.
const ResourceNodesScript := preload("res://scripts/core/resource_nodes.gd")
const BuildingsScript := preload("res://scripts/core/buildings.gd")
const BuildingDefinitionsScript := preload("res://scripts/core/building_definitions.gd")
const ConstructionScript := preload("res://scripts/core/construction.gd")
const ItemDefinitionsScript := preload("res://scripts/core/item_definitions.gd")
const InventoryScript := preload("res://scripts/core/inventory.gd")
const StockAgeScript := preload("res://scripts/core/stock_age.gd")
const GroundPilesScript := preload("res://scripts/core/ground_piles.gd")
const GearScript := preload("res://scripts/core/gear.gd")
const HaulCarryScript := preload("res://scripts/core/haul_carry.gd")
const UndergroundSession := preload("res://scripts/core/underground_session.gd")
const UndergroundContent := preload("res://demo/cast/underground_actor_content.gd")
const DemolitionAdmissionsScript := preload("res://scripts/core/demolition_admissions.gd")
const DemolitionWorkScript := preload("res://scripts/core/demolition_work.gd")
const StarterStructuresScript := preload("res://scripts/core/starter_structures.gd")
const StarterColonyScript := preload("res://scripts/core/starter_colony.gd")
const MilestonesScript := preload("res://scripts/core/milestones.gd")
const IntMath := preload("res://scripts/core/int_math.gd")
const PerfTimerScript := preload("res://scripts/utils/perf_timer.gd")

## Index of winter in `sim_clock.gd`'s SEASON_NAMES. `_assert_shared_contracts()` proves it names
## winter rather than trusting the ordering, because REQ-SET-143's multiplier hangs off it.
const SEASON_WINTER: int = 3
const SEASON_COUNT: int = 4

## REQ-SET-007's five daily legs, in the requirement's own order, plus ARCH-TICK-003's season
## handover between the first two. `daily_leg_at()` publishes the ones a boundary ACTUALLY ran,
## so a leg this system does not own cannot be quietly slipped in and cannot be assumed absent.
const LEG_STOCK_AGE: int = 0
const LEG_SEASON_HANDOVER: int = 1
const LEG_ECOLOGY: int = 2
const LEG_CROP_WEATHER: int = 3
const LEG_IMMIGRATION_DEPARTURE: int = 4
const LEG_PROGRESSION: int = 5
const DAILY_LEG_CAPACITY: int = 6

## The §5 stages this node dispatches ON THE TICK PATH, in dispatch order. `tick_stage_usec_at()`
## publishes what each one COST on the most recent tick, so "which stage is expensive" is a
## measurement rather than an opinion. NO BUDGET IS ASSERTED AGAINST THEM: REQ-SET-163's figures
## are for 256 residents on a stated machine, and nothing here qualifies against them.
const TICK_STAGE_COMMAND_COMMIT: int = 0
const TICK_STAGE_INTERVAL: int = 1
const TICK_STAGE_STOCK_AGE: int = 2
const TICK_STAGE_CROP_HOUR: int = 3
const TICK_STAGE_JOB_PLANNER: int = 4
const TICK_STAGE_SELECTION: int = 5
const TICK_STAGE_WORK: int = 6
const TICK_STAGE_PRESENTATION: int = 7
const TICK_STAGE_COUNT: int = 8

## The ARCH-SYS id each measured stage is, so a reader cannot mistake the selection stage's
## fused pair for one system. ARCH-SYS-008 appears as a PART: only activity resolution runs.
const TICK_STAGE_KEYS: Array[StringName] = [
	&"ARCH-SYS-002 CommandCommit",
	&"ARCH-SYS-003 IntervalIntegrator (ARCH-SYS-017 CareHealth inside it)",
	&"ARCH-SYS-004 StockAge hourly",
	&"ARCH-SYS-006 CropWeather hourly",
	&"ARCH-SYS-009 JobPlanner",
	&"ARCH-SYS-008 NeedIntent (activity resolution only) + ARCH-SYS-010 JobSelector",
	&"ARCH-SYS-013 ProductiveWork",
	&"ARCH-SYS-023 PresentationExtract",
]

## REQ-SET-012's "a prepared meal is reachable and unreserved", answered false and NOT guessed.
## Two separate things are missing: §5.7's recipe/portion model, so no prepared MEAL exists as an
## entity at all (a `ration` lot in the pantry is stock, not a served portion nobody has claimed),
## and §5.11's pathfinder, so REACHABLE has no oracle. False therefore says "no reachable prepared
## meal", which is the true state of a settlement with no kitchen and no routes. Its only effect
## is that REQ-SET-013's raw-edible threshold (hunger<=1500) governs the eat interrupt instead of
## REQ-SET-012's 3500 -- and today not even that is observable, because both WORK and ANYTHING
## permit work and no job exists to be interrupted.
const PREPARED_MEAL_REACHABLE: bool = false

## GDD §5.1: the settlement opens on absolute day 1, at tick 0, which is 06:00 and no crossing.
const OPENING_CALENDAR_DAY: int = 1

## INIT-POSE-R01's authored starter placement: the refuge hall's SOUTH EXTERIOR APRON. Ordered by
## persistent id ascending, `i = persistent_id - 1` for ids 1..12 and for NO OTHER ID -- immigration,
## births, rescue release, load, teleportation and scenario variants each need their own placement
## contract, and a later arrival uses §5.1's map exit (64,126), never this row.
##
## Every value below is the ruling's own table, and `_assert_assembly_row()` re-derives each one
## from the inherited geometry in `world_init.gd` rather than trusting the transcription.
const ASSEMBLY_COHORT_SIZE: int = 12
const ASSEMBLY_FIRST_TILE_X: int = 58
const ASSEMBLY_TILE_Z: int = 69
const ASSEMBLY_FIRST_TILE_INDEX: int = 8890
const ASSEMBLY_FIRST_ROOT_X_UNITS: int = 119808
const ASSEMBLY_ROOT_X_STEP_UNITS: int = 2048
const ASSEMBLY_ROOT_Y_UNITS: int = 512
const ASSEMBLY_ROOT_Z_UNITS: int = 142336
## The authored neutral model orientation, asset forward -Z. THIS IS NOT A ROTATION CONVENTION:
## `transforms.gd` names the yaw zero reference and handedness as MOVE-G01/G04 blockers, and no
## moving actor may infer a positive-yaw direction from this value.
const ASSEMBLY_YAW: int = 0

const REFUSE_NONE: StringName = &""
const REFUSE_INVALID_TICK: StringName = &"INVALID_TICK"
const REFUSE_INVALID_DAY: StringName = &"INVALID_ABSOLUTE_DAY"
const REFUSE_INVALID_SEASON: StringName = &"INVALID_SEASON"
const REFUSE_NO_TICK_MEASURED: StringName = &"NO_TICK_MEASURED"
const REFUSE_CLOCK_BIND: StringName = &"SIMULATION_CLOCK_BIND_REFUSED"
const REFUSE_CALENDAR_MISMATCH: StringName = &"DAY_BOUNDARY_CALENDAR_MISMATCH"
const REFUSE_INVALID_INDEX: StringName = &"INVALID_INDEX"
const REFUSE_ECOLOGY_BIND: StringName = &"COMMAND_ECOLOGY_BIND_REFUSED"
## STOCK-SEED-R01's guard could not be bound to the lot store, so seed consumption would be
## enforced by nobody. Fatal for the same reason the ecology bind is: the HUD would show a running
## settlement while every sower helped itself to dead seed.
const REFUSE_SEED_AUTHORITY_BIND: StringName = &"SEED_EXPIRY_AUTHORITY_BIND_REFUSED"
const REFUSE_PLANNER_DAY: StringName = &"JOB_PLANNER_DAY_REFUSED"
## STOCK-SEED-R01. `STOCK_AGE_INTEGRITY_HALT` is what every tick refuses with once an arithmetic,
## ledger or schema failure in the hourly sweep has survived its one revalidated retry; it is a
## refusal, never a sentinel value, and nothing downstream reads a number out of it.
const REFUSE_STOCK_INTEGRITY_HALT: StringName = &"STOCK_AGE_INTEGRITY_HALT"
## Asked which hour faulted when none has. A refusal, because tick 0 is a real tick.
const REFUSE_STOCK_NO_FAULT: StringName = &"NO_STOCK_INTEGRITY_FAULT"

## INIT-POSE-R01 refusals. Each names the input that failed; none is a sentinel value and none
## leaves a partially placed cohort, because every one of them is decided BEFORE the first place().
const REFUSE_POSE_NO_PLAN: StringName = &"INITIAL_POSE_NO_PREPARED_WORLD"
const REFUSE_POSE_IDENTITY: StringName = &"INITIAL_POSE_IDENTITY_INVALID"
const REFUSE_POSE_TILE: StringName = &"INITIAL_POSE_TILE_INVALID"
const REFUSE_POSE_TERRAIN: StringName = &"INITIAL_POSE_TILE_NOT_LAND"
const REFUSE_POSE_NOT_CLEARED: StringName = &"INITIAL_POSE_TILE_NOT_CLEARED"
const REFUSE_POSE_OCCUPIED: StringName = &"INITIAL_POSE_TILE_OCCUPIED"
const REFUSE_POSE_TRANSFORM: StringName = &"INITIAL_POSE_TRANSFORM_REFUSED"
## R-INIT-ID-001 step 5, tightened by INIT-POSE-R01 §2.5: replacement rollback does not exist, so
## a published world is never overwritten -- not even one with nobody standing in it.
const REFUSE_WORLD_ALREADY_PUBLISHED: StringName = &"SETTLEMENT_WORLD_ALREADY_PUBLISHED"
## INIT-C live apply (decision 0533). The colony is materialised once per settlement; a World row
## or a live building already present means it has been, or that something else placed there.
const REFUSE_STARTER_COLONY_PRESENT: StringName = &"STARTER_COLONY_ALREADY_PRESENT"
const REFUSE_GROUND_PILES_BIND: StringName = &"GROUND_PILE_COMPOSER_BIND_REFUSED"
const REFUSE_EQUIPMENT_BIND: StringName = &"SETTLEMENT_EQUIPMENT_BIND_REFUSED"
const REFUSE_GROUND_PILE_WORLD_BIND: StringName = &"GROUND_PILE_WORLD_BIND_REFUSED"
## GDD §5.11: "Active new worlds start with M0=0 and both masks=1". The starter structures all
## carry unlock ordinal 0, so this is the mask they are placed under; no Progress store exists to
## read it back from (decision 0087 blocker 2), so the authored value is named here once.
const STARTER_UNLOCKED_MASK: int = MilestonesScript.INITIAL_MASK
## The KIND_WORLD row is the directory's only one of its kind (capacity 1), so it is typed row 0.
const WORLD_TYPED_ROW: int = 0

## REQ-SET-128's composed demolition gate (INV-GOODS-R01). Every one of these is a refusal that
## wrote nothing. The two resident refusals are `construction.gd`'s OWN codes, re-raised rather
## than re-spelled, so a caller cannot tell this gate's occupant answer from that store's.
const REFUSE_DEMOLITION_STALE_BUILDING: StringName = &"DEMOLITION_STALE_BUILDING_REF"
const REFUSE_DEMOLITION_NOT_ACTIVE: StringName = &"DEMOLITION_BUILDING_NOT_ACTIVE"
const REFUSE_DEMOLITION_IN_PROGRESS: StringName = &"DEMOLITION_ALREADY_UNDER_CONSTRUCTION"
## A binding needed to prove coverage is ABSENT. Distinct from every refusal below it, because
## "I could not see" and "I looked and it is occupied" must never read as the same answer -- and
## neither of them may read as the proved-empty success this gate cannot yet reach.
const REFUSE_DEMOLITION_MISSING_CONTAINMENT: StringName = &"DEMOLITION_MISSING_CONTAINMENT_CONTRACT"
const REFUSE_DEMOLITION_STORED_GOODS: StringName = &"DEMOLITION_BLOCKED_STORED_GOODS"
const REFUSE_DEMOLITION_CAPACITY_CLAIM: StringName = &"DEMOLITION_BLOCKED_CAPACITY_CLAIM"
## The owner query itself refused -- a malformed owner or an undersized buffer. Its own refusal,
## never folded into "no goods found".
const REFUSE_DEMOLITION_SCAN: StringName = &"DEMOLITION_GOODS_SCAN_REFUSED"
const REFUSE_DEMOLITION_OVERFLOW: StringName = &"DEMOLITION_GOODS_TOTAL_OVERFLOW"
## Stage 5, DEMO-CONTAIN-R01 #3a/#3c/#7 (decision 0534): the owner scan and the tile scan must
## agree. An affected owner's container placed off the footprint (or nowhere) is one way they
## disagree; a container on the footprint owned by somebody else is the other. An anchored
## container with no well-formed owner is #7's own refusal.
const REFUSE_DEMOLITION_OFF_FOOTPRINT: StringName = &"DEMOLITION_OWNED_CONTAINER_OFF_FOOTPRINT"
const REFUSE_DEMOLITION_FOREIGN_CONTAINER: StringName = &"DEMOLITION_FOREIGN_CONTAINER_ON_FOOTPRINT"
const REFUSE_DEMOLITION_ANCHORED_ORPHAN: StringName = &"DEMOLITION_ANCHORED_NULL_OWNER_CONTAINER"
## The footprint itself could not be read (the composer is unbound, or the door is off the grid).
const REFUSE_DEMOLITION_FOOTPRINT: StringName = &"DEMOLITION_FOOTPRINT_UNREADABLE"
## Admit (blocker 1): a material key the item catalog cannot name, no surviving store and no
## ground-pile fallback able to take the 50% return, or a caller's open inventory transaction.
const REFUSE_DEMOLITION_RETURN_ITEM: StringName = &"DEMOLITION_RETURN_ITEM_UNKNOWN"
const REFUSE_DEMOLITION_NO_OUTPUT: StringName = &"DEMOLITION_NO_OUTPUT_CAPACITY"
const REFUSE_DEMOLITION_TRANSACTION: StringName = &"DEMOLITION_INVENTORY_TRANSACTION_OPEN"
## `cancel_demolition()`: the building carries no demolition project to cancel, or the project is
## already being refunded, or the recorded claim is no longer held where the record says.
const REFUSE_DEMOLITION_NOT_ADMITTED: StringName = &"DEMOLITION_NOT_ADMITTED"
const REFUSE_DEMOLITION_CANCEL_PHASE: StringName = &"DEMOLITION_CANCEL_WRONG_PHASE"
const REFUSE_DEMOLITION_CLAIM_MISSING: StringName = &"DEMOLITION_RESERVATION_NOT_HELD"
## `release_stranded_reservation()`: the row's claim still has a live project (cancel instead), or
## the row records no claim at all.
const REFUSE_DEMOLITION_NOT_STRANDED: StringName = &"DEMOLITION_RESERVATION_NOT_STRANDED"
## Decision 0536: a piece of furniture whose own construction project is still live is not
## completed capital (BUILD-C4-R01 settles in-progress work through its cancellation first), so
## neither its building's demolition nor its own removal may take it until that project closes.
## Every other piece's package is DERIVED from its type (Brendan's P1 ruling) and returns 50%.
const REFUSE_DEMOLITION_FURNITURE_UNDER_CONSTRUCTION: StringName = \
	&"DEMOLITION_FURNITURE_UNDER_CONSTRUCTION"
## The commit's return is not the one admission charged: the recorded grams or the admitted charge
## differ from what the project would place now -- a piece placed or removed around the
## coordinator since admission (decisions 0535 review L5, 0536). Commit-pending until it agrees.
const REFUSE_DEMOLITION_RESERVATION_MISMATCH: StringName = &"DEMOLITION_RESERVATION_MISMATCH"
## Decision 0536's single-piece door: a stale piece; a piece whose building is not ACTIVE; and
## DEMO-CONTAIN-R01 #3b's two refusals -- the pantry store left over capacity without the shelf,
## or no single main store (an owned container at the building's origin) to take the reduction.
const REFUSE_REMOVAL_STALE_PIECE: StringName = &"FURNITURE_REMOVAL_STALE_PIECE"
const REFUSE_REMOVAL_BUILDING_NOT_ACTIVE: StringName = &"FURNITURE_REMOVAL_BUILDING_NOT_ACTIVE"
const REFUSE_REMOVAL_PANTRY_OVER_CAPACITY: StringName = &"FURNITURE_REMOVAL_PANTRY_OVER_CAPACITY"
const REFUSE_REMOVAL_PANTRY_STORE: StringName = &"FURNITURE_REMOVAL_PANTRY_STORE_UNREADABLE"

## The two endpoint stages. Named rather than a boolean flag: ONE walk defines the affected
## endpoint set, and running it twice with different stages is what makes the goods scan
## provably cover exactly the endpoints the proof just validated.
const ENDPOINT_STAGE_PROVE: int = 0
const ENDPOINT_STAGE_SCAN: int = 1
## Stage 5's first half: every container the owner scan reaches must be anchored on the footprint.
const ENDPOINT_STAGE_CONTAIN: int = 2
## #6's step (1), inside the commit's transaction: destroy every container the same walk reaches.
const ENDPOINT_STAGE_DESTROY: int = 3


class DemolitionReport:
	"""One demolition request's outcome and the exact evidence behind it.

	`OpResult.value` alone cannot describe a multi-lot notice (INV-GOODS-R01), so this carries
	the counts a notice needs AND the stranded lot refs themselves. `ok` is true only when the
	call it answers -- an admission or a completed demolition -- was made; `error` says why not,
	and the counters below are only filled by the stage that reached them -- a refusal at the
	endpoint proof leaves the goods totals at 0 BECAUSE NOTHING WAS COUNTED, which is exactly why
	`error` and not a zero total is what a caller must read.

	The lot columns are allocated once at the lot store's capacity and refilled per request.
	"""
	var ok: bool = false
	var error: StringName = &""
	var endpoint_owner_count: int = 0
	var scanned_container_count: int = 0
	var stranded_lot_count: int = 0
	var stranded_quantity_milli: int = 0
	var outstanding_reserved_mass_g: int = 0
	var claiming_container_count: int = 0
	var occupant_count: int = 0
	var furniture_user_count: int = 0
	## Stage 5: containers the tile scan found on the footprint, and the one that disagreed.
	var anchored_container_count: int = 0
	var blocking_container: Vector2i = InventoryScript.NULL_REF
	## Admit: the published project, where the return's capacity is reserved (an INVENTORY ref,
	## null when it falls back to ground piles), its grams, and the building's new revision.
	var project_ref: Vector2i = EntityDirectoryScript.NULL_REF
	var output_container: Vector2i = InventoryScript.NULL_REF
	var output_reserved_g: int = 0
	var output_to_ground_piles: bool = false
	var destination_revision: int = 0
	## D5 (decision 0535): the furniture that blocks the return (a DIRECTORY ref) and how many
	## pieces do; and, after a completed demolition, what its commit destroyed, removed and placed.
	var blocking_furniture: Vector2i = EntityDirectoryScript.NULL_REF
	var blocked_furniture_count: int = 0
	var removed_furniture_count: int = 0
	var destroyed_container_count: int = 0
	var removed_room_count: int = 0
	var returned_lot_count: int = 0
	## D6 (decision 0537): `order_evacuate_then_demolish()` recorded the building's intent. The
	## refusal that made it necessary stays in `error`, with its stranded lots, for the notice.
	var evacuation_ordered: bool = false
	var _lot_slot: PackedInt32Array = PackedInt32Array()
	var _lot_generation: PackedInt32Array = PackedInt32Array()

	func _init(lot_capacity: int) -> void:
		"""Size the stranded-lot columns once, to the lot store's own capacity."""
		_lot_slot.resize(lot_capacity)
		_lot_generation.resize(lot_capacity)
		reset()

	func reset() -> void:
		"""Clear every field before a request, so no number survives from an earlier one."""
		ok = false
		error = &""
		endpoint_owner_count = 0
		scanned_container_count = 0
		stranded_lot_count = 0
		stranded_quantity_milli = 0
		outstanding_reserved_mass_g = 0
		claiming_container_count = 0
		occupant_count = 0
		furniture_user_count = 0
		anchored_container_count = 0
		blocking_container = InventoryScript.NULL_REF
		project_ref = EntityDirectoryScript.NULL_REF
		output_container = InventoryScript.NULL_REF
		output_reserved_g = 0
		output_to_ground_piles = false
		destination_revision = 0
		blocking_furniture = EntityDirectoryScript.NULL_REF
		blocked_furniture_count = 0
		removed_furniture_count = 0
		destroyed_container_count = 0
		removed_room_count = 0
		returned_lot_count = 0
		evacuation_ordered = false

	func record_lot(lot_ref: Vector2i) -> void:
		"""Record one stranded lot ref. The count is the authority; the columns are the list."""
		if stranded_lot_count < _lot_slot.size():
			_lot_slot[stranded_lot_count] = lot_ref.x
			_lot_generation[stranded_lot_count] = lot_ref.y
		stranded_lot_count += 1

	func stranded_lot_at(index: int) -> Vector2i:
		"""The `index`th stranded lot ref, or Inventory's null ref when the index names none.

		These are INVENTORY-LOT refs, so the null ref is Inventory's, not the directory's.
		"""
		if index < 0 or index >= stranded_lot_count or index >= _lot_slot.size():
			return InventoryScript.NULL_REF
		return Vector2i(_lot_slot[index], _lot_generation[index])


# --- the settlement's stores (composed once in _init, never reallocated) ----------------------

var _residents: ResidentsScript = ResidentsScript.new()
var _priorities: PrioritiesScript = PrioritiesScript.new()
var _reservations: ReservationsScript = ReservationsScript.new()
var _directory: EntityDirectoryScript = null
var _needs: NeedsScript = null
var _schedule: ScheduleScript = null
var _jobs: JobsScript = null
var _work: WorkScript = null
var _commands: CommandsScript = null
var _dispatch: CommandDispatchScript = null
var _ecology: EcologyScript = null
var _rng: RngScript = null
var _crop_weather: CropWeatherScript = null
var _planner: JobPlannerScript = null
var _presentation: PresentationExtractScript = null
var _world: WorldInitScript = null
var _buildings: BuildingsScript = null
var _construction: ConstructionScript = null
var _inventory: InventoryScript = null
var _item_definitions: ItemDefinitionsScript = null
var _stock_age: StockAgeScript = null
## DEMO-CONTAIN-R01 #9's site and placement authority (decision 0532). Held STRONGLY here, for the
## node's whole life, because Inventory and Buildings hold it only weakly.
var _ground_piles: GroundPilesScript = null
## ADR1148: one existing-budget Gear and Carry owner; wiring creates no stock or tool instances.
var _gear: GearScript = null
var _haul_carry: HaulCarryScript = null
## ADR1149: one existing-reserve Session, retained before initialization so reentry cannot reset its stores.
var _underground_session: UndergroundSession = null
## Producer of the authored starter plan (decision 0184). Holds only its last refusal code.
var _starter_producer: StarterStructuresScript = StarterStructuresScript.new()
## ARCH-SYS-001's ONE authoritative pose store, bound to the SAME directory as the resident store.
## The renderer borrows it through `transforms()`; presentation never constructs a second one and
## never writes a simulation pose. Movement, when it is composed, becomes its sole per-tick writer.
var _transforms: TransformsScript = null

# --- the live-resident index ------------------------------------------------------------------

## Resident rows this system has attached settlement components to, ascending. `residents.gd`
## keeps the same list privately and publishes no accessor, and this task does not own that file,
## so the index is maintained here at the only two lifecycle points this system owns:
## `create_initial_settlement()` and `reset()`. It exists so the per-tick pass costs O(population)
## rather than a 512-row scan.
var _live_slots: PackedInt32Array = PackedInt32Array()
var _live_count: int = 0

# --- per-tick scratch (not simulation state) --------------------------------------------------

## Reused across ticks; each is consumed before the next call that writes it, and none escapes.
var _calendar: SimClockScript.Calendar = SimClockScript.Calendar.new(0)
var _read: IntMath.IntResult = IntMath.IntResult.new()
var _tick_result: WorkScript.TickResult = WorkScript.TickResult.new(false, REFUSE_NONE)
var _command_report: CommandDispatchScript.TickReport = CommandDispatchScript.TickReport.new()
var _ecology_day: EcologyScript.DayResult = EcologyScript.DayResult.new()
var _crop_day: CropWeatherScript.DayResult = CropWeatherScript.DayResult.new()
var _crop_hour: CropWeatherScript.HourResult = CropWeatherScript.HourResult.new()
var _stock_hour: StockAgeScript.HourResult = StockAgeScript.HourResult.new()
var _planner_result: IntMath.IntResult = IntMath.IntResult.new()
var _planner_day: JobPlannerScript.OpResult = null
## The 00:00 tick of the day boundary being run, located and PROVED once per boundary.
var _boundary_tick: int = 0
## REQ-SET-007 legs the most recent boundary executed, in execution order. Sized once in _init().
var _daily_legs: PackedInt32Array = PackedInt32Array()
var _daily_leg_count: int = 0
var _tick_timer: PerfTimerScript = PerfTimerScript.new()
## One reused stopwatch for every stage: each stage opens and closes it, so the cost is two
## `Time.get_ticks_usec()` calls per stage and no allocation at all.
var _stage_timer: PerfTimerScript = PerfTimerScript.new()
## Microseconds the most recent tick spent in each dispatched stage, and the running totals the
## means are taken over. Both sized once in _init(); neither is simulation state.
var _stage_usec: PackedInt64Array = PackedInt64Array()
var _stage_usec_total: PackedInt64Array = PackedInt64Array()
## How many times each stage has been MEASURED since the last reset(). One per tick per stage, so
## a stage that stopped being dispatched -- or whose window was closed against the wrong stage --
## is visible as a count that no longer matches `ticks_run()`.
var _stage_measured: PackedInt64Array = PackedInt64Array()

# --- observable counters ----------------------------------------------------------------------

var _ticks_run: int = 0
var _refused_tick_count: int = 0
var _refused_crop_hour_count: int = 0
var _refused_stock_hour_count: int = 0
var _refused_extract_count: int = 0
var _refused_planner_day_count: int = 0
var _planner_day_count: int = 0
var _tick_usec_total: int = 0
var _tick_usec_max: int = 0
var _assignment_count: int = 0
var _refused_assignment_count: int = 0
var _accepted_mwu_last_tick: int = 0
var _commands_committed_last_tick: int = 0
var _commands_refused_last_tick: int = 0
var _last_refusal: StringName = REFUSE_NONE
var _reported_refusal: bool = false

# --- STOCK-SEED-R01's integrity-fault ledger ---------------------------------------------------
#
# NINE SCALARS, NOT A PACKED COLUMN AND NOT A PER-ENTITY STORE. At most ONE stock integrity fault
# is open at a time, because the first one stops the simulation before a second hour can run, so
# there is nothing to index by. Nothing here is serialized: a save taken while the world is halted
# is a save of an unsafe world, and the save owner has no section for this (reported, not built).
#
# THE LIFETIMES, which are the whole of the exactly-once claim:
#   `_stock_fault_code`   REFUSE_NONE means no open fault. Set once at the raise; cleared ONLY by
#                         a retry that succeeded, or by `reset()`.
#   `_stock_fault_tick`   the HOUR CROSSING tick the fault belongs to, which is the tick the retry
#                         re-derives. Read only while a fault is open; `stock_fault_tick()`
#                         REFUSES rather than answering it when none is.
#   `_stock_retry_pending` the single retry entitlement. Armed at the raise for the hour-level
#                         class only, and CONSUMED BEFORE the attempt, so no repeat dispatch can
#                         spend it twice. It is keyed to the faulted transaction, not to a sweep
#                         or to a run: a later hour's fault is a DIFFERENT transaction and earns
#                         its own single retry, while the faulted hour never gets a second.
#   `_stock_fault_halted` set when no retry is left to make. Cleared only by `reset()`.
#   `_stock_pause_held`   this system has an unmatched CRITICAL hold outstanding.
var _stock_fault_code: StringName = REFUSE_NONE
var _stock_fault_tick: int = 0
var _stock_retry_pending: bool = false
var _stock_fault_halted: bool = false
var _stock_pause_held: bool = false
var _stock_fault_count: int = 0
var _stock_retry_count: int = 0
var _stock_retry_recovered_count: int = 0
var _stock_pause_refusal: StringName = REFUSE_NONE
## Reused so raising or clearing the pause allocates nothing, even at the worst moment.
var _submit_result: SchedulerEventsScript.SubmitResult = SchedulerEventsScript.SubmitResult.new()

## INIT-POSE-R01 placement scratch, sized once in `_init()`: the resident row holding each
## persistent id 1..12, and one reused Pose record for the post-placement read-back. Neither is
## simulation state and neither is touched on a tick path -- placement happens once per world.
var _assembly_slot: PackedInt32Array = PackedInt32Array()
var _assembly_pose: TransformsScript.Pose = TransformsScript.Pose.new()

## INV-GOODS-R01's demolition-gate scratch, allocated once in _init() and refilled per request.
## No tick stage reads or writes any of it: a demolition request is a cold destructive path.
## The pair buffer is sized from the lot store's OWN published maximum rather than from a
## number chosen here, because a smaller buffer would be a silent cap on how much stranded
## stock the gate can see, and the query refuses an undersized buffer rather than truncating.
var _demolition: DemolitionReport = null
var _demolition_pairs: PackedInt32Array = PackedInt32Array()
var _demolition_seen: PackedByteArray = PackedByteArray()
var _demolition_read: IntMath.IntResult = IntMath.IntResult.new()
## Decision 0534's stage-5 and admit scratch, same lifetime. The footprint mask is the one
## 16384-byte buffer decisions 0531 and 0532 told D4 to build for both the anchor query and the
## refund seeds; `_demolition_outside` is its complement, for the surviving-store scan.
var _demolition_footprint: PackedByteArray = PackedByteArray()
var _demolition_outside: PackedByteArray = PackedByteArray()
var _demolition_seeds: PackedInt32Array = PackedInt32Array()
var _demolition_seed_count: int = 0
var _demolition_keys: PackedInt32Array = PackedInt32Array()
var _demolition_milli: PackedInt64Array = PackedInt64Array()
var _demolition_specs: PackedInt64Array = PackedInt64Array()
var _demolition_spec_rows: int = 0
var _demolition_place: GroundPilesScript.PlaceResult = GroundPilesScript.PlaceResult.new()
## Decision 0536: the pantry store a removed shelf's capacity leaves, and how much (#3b). Set by
## the proof of the request that reads it; 0 g means the piece carries no pantry capacity.
var _removal_pantry_store: Vector2i = InventoryScript.NULL_REF
var _removal_pantry_g: int = 0
## The planned return's capacity charge in grams, from `_compile_return_specs()`: what admit
## records for every admission and the commit compares against (decision 0536). The report's
## `output_reserved_g` shows only grams actually reserved, so a pile plan reports 0 (review L1).
var _return_charge_g: int = 0
## The coordinator's per-building admission record and destination revision (decision 0534).
var _admissions: DemolitionAdmissionsScript = null
## D6 (decision 0537): the evacuation intents and the removal work Jobs' links.
var _demolition_work: DemolitionWorkScript = null
## D6: an admission since the last reconcile, so its work Job is posted before the next selection.
var _removal_work_dirty: bool = false
## D6: removal work Jobs this tick's work stage completed, committed once the stage's walk ends.
var _removal_jobs_finished: int = 0
## D6 diagnostics: deferred admits the hourly reconcile attempted (sources empty) and commits it
## retried (work done, commit pending). Counts, never authority.
var _evacuation_retry_count: int = 0
var _removal_commit_retry_count: int = 0


func _init() -> void:
	"""Compose the settlement stores once and size the live index; allocate nothing later.

	Every store is built here rather than at declaration because five of them borrow another:
	the residents store owns the directory and needs rows, the schedule reads those same needs,
	jobs read residents/priorities/schedule, work reads jobs, and the ecology stores take this
	settlement's directory and Job store so a forage claim validates its owning Job in the one
	directory every other settlement reference already lives in.
	"""
	_directory = _residents.directory()
	_needs = _residents.needs()
	_schedule = ScheduleScript.new(_needs)
	_jobs = JobsScript.new(_residents, _priorities, _schedule)
	_work = WorkScript.new(_jobs)
	_commands = CommandsScript.new(SimClockScript.new(), _directory)
	_dispatch = CommandDispatchScript.new(_commands, _residents, _priorities, _schedule, _jobs)
	_ecology = EcologyScript.new(_directory, _jobs)
	_rng = RngScript.new()
	_crop_weather = CropWeatherScript.new(_ecology, _rng)
	_planner = JobPlannerScript.new(_crop_weather.farming(), _jobs, _ecology.forage(),
		_ecology.orchard_hive())
	_presentation = PresentationExtractScript.new(_residents, _jobs, _dispatch,
		_ecology.forage(), _planner, _crop_weather.weather())
	_world = WorldInitScript.new(_directory, _ecology.resource_nodes(), _ecology.forage(),
		_ecology.fishing(), _rng, _crop_weather.farming(), _ecology.orchard_hive(), _jobs,
		_commands)
	_buildings = BuildingsScript.new(_directory)
	_construction = ConstructionScript.new(_buildings)
	_admissions = DemolitionAdmissionsScript.new(_directory)
	_demolition_work = DemolitionWorkScript.new(_jobs, _construction)
	_transforms = TransformsScript.new(_directory)
	_compose_stock_layer()
	_compose_ground_piles()
	_compose_equipment()
	_bind_ecology_to_commands()
	_size_index_and_scratch_columns()
	_assert_shared_contracts()
	_assert_assembly_row()


func _size_index_and_scratch_columns() -> void:
	"""ARCH-MEM-001: size every index and scratch column ONCE, here and nowhere else.

	Not one of these is resized, grown or reallocated afterwards -- a per-tick `resize()` is the
	allocation this architecture forbids, and `resolve_assembly_order_into()` REFUSES an
	undersized output column rather than quietly growing it.
	"""
	_live_slots.resize(ResidentsScript.RESIDENT_CAPACITY)
	_live_slots.fill(EntityDirectoryScript.NULL_SLOT)
	_daily_legs.resize(DAILY_LEG_CAPACITY)
	_daily_legs.fill(LEG_STOCK_AGE)
	_stage_usec.resize(TICK_STAGE_COUNT)
	_stage_usec_total.resize(TICK_STAGE_COUNT)
	_stage_measured.resize(TICK_STAGE_COUNT)
	_assembly_slot.resize(ASSEMBLY_COHORT_SIZE)
	_assembly_slot.fill(EntityDirectoryScript.NULL_SLOT)
	_demolition = DemolitionReport.new(InventoryScript.LOT_CAPACITY)
	_demolition_pairs.resize(_inventory.owner_query_cells())
	@warning_ignore("integer_division") _demolition_seen.resize(_inventory.owner_query_cells() / 2)
	_demolition_footprint.resize(_inventory.anchor_query_mask_bytes())
	_demolition_outside.resize(_inventory.anchor_query_mask_bytes())
	_demolition_seeds.resize(GroundPilesScript.REFUND_SEED_CAPACITY)
	_demolition_keys.resize(ConstructionScript.RETURN_LINE_CAPACITY)
	_demolition_milli.resize(ConstructionScript.RETURN_LINE_CAPACITY)


func _compose_stock_layer() -> void:
	"""Build the InventoryLot store, load its item catalog, and give ARCH-SYS-004 both.

	The catalog is loaded INTO this settlement's own inventory because `register_item()` is what
	gives a lot row a mass and a category; ARCH-SYS-004 then reads the same catalog for GDD
	§5.8's shelf lives. A catalog that fails to load leaves the stage refusing
	ITEM_CATALOG_NOT_BOUND by its own rule, which is visible in `stock_hour()`, rather than
	leaving this node to invent a shelf life.
	"""
	_inventory = InventoryScript.new()
	_item_definitions = ItemDefinitionsScript.new()
	_item_definitions.load_default(_inventory)
	_stock_age = StockAgeScript.new(_inventory, _item_definitions)
	_bind_seed_expiry_authority()


func _compose_ground_piles() -> void:
	"""Build decision 0532's composer and make it Inventory's site and Buildings' placement authority.

	Runs once, after the stock layer exists. Both bindings are wiring, not state: `clear()` on
	either store keeps them, so `reset()` does not rebind. A refused bind is fatal rather than
	silent, because an unbound composer would let a building cover a pile.
	"""
	_ground_piles = GroundPilesScript.new()
	@warning_ignore("assert_always_true")
	assert(EntityDirectoryScript.KIND_CAPACITY[EntityDirectoryScript.KIND_WORLD] == WORLD_TYPED_ROW + 1,
		"the World row is the directory's only row of its kind")
	if _ground_piles.bind_stores(_inventory, _buildings, _stock_age) \
			and _buildings.set_placement_authority(_ground_piles).ok:
		return
	_last_refusal = REFUSE_GROUND_PILES_BIND
	push_error("SettlementSystem could not bind the ground-pile composer")


func _compose_equipment() -> void:
	"""Bind the actual stock, residents, work and carry once; the existing boot still owns all seeding."""
	_gear = GearScript.new()
	_haul_carry = HaulCarryScript.new()
	if _gear.bind_equipment(_inventory, _directory, _residents).ok \
			and _work.bind_gear(_gear).ok \
			and _haul_carry.bind(_inventory, _reservations, _residents, _ground_piles):
		return
	_last_refusal = REFUSE_EQUIPMENT_BIND
	push_error("SettlementSystem could not bind the equipment and hauling owners")


func _bind_seed_expiry_authority() -> void:
	"""Give the lot store STOCK-SEED-R01's seed-consumer predicate. The wiring call, made once.

	`inventory.gd` publishes `set_seed_expiry_authority()` and `stock_age.gd` publishes
	`refuses_seed_consumption()`; both have existed and NOTHING called the setter, so the guard
	refused nothing in the running game -- an unbound store cannot identify a seed at all, so it
	had no lots to refuse rather than every lot. This is the one place that owns both
	collaborators, which is where the ruling puts the call.

	ORDER IS THE POINT. It runs at the end of `_compose_stock_layer()`: after the inventory, the
	item catalog and the aging stage exist, and before `_init()` returns -- so before any command,
	planner, work step or hourly pass can reach a lot. A refused bind is fatal rather than silent.

	`_clear_stock_layer()` does NOT rebind: `set_seed_expiry_authority()` is wiring, not simulation
	state, and `inventory.clear()` deliberately preserves it. Rebinding there would hide a store
	that had somehow lost its guard.
	"""
	var bound: InventoryScript.OpResult = _inventory.set_seed_expiry_authority(_stock_age)
	if bound.ok:
		return
	_last_refusal = REFUSE_SEED_AUTHORITY_BIND
	push_error("SettlementSystem could not bind the seed-expiry authority: %s" % bound.error)


func _bind_ecology_to_commands() -> void:
	"""Task 04.2's NAMED RUNTIME HANDOFF: give ARCH-SYS-002 the ecology stores it commits into.

	This one call is what stops DESIGNATE_ZONE and SET_POLICY refusing COMMAND_STORE_NOT_BOUND in
	the real game. It was deliberately absent while the ecology had nothing to advance and the
	world had no content; ARCH-SYS-005/006 now run and `world_init.gd` fills the world, so both
	reasons are gone. A refused bind is fatal rather than silent: the settlement would otherwise
	go on refusing every zone and policy edit while the HUD showed a running game.
	"""
	if _dispatch.bind_ecology(_ecology.forage(), _planner):
		return
	_last_refusal = REFUSE_ECOLOGY_BIND
	push_error("SettlementSystem could not bind the ecology to ARCH-SYS-002: %s"
		% _dispatch.last_refusal())


func _assert_assembly_row() -> void:
	"""Re-derive INIT-POSE-R01's authored table from the inherited geometry it was written against.

	The ruling states the row as literal numbers AND as a construction: the hall's south exterior
	apron, at §5.1's 2 m tile pitch and tile centre, on §5.1's land elevation. Transcribing the
	numbers alone would let the two drift apart silently, so both halves are checked here and the
	build fails loudly rather than spawning a cohort inside a wall.
	"""
	@warning_ignore("assert_always_true") assert(ASSEMBLY_FIRST_TILE_X == WorldInitScript.HALL_ORIGIN_X,
		"the row starts at the hall's own west edge")
	@warning_ignore("assert_always_true") assert(ASSEMBLY_TILE_Z == WorldInitScript.HALL_ORIGIN_Z + WorldInitScript.HALL_SIZE_Z,
		"and one tile SOUTH of its footprint, which occupies z=59..68")
	@warning_ignore("assert_always_true") assert(ASSEMBLY_COHORT_SIZE == WorldInitScript.HALL_SIZE_X
			and ASSEMBLY_COHORT_SIZE == ResidentsScript.INITIAL_POPULATION,
		"§5.1's twelve residents fill exactly one row of §5.9's twelve-tile-wide hall")
	assert(ASSEMBLY_FIRST_TILE_INDEX
			== WorldInitScript.tile_index_of(ASSEMBLY_FIRST_TILE_X, ASSEMBLY_TILE_Z),
		"the authored tile index must be z*128+x of the authored tile")
	@warning_ignore("assert_always_true") assert(ASSEMBLY_ROOT_X_STEP_UNITS == WorldInitScript.TILE_SIZE_UNITS,
		"adjacent roots are one tile pitch apart")
	assert(ASSEMBLY_FIRST_ROOT_X_UNITS
			== WorldInitScript.tile_center_x_units(ASSEMBLY_FIRST_TILE_X)
			and ASSEMBLY_ROOT_Z_UNITS == WorldInitScript.tile_center_z_units(ASSEMBLY_TILE_Z),
		"the authored roots are the authored tile's centre")
	@warning_ignore("assert_always_true") assert(ASSEMBLY_ROOT_Y_UNITS == WorldInitScript.LAND_Y_UNITS,
		"y is §5.1's authored land elevation, not a guessed ground height")


func _assert_shared_contracts() -> void:
	"""Prove the capacities and the season index this file reads out of other modules."""
	@warning_ignore("assert_always_true") assert(ResidentsScript.RESIDENT_CAPACITY == NeedsScript.RESIDENT_CAPACITY,
		"the resident and needs stores must share one row capacity")
	@warning_ignore("assert_always_true") assert(ResidentsScript.RESIDENT_CAPACITY == ScheduleScript.SCHEDULE_CAPACITY,
		"the schedule store must share the resident row capacity")
	@warning_ignore("assert_always_true") assert(ResidentsScript.RESIDENT_CAPACITY == PrioritiesScript.PRIORITY_CAPACITY,
		"the priorities store must share the resident row capacity")
	assert(SimClockScript.SEASON_NAMES.size() == SEASON_COUNT,
		"the calendar must publish exactly four seasons")
	@warning_ignore("assert_always_true") assert(SimClockScript.SEASON_NAMES[SEASON_WINTER] == "winter",
		"SEASON_WINTER must index the calendar's winter, which REQ-SET-143 hangs off")
	assert(_ecology.directory() == _directory,
		"the ecology stores must validate references through this settlement's one directory")
	assert(_crop_weather.directory() == _directory,
		"the crop and weather stores must validate references through that same directory")
	assert(_crop_weather.orchard_hive() == _ecology.orchard_hive(),
		"ARCH-SYS-006 must borrow ARCH-SYS-005's hives, not compose a second orchard store")
	assert(_crop_weather.rng() == _rng,
		"ARCH-SYS-006 must consume this settlement's one ARCH-RNG-002 stream set")
	@warning_ignore("assert_always_true") assert(DAILY_LEG_CAPACITY == LEG_PROGRESSION + 1,
		"the leg log must hold exactly REQ-SET-007's legs plus the season handover")
	assert(_planner.forage() == _ecology.forage(),
		"ARCH-SYS-009 must plan over ARCH-SYS-005's own HarvestZone store, not a second one")
	assert(_planner.jobs() == _jobs,
		"ARCH-SYS-009 must publish into the Job store ARCH-SYS-010 selects from")
	assert(_planner.hives() == _ecology.orchard_hive(),
		"R06-JOB-006's producer must service the hives ARCH-SYS-005 advances, not a private set")
	assert(_planner.farming() == _crop_weather.farming(),
		"ARCH-SYS-009 must service the FarmPlot rows ARCH-SYS-006 integrates")
	assert(_world.directory() == _directory,
		"REQ-SET-009's generator must allocate out of this settlement's one directory")
	assert(_buildings.directory() == _directory,
		"the Building/Room/Furniture store must share this settlement's one directory")
	assert(_construction.buildings() == _buildings and _construction.directory() == _directory,
		"REQ-SET-124's projects must act on THIS settlement's buildings and one directory")
	@warning_ignore("assert_always_true") assert(BuildingsScript.MAP_TILES_X == WorldInitScript.MAP_TILES_X
			and BuildingsScript.MAP_TILES_Z == WorldInitScript.MAP_TILES_Z,
		"the building tile maps and REQ-SET-009's ground map must index the same §5.1 grid")
	assert(TICK_STAGE_KEYS.size() == TICK_STAGE_COUNT,
		"every measured tick stage must name the ARCH-SYS system it dispatches")
	assert(_stage_usec.size() == TICK_STAGE_COUNT and _stage_usec_total.size() == TICK_STAGE_COUNT,
		"the per-stage measurement columns must hold exactly one entry per dispatched stage")


func _ready() -> void:
	"""Keep receiving frames through pauses, bind to the clock, and report readiness.

	The bind is what makes this the production caller of the core modules. A refused bind is
	reported loudly rather than swallowed: the settlement would otherwise sit inert while the
	HUD kept displaying a running game.
	"""
	process_mode = Node.PROCESS_MODE_ALWAYS
	if not GameManager.bind_simulation(run_tick, run_day_boundary):
		_last_refusal = REFUSE_CLOCK_BIND
		push_error("SettlementSystem could not bind to the clock: %s" % GameManager.last_refusal())
	print("[SettlementSystem] ready")


# --- lifecycle ---------------------------------------------------------------------------------

func create_generated_settlement(items: ItemDefinitionsScript,
		world_seed: int = WorldInitScript.TUTORIAL_WORLD_SEED) -> bool:
	"""REQ-SET-009 end to end: §5.1's cohort takes ids 1-12, then §5.1's world follows from 13.

	THE GAP THIS CLOSES. `world_init.gd` built the world and `create_initial_settlement()` built
	the population, and NOTHING CALLED BOTH -- so generating produced an empty world and booting
	produced a cohort with nowhere to stand. §5.1 states one initialization contract, not two, and
	this is the single operation that satisfies it.

	THE ORDER IS THE RULING'S (R-INIT-ID-001, decision 0075), AND IT IS THE REVERSE OF DECISION
	0071's. That decision recorded that `world_init._publish()` cleared the directory, forcing the
	world to be created first and leaving the cohort on ids 1714-1725 instead of §5.1's "IDs 1-12".
	The specification owner ruled that the clear is a reset BEFORE new-world allocation, not a
	second reset inside terrain publication. So this operation is now one transaction:

	  1. PREFLIGHT, changing nothing: the settlement must be empty, the seventeen resource ids must
	     bind, the world plan must stage and validate, and the cohort's own catalog, capacities and
	     opening-day weather must check out. Every refusal below is decided here.
	  2. ENTER THE TRANSACTION: `reset()` once -- stores, directory, allocators, command, job and
	     child state -- then seed the nine RNG streams, before any consumer draws.
	  3. ALLOCATE THE TWELVE RESIDENTS FIRST, in §5.1's cohort order, through the ordinary
	     directory allocator. They receive persistent ids 1-12 and Warden Rowan receives 1.
	  4. PUBLISH THE WORLD from the SAME continuing counter, so the first world entity is 13.
	     `publish_prepared()` clears and reseeds nothing.
	  5. MATERIALISE THE STARTER COLONY (INIT-C live apply, decision 0533): the World row, then
	     §5.9's seven buildings, four rooms and thirty-one furniture, from the same counter AFTER
	     the world, so R-INIT-ID-001's "first world entity is 13" still holds.

	ALLOCATE BEFORE CONSUME (decision 0059). A populated settlement refuses at step 1 and is
	byte-identical afterwards, which is how "a refused initialization retains the previous valid
	world" is honoured: the only world this can overwrite is one with nobody in it. See
	`_abandon_transaction()` for what an in-transaction failure can and cannot restore.
	"""
	if _residents.population() != 0:
		return _refuse(ResidentsScript.REFUSE_SETTLEMENT_NOT_EMPTY)
	if _world.is_published():
		return _refuse(REFUSE_WORLD_ALREADY_PUBLISHED)
	var built: WorldInitScript.RequestResult = WorldInitScript.bound_request(items, world_seed)
	if not built.ok:
		return _refuse(built.error)
	var planned: WorldInitScript.GenerateResult = _world.preflight(built.request)
	if not planned.ok:
		return _refuse(planned.error)
	var cohort: StringName = _refuse_cohort_preflight()
	if cohort == REFUSE_NONE and not _starter_producer.prepare_into(StarterStructuresScript.Plan.new()):
		cohort = _starter_producer.last_refusal()
	if cohort != REFUSE_NONE:
		_world.discard_prepared_plan()
		return _refuse(cohort)
	return _run_initialization_transaction()


func _refuse_cohort_preflight() -> StringName:
	"""The code blocking §5.1's cohort, or REFUSE_NONE -- read from live state, writing nothing.

	Ruling step 1 requires the cohort's capacity, catalog bindings and resources preflighted before
	the transaction opens, so that step 3 cannot fail after the reset has already emptied a world.
	Every check below reads state the reset does not change: compiled catalogs, fixed capacities,
	and the opening day's weather preconditions (§5.10's forced first spring, which draws nothing).
	"""
	if _residents.catalog_error() != "":
		return ResidentsScript.REFUSE_SPECIES_CATALOG
	for species: StringName in ResidentsScript.INITIAL_SPECIES:
		if not _residents.has_species(species):
			return ResidentsScript.REFUSE_UNKNOWN_SPECIES
	if ResidentsScript.INITIAL_POPULATION > ResidentsScript.RESIDENT_CAPACITY \
			or ResidentsScript.INITIAL_POPULATION > EntityDirectoryScript.RESIDENT_LIVING_CAP \
			or ResidentsScript.INITIAL_POPULATION > _directory.capacity_of_kind(
				EntityDirectoryScript.KIND_RESIDENT):
		return EntityDirectoryScript.REFUSAL_LIVING_CAP
	var template: IntMath.IntResult = _schedule.default_template_id()
	if not template.ok:
		return StringName(template.error)
	return _crop_weather.preflight_refusal_for(OPENING_CALENDAR_DAY,
		OrchardHiveScript.season_of_day(OPENING_CALENDAR_DAY))


func _run_initialization_transaction() -> bool:
	"""Ruling steps 2-5: reset once, seed, allocate the cohort, then publish the world with it.

	The cohort is allocated BEFORE the world so that §5.1's twelve residents take persistent ids
	1-12 out of §4.2's one id space; publication continues the same counter rather than restarting
	it. Any failure inside the transaction abandons the whole thing through
	`_abandon_transaction()`; nothing is published by halves.
	"""
	if not reset():
		_world.discard_prepared_plan()
		return false
	var seeded: StringName = _world.seed_prepared_streams()
	if seeded != REFUSE_NONE:
		return _abandon_transaction(seeded)
	if not create_initial_settlement():
		return _abandon_transaction(_last_refusal)
	if not _place_initial_cohort():
		return _abandon_transaction(_last_refusal)
	var published: WorldInitScript.GenerateResult = _world.publish_prepared()
	if not published.ok:
		return _abandon_transaction(published.error)
	var colony: StringName = _materialize_refusal()
	if colony != REFUSE_NONE:
		return _abandon_transaction(colony)
	_last_refusal = REFUSE_NONE
	return true


func _abandon_transaction(code: StringName) -> bool:
	"""Return the settlement to EMPTY, drop the staged plan, and report `code`.

	WHAT THIS RESTORES AND WHAT IT CANNOT. A settlement that held residents refused in the
	preflight and never reached the transaction, so no populated world can be lost here. A world
	with NO residents in it -- the only other thing the transaction can overwrite -- is not
	restored: rebuilding it would mean re-running generation, and a regenerated world is a
	different set of persistent ids rather than the same world back. The ruling's "reset-to-empty
	alone is insufficient when a valid world preceded it" is therefore satisfied by the preflight
	rather than by a rollback, and this limitation is named in decision 0075 rather than hidden.
	"""
	_world.discard_prepared_plan()
	reset()
	return _refuse(code)


func create_initial_settlement() -> bool:
	"""Spawn the GDD §5.1 starting cohort and attach every per-resident settlement row.

	All-or-nothing: a partial cohort, or a resident missing its schedule or job agent, would be a
	settlement that ticks some residents and not others. On any refusal the whole settlement is
	returned to empty and the reason is preserved in `last_refusal()`.

	There is deliberately NO second emptiness check here. `residents.spawn_initial_settlement()`
	already refuses a non-empty store, to protect §5.1's "IDs 1-12", and a copy of that rule here
	would be a second place for it to be stated and to drift. Its refusal is passed through.

	§5.1's "IDs 1-12" IS NOW LITERAL ON BOTH PATHS (R-INIT-ID-001). Called on a freshly reset
	settlement -- which is what `_run_initialization_transaction()` does, before the world is
	published -- the twelve spawns take the first twelve persistent ids out of §4.2's one id space,
	in cohort order, so Warden Rowan is id 1. Called on its own, as the cohort-only path the suite
	uses, it does the same thing over an empty directory.
	"""
	var spawned: ResidentsScript.OpResult = _residents.spawn_initial_settlement()
	if not spawned.ok:
		return _refuse(spawned.error)
	if not _attach_all_residents() or not _open_the_first_day():
		var code: StringName = _last_refusal
		reset()
		_last_refusal = code
		return false
	_last_refusal = REFUSE_NONE
	return true


# --- INIT-C live apply: the starter colony (DEMO-CONTAIN-R01 D3, decision 0533) ---------------

func materialize_starter_colony() -> bool:
	"""Create the World row and §5.9's starter colony in a settlement that has neither. All or nothing.

	THE CREATE BUTTON'S COLONY STEP. Boot runs the same body inside its own transaction, after
	`publish_prepared()`; UI-SET-103's Create publishes through its own session and calls this
	afterwards, so both routes place the same rows in the same order. A refusal found by the
	preflight changes nothing. A refusal after the first write -- unreachable while the preflight
	holds, because every later door is deterministic over an empty hall -- empties the settlement
	with its code kept, exactly as a cohort refusal does, rather than leave a partial colony.
	"""
	var code: StringName = _materialize_refusal()
	if code == REFUSE_NONE:
		_last_refusal = REFUSE_NONE
		return true
	if _directory.live_count(EntityDirectoryScript.KIND_WORLD) != 0 \
			and code != REFUSE_STARTER_COLONY_PRESENT:
		reset()
	return _refuse(code)


func _materialize_refusal() -> StringName:
	"""Preflight the plan and the empty site, then write: World row, binding, colony, re-read."""
	if _buildings.live_building_count() != 0 \
			or _directory.live_count(EntityDirectoryScript.KIND_WORLD) != 0:
		return REFUSE_STARTER_COLONY_PRESENT
	var plan: StarterStructuresScript.Plan = StarterStructuresScript.Plan.new()
	if not _starter_producer.prepare_into(plan):
		return _starter_producer.last_refusal()
	var code: StringName = StarterColonyScript.preflight_refusal(_buildings, plan,
		STARTER_UNLOCKED_MASK)
	if code != REFUSE_NONE:
		return code
	var world_row: Vector2i = _directory.create(EntityDirectoryScript.KIND_WORLD)
	if world_row == EntityDirectoryScript.NULL_REF:
		return _directory.last_refusal()
	if not _ground_piles.bind_world(world_row):
		return REFUSE_GROUND_PILE_WORLD_BIND
	var applied: StarterColonyScript.Applied = StarterColonyScript.Applied.new()
	code = StarterColonyScript.apply_into(_buildings, plan, STARTER_UNLOCKED_MASK, applied)
	if code != REFUSE_NONE:
		return code
	return StarterColonyScript.plan_mismatch_refusal(_buildings, plan, applied)


func starter_store_binding_into(out: StarterColonyScript.StoreBinding) -> bool:
	"""Answer #7's owners and #3a's anchors for EconomySystem, read back from the live buildings.

	`out` names the hall as the pantry's owner and the four open stockpiles, in plan order, as the
	material stores' owners, each anchored at its building's origin tile. Refuses -- `out`
	cleared -- unless that colony is standing. Cold path: it prepares one plan to read the origins.
	"""
	var plan: StarterStructuresScript.Plan = StarterStructuresScript.Plan.new()
	if not _starter_producer.prepare_into(plan):
		out.clear()
		return _refuse(_starter_producer.last_refusal())
	var code: StringName = StarterColonyScript.store_binding_into(_buildings, plan, out)
	if code != REFUSE_NONE:
		return _refuse(code)
	return true


func world_ref() -> Vector2i:
	"""The live World directory row, or the null ref before the starter colony is materialised."""
	return _directory.ref_of_slot(_directory.owner_slot_of_typed_row(
		EntityDirectoryScript.KIND_WORLD, WORLD_TYPED_ROW))


func ground_piles() -> GroundPilesScript:
	"""Decision 0532's ground-pile composer, bound to this settlement's stores and World row."""
	return _ground_piles


# --- INIT-POSE-R01: the authored starter placement ---------------------------------------------

func create_placed_cohort_on(target_world: WorldInitScript) -> bool:
	"""Spawn §5.1's cohort AND stand it on the apron of `target_world`'s prepared plan. All or nothing.

	THE CREATE BUTTON'S COHORT STEP. `UiWorldSession` prepares its own WorldInit and hands it
	here between its seed and its publish, which is exactly where the boot transaction places.
	Before this existed Create called `create_initial_settlement()` alone: INIT-POSE-R01's
	placement lived only in `_run_initialization_transaction()`, so Create left twelve living
	residents with no pose and the crowd drew none of them. Boot and Create now share ONE
	placement body; only the world it is proved against differs.

	A placement refusal empties the settlement, as a cohort refusal does, with its code kept.
	"""
	if not create_initial_settlement():
		return false
	if _place_initial_cohort_on(target_world):
		return true
	var code: StringName = _last_refusal
	reset()
	_last_refusal = code
	return false


func _place_initial_cohort() -> bool:
	"""The boot transaction's placement: this settlement's own prepared world.

	Kept as its own method because the suite overrides it to observe the instant of placement.
	"""
	return _place_initial_cohort_on(_world)


func _place_initial_cohort_on(target_world: WorldInitScript) -> bool:
	"""Stand §5.1's twelve on the hall's south apron, inside the generation transaction.

	VALIDATE EVERYTHING FIRST, THEN PLACE. The ruling is explicit that a failure on resident
	twelve cannot expose eleven placements, so no column is written until every identity, tile,
	terrain, elevation, clearing, footprint and prepared-resource check has passed for all twelve.
	There is no dynamic-growth fallback and no partial row.

	It runs against the PREPARED world -- after the cohort takes ids 1-12 and before
	`publish_prepared()` creates a single world entity -- so the ground it proves clear is the
	ground the world is about to be published onto.
	"""
	var code: StringName = _refuse_assembly_row_on(target_world)
	if code != REFUSE_NONE:
		return _refuse(code)
	for index: int in ASSEMBLY_COHORT_SIZE:
		var ref: Vector2i = _residents.ref_of(_assembly_slot[index])
		if not _transforms.place(ref, assembly_root_x_units(index), ASSEMBLY_ROOT_Y_UNITS,
				ASSEMBLY_ROOT_Z_UNITS, ASSEMBLY_YAW):
			return _refuse(REFUSE_POSE_TRANSFORM)
	return _verify_assembly_poses()


static func assembly_root_x_units(index: int) -> int:
	"""The authored root x of cohort index `index`, one 2 m tile pitch apart along the apron."""
	return ASSEMBLY_FIRST_ROOT_X_UNITS + ASSEMBLY_ROOT_X_STEP_UNITS * index


static func assembly_tile_index(index: int) -> int:
	"""The authored exterior tile index of cohort index `index`, ascending along one row."""
	return ASSEMBLY_FIRST_TILE_INDEX + index


func _refuse_assembly_row_on(target_world: WorldInitScript) -> StringName:
	"""Every INIT-POSE-R01 input against `target_world`, decided before the first write."""
	if target_world == null or not target_world.has_prepared_plan():
		return REFUSE_POSE_NO_PLAN
	var identities: StringName = _resolve_assembly_slots()
	if identities != REFUSE_NONE:
		return identities
	var ground: StringName = _refuse_assembly_ground()
	if ground != REFUSE_NONE:
		return ground
	return refuse_assembly_occupancy(target_world)


static func resolve_assembly_order_into(resident_store: ResidentsScript,
		out: PackedInt32Array) -> StringName:
	"""Map persistent ids 1..12 onto resident rows, refusing any cohort that is not exactly that.

	ASSIGNMENT IS BY PERSISTENT ID, NOT BY SLOT ORDER OR ITERATION ORDER. The row a resident
	occupies and the order the store happens to be walked in are both allocation details; the
	ruling orders the cohort by id, so the id -- and only the id -- indexes the apron. A missing,
	duplicated or out-of-range id refuses the whole placement rather than leaving one unplaced.

	STATIC AND STORE-INJECTED so an isolated fixture can hand it a cohort whose slot order and id
	order DISAGREE. On a fresh directory they never do -- ids are minted in slot order -- so a
	production-world test alone cannot tell this rule apart from `out[slot] = slot`.
	`out` must already be sized to ASSEMBLY_COHORT_SIZE; nothing is resized here.
	"""
	if resident_store == null or out.size() != ASSEMBLY_COHORT_SIZE:
		return REFUSE_POSE_IDENTITY
	if resident_store.living_count() != ASSEMBLY_COHORT_SIZE:
		return REFUSE_POSE_IDENTITY
	out.fill(EntityDirectoryScript.NULL_SLOT)
	for slot: int in ResidentsScript.RESIDENT_CAPACITY:
		if not resident_store.is_alive(slot):
			continue
		var persistent: IntMath.IntResult = resident_store.persistent_id_of(slot)
		if not persistent.ok or persistent.value < 1 or persistent.value > ASSEMBLY_COHORT_SIZE:
			return REFUSE_POSE_IDENTITY
		if out[persistent.value - 1] != EntityDirectoryScript.NULL_SLOT:
			return REFUSE_POSE_IDENTITY
		out[persistent.value - 1] = slot
	return REFUSE_NONE


func _resolve_assembly_slots() -> StringName:
	"""Resolve this settlement's cohort order, then prove every resolved row can hold a pose."""
	var order: StringName = resolve_assembly_order_into(_residents, _assembly_slot)
	if order != REFUSE_NONE:
		return order
	return _refuse_assembly_bindings()


func _refuse_assembly_bindings() -> StringName:
	"""Prove every resolved row has a live, positioned, derivable and unplaced Transform row."""
	for index: int in ASSEMBLY_COHORT_SIZE:
		var slot: int = _assembly_slot[index]
		if slot == EntityDirectoryScript.NULL_SLOT:
			return REFUSE_POSE_IDENTITY
		var ref: Vector2i = _residents.ref_of(slot)
		if not _directory.is_valid(ref) \
				or _directory.get_kind(ref) != EntityDirectoryScript.KIND_RESIDENT:
			return REFUSE_POSE_IDENTITY
		if not _transforms.transform_row_into(ref, _read):
			return REFUSE_POSE_TRANSFORM
		if _transforms.is_bound(ref):
			return REFUSE_POSE_TRANSFORM
	return REFUSE_NONE


func _refuse_assembly_ground() -> StringName:
	"""Check the twelve apron tiles against the map rules the prepared world was staged from.

	`world_init.gd`'s `_stage_masks()` writes the staged terrain, soil and CLEARED columns as
	`terrain_of()`, `soil_of()` and `is_cleared_tile()` of each coordinate, so calling those
	predicates here reads the prepared world's own rules rather than a second opinion copied out
	of the specification. Tiles are unique by construction and proved so: each index must be
	`8890 + i`, and distinct `i` cannot produce one index twice.
	"""
	for index: int in ASSEMBLY_COHORT_SIZE:
		var tile_x: int = ASSEMBLY_FIRST_TILE_X + index
		var tile: int = WorldInitScript.tile_index_of(tile_x, ASSEMBLY_TILE_Z)
		if tile != assembly_tile_index(index) or not WorldInitScript.is_tile_index(tile):
			return REFUSE_POSE_TILE
		if WorldInitScript.tile_center_x_units(tile_x) != assembly_root_x_units(index) \
				or WorldInitScript.tile_center_z_units(ASSEMBLY_TILE_Z) != ASSEMBLY_ROOT_Z_UNITS:
			return REFUSE_POSE_TILE
		if WorldInitScript.terrain_of(tile_x, ASSEMBLY_TILE_Z) != WorldInitScript.TERRAIN_LAND \
				or not WorldInitScript.is_walkable(tile_x, ASSEMBLY_TILE_Z):
			return REFUSE_POSE_TERRAIN
		if WorldInitScript.elevation_y_units_of(tile_x, ASSEMBLY_TILE_Z) != ASSEMBLY_ROOT_Y_UNITS:
			return REFUSE_POSE_TERRAIN
		if not WorldInitScript.is_cleared_tile(tile_x, ASSEMBLY_TILE_Z):
			return REFUSE_POSE_NOT_CLEARED
	return REFUSE_NONE


static func refuse_assembly_occupancy(target_world: WorldInitScript) -> StringName:
	"""Prove no static footprint and no PLANNED resource node stands on the apron row.

	The tree half reads the HELD PLAN -- `planned_tree_centre_at()` and `planned_grove_at()` are
	the tiles `publish_prepared()` is about to plant -- rather than the published store, which is
	still empty at this point in the transaction. One pass over at most 3100 planned tiles, once
	per generated world; `assembly_covers_tile()` makes each test O(1).

	STORE-INJECTED so a fixture can hand it a plan that DOES claim an apron tile. On the authored
	map that cannot happen -- the clear mask reserves the row and a planned tree requires uncleared
	ground -- so the refusing branch is unreachable through generation and would otherwise never
	be executed by any test at all.
	"""
	if target_world == null:
		return REFUSE_POSE_OCCUPIED
	for index: int in ASSEMBLY_COHORT_SIZE:
		var tile_x: int = ASSEMBLY_FIRST_TILE_X + index
		if WorldInitScript.is_starter_footprint_tile(tile_x, ASSEMBLY_TILE_Z):
			return REFUSE_POSE_OCCUPIED
		if _is_deposit_tile(tile_x, ASSEMBLY_TILE_Z):
			return REFUSE_POSE_OCCUPIED
	for index: int in target_world.planned_tree_centre_count():
		var centre: IntMath.IntResult = target_world.planned_tree_centre_at(index)
		if not centre.ok or assembly_covers_tile(centre.value):
			return REFUSE_POSE_OCCUPIED
	for index: int in target_world.planned_grove_count():
		var grove: IntMath.IntResult = target_world.planned_grove_at(index)
		if not grove.ok or assembly_covers_tile(grove.value):
			return REFUSE_POSE_OCCUPIED
	return REFUSE_NONE


static func assembly_covers_tile(tile: int) -> bool:
	"""True when an exterior tile index is one of the twelve authored apron tiles.

	`8890..8901` inclusive and nothing else. Public because it is the whole of the exclusion rule
	the occupancy scan applies, and a rule that only runs on tiles no world ever produces needs a
	direct test rather than an argument that it is equivalent to doing nothing.
	"""
	var offset: int = tile - ASSEMBLY_FIRST_TILE_INDEX
	return offset >= 0 and offset < ASSEMBLY_COHORT_SIZE


static func _is_deposit_tile(x: int, z: int) -> bool:
	"""True when (x,z) lies under either of decision 0029's two authored ore-deposit footprints."""
	return _in_deposit(x, z, ResourceNodesScript.STONE_DEPOSIT_ORIGIN_X,
			ResourceNodesScript.STONE_DEPOSIT_ORIGIN_Z) \
		or _in_deposit(x, z, ResourceNodesScript.IRON_DEPOSIT_ORIGIN_X,
			ResourceNodesScript.IRON_DEPOSIT_ORIGIN_Z)


static func _in_deposit(x: int, z: int, origin_x: int, origin_z: int) -> bool:
	"""True when (x,z) lies inside one 4x4 deposit footprint anchored at (origin_x, origin_z)."""
	var size: int = ResourceNodesScript.DEPOSIT_FOOTPRINT_SIZE
	return x >= origin_x and x < origin_x + size and z >= origin_z and z < origin_z + size


func _verify_assembly_poses() -> bool:
	"""Read all twelve poses back and refuse unless each is the authored pose with no history.

	`place()` writes previous = current, which is what makes a spawned resident interpolate to
	exactly where it stands instead of being dragged out of somewhere it has never been. That
	property is checked here rather than assumed, because a renderer cannot tell the difference
	on a still frame.
	"""
	for index: int in ASSEMBLY_COHORT_SIZE:
		var ref: Vector2i = _residents.ref_of(_assembly_slot[index])
		if not _transforms.read_into(ref, _assembly_pose):
			return _refuse(REFUSE_POSE_TRANSFORM)
		if _assembly_pose.x != assembly_root_x_units(index) \
				or _assembly_pose.y != ASSEMBLY_ROOT_Y_UNITS \
				or _assembly_pose.z != ASSEMBLY_ROOT_Z_UNITS \
				or _assembly_pose.yaw != ASSEMBLY_YAW:
			return _refuse(REFUSE_POSE_TRANSFORM)
		if not _assembly_pose.matches_previous():
			return _refuse(REFUSE_POSE_TRANSFORM)
	return true


func _open_the_first_day() -> bool:
	"""Write §5.1's opening day's §5.10 weather, because day 1 never reaches a midnight.

	The offset calendar starts at 06:00 of day 1 and its first crossing is day 2, so without this
	the first 18 game hours would read the cleared Weather row -- 0.0 C and no rain -- instead of
	spring. It consumes no WEATHER draw: year 1's spring is §5.10's forced onboarding event.
	"""
	if _crop_weather.prime_day(OPENING_CALENDAR_DAY):
		return true
	return _refuse(_crop_weather.last_refusal())


func _attach_all_residents() -> bool:
	"""Attach settlement components to every spawned resident row, in ascending slot order."""
	for slot: int in ResidentsScript.RESIDENT_CAPACITY:
		if not _residents.is_present(slot):
			continue
		if not _attach_resident(slot):
			return false
	return true


func _attach_resident(slot: int) -> bool:
	"""Give one resident its Priorities, Schedule and JobAgent rows, all-or-nothing.

	The schedule template is `schedule.gd`'s own `default_template_id()`. GDD §5.1 states no
	starting template for the cohort; that module says so in its header and publishes the §5.3
	default for exactly this caller, so the number is read from it rather than written here.
	"""
	var template: IntMath.IntResult = _schedule.default_template_id()
	if not template.ok:
		return _refuse(StringName(template.error))
	var priorities_result: PrioritiesScript.OpResult = _priorities.spawn(slot)
	if not priorities_result.ok:
		return _refuse(priorities_result.error)
	var schedule_result: ScheduleScript.OpResult = _schedule.spawn(slot, template.value)
	if not schedule_result.ok:
		_priorities.despawn(slot)
		return _refuse(schedule_result.error)
	var agent: JobsScript.OpResult = _jobs.spawn_agent(slot)
	if not agent.ok:
		_schedule.despawn(slot)
		_priorities.despawn(slot)
		return _refuse(agent.error)
	_live_slots[_live_count] = slot
	_live_count += 1
	return true


func mount_underground(content: UndergroundContent) -> bool:
	"""Compose the one actual foundation without seeding stock, duplicating a World or opening work."""
	if _underground_session != null:
		return _refuse(&"UNDERGROUND_SESSION_ALREADY_BOUND")
	_underground_session = UndergroundSession.new()
	var code: StringName = _underground_session.configure(_world, world_ref(), _buildings,
		_construction, _inventory, _item_definitions, _residents, _jobs, _work, _reservations,
		_transforms, _gear, _haul_carry, _ground_piles, content)
	if code != &"":
		_underground_session = null
		return _refuse(code)
	_last_refusal = REFUSE_NONE
	return true


func underground_session() -> UndergroundSession:
	"""Borrow the one foundation; its own current checks reject retired or partially configured state."""
	return _underground_session


func underground_content() -> UndergroundContent:
	"""Borrow the immutable loaded image for synchronous World replacement, never another palette allocation."""
	return _underground_session._content if _underground_session != null and _underground_session._ready else null


func prepare_world_reset(allow_prepared_world: bool = false) -> bool:
	"""Retire foundations before any caller clears Economy/Entity/settlement state; refusal writes none."""
	if _underground_session == null:
		return true
	var code: StringName = _underground_session.retire_foundation(allow_prepared_world)
	if code != &"":
		return _refuse(code)
	_underground_session = null
	return true


func reset(allow_prepared_world: bool = false) -> bool:
	"""Empty every settlement store, index and counter, without reallocating a column.

	`_clear_stores()`'s `residents.clear()` also clears the directory and needs rows, because this
	system built the residents store with neither collaborator supplied and it therefore owns both.
	"""
	if not prepare_world_reset(allow_prepared_world):
		return false
	_clear_stores()
	_release_critical_pause()
	_live_slots.fill(EntityDirectoryScript.NULL_SLOT)
	_live_count = 0
	_daily_leg_count = 0
	_boundary_tick = 0
	_clear_counters()
	return true


func _clear_stores() -> void:
	"""Empty every composed store in one place, so a store added later cannot be forgotten here."""
	_residents.clear()
	_priorities.clear()
	_schedule.clear()
	_jobs.clear()
	_work.clear()
	_gear.clear()
	_reservations.clear()
	_commands.clear()
	_dispatch.clear()
	_ecology.clear()
	_crop_weather.clear()
	_clear_stock_layer()
	_planner.clear()
	_presentation.clear()
	_world.clear()
	_buildings.clear()
	_construction.clear()
	_admissions.clear()
	_demolition_work.clear()
	_removal_work_dirty = false
	_removal_jobs_finished = 0
	_evacuation_retry_count = 0
	_removal_commit_retry_count = 0
	_transforms.reset()
	_rng.clear()


func _clear_stock_layer() -> void:
	"""Empty the lot store and every storage declaration, then re-register the item catalog.

	`inventory.clear()` drops the item registry as well as the rows -- it is the catalog-time
	half of the same store -- so a settlement reset without this reload would leave every lot
	operation refusing UNKNOWN_ITEM. Both generation spaces step forward inside `clear()`, so a
	lot or container ref taken before a reset still cannot validate after it.
	"""
	_inventory.clear()
	_item_definitions.load_default(_inventory)
	_stock_age.clear()


func _clear_counters() -> void:
	"""Return every observable counter and refusal to its pre-run value."""
	_ticks_run = 0
	_refused_tick_count = 0
	_refused_crop_hour_count = 0
	_refused_stock_hour_count = 0
	_refused_extract_count = 0
	_refused_planner_day_count = 0
	_planner_day_count = 0
	_tick_usec_total = 0
	_tick_usec_max = 0
	_stage_usec.fill(0)
	_stage_usec_total.fill(0)
	_stage_measured.fill(0)
	_assignment_count = 0
	_refused_assignment_count = 0
	_accepted_mwu_last_tick = 0
	_commands_committed_last_tick = 0
	_commands_refused_last_tick = 0
	_last_refusal = REFUSE_NONE
	_reported_refusal = false
	_clear_stock_integrity_fault()


func _clear_stock_integrity_fault() -> void:
	"""Drop STOCK-SEED-R01's fault ledger. Reached ONLY from `_clear_counters()`, i.e. `reset()`.

	This is the one and only exit from a halted simulation, and it is private for that reason:
	`reset()` empties every store, so the world the skipped hour would have corrupted no longer
	exists. A public "clear the fault" would let the faulted hour be skipped in a world that
	still contains the stock it failed to age, which is the correctness hole the halt closes.
	The CRITICAL hold is released by `reset()` BEFORE this runs, so the flag and the clock agree.
	"""
	_stock_fault_code = REFUSE_NONE
	_stock_fault_tick = 0
	_stock_retry_pending = false
	_stock_fault_halted = false
	_stock_fault_count = 0
	_stock_retry_count = 0
	_stock_retry_recovered_count = 0
	_stock_pause_refusal = REFUSE_NONE


# --- the tick ----------------------------------------------------------------------------------

func run_tick(tick_index: int) -> bool:
	"""Run one completed fixed tick through the §5 stages that have an implemented owner.

	`tick_index` is the index of the tick being committed, supplied by the clock through
	GameManager. No elapsed time, no delta and no speed reaches this function: at 2x and 4x it is
	called more often and does exactly the same work (REQ-SET-003, REQ-SET-011).
	"""
	if tick_index < 0:
		return _refuse(REFUSE_INVALID_TICK)
	if _stock_fault_halted:
		return _refuse_while_halted()
	_tick_timer.start()
	var ok: bool = _run_stages(tick_index)
	_record_tick_cost(_tick_timer.stop())
	return ok


func _refuse_while_halted() -> bool:
	"""Run no stage while STOCK-SEED-R01's integrity fault stands, and re-assert its pause.

	NOT a fabricated successful tick and not a skipped hour: the faulted hour is still owed, and
	running the remaining stages would advance needs, jobs and work over stock that never aged.
	The hold is re-submitted on every refused tick because CRITICAL is a SHARED bit -- the
	REQ-SET-008 overload ladder produces it too, and `acknowledge_without_catchup()` clears the
	whole bit -- so an unrelated acknowledgement costs one refused tick here instead of resuming
	an unsafe world. `submit_safety_hold_into()` coalesces an already-pending hold, so the repeat
	consumes no sequence and cannot fill the queue.
	"""
	_refused_tick_count += 1
	_hold_critical_pause()
	return _refuse(REFUSE_STOCK_INTEGRITY_HALT)


func _run_stages(tick_index: int) -> bool:
	"""ARCH-SYS-002, then 003, then 008/010, then 013, in the §5 table's order.

	CommandCommit is FIRST because §5 places it "after snapshot, before selectors" and no
	TransformSnapshot exists. A refused command does not stop the tick: the stage records the
	refusal against that command and the settlement keeps running, because one player edit
	failing is not a reason to stop integrating everybody's needs.
	"""
	_last_refusal = REFUSE_NONE
	_accepted_mwu_last_tick = 0
	_commit_commands(tick_index)
	if not _integrate_interval():
		_extract_presentation(tick_index)
		return false
	_age_stocks(tick_index)
	_integrate_crops(tick_index)
	_plan_jobs(tick_index)
	_select_jobs(tick_index)
	_run_productive_work()
	_extract_presentation(tick_index)
	return true


func _plan_jobs(tick_index: int) -> void:
	"""ARCH-SYS-009 JobPlanner: reconcile every dirty owner and this tick's staggered idle slice.

	R06-JOB-008 requires an owner's demand to be reconciled "before selection", and selection is
	the very next stage, so this sits between them. A refusal is recorded and not fatal: one
	unplannable owner is not a reason to discard a committed needs sweep.

	IT RUNS BEFORE ARCH-SYS-008's activity resolution rather than after it, which is one place
	off §5's table order. The two have no data dependency -- the planner reads FarmPlot rows and
	HarvestZone designations, and resolution reads needs and the hour -- and moving it after
	would split the fused resolve/select loop that keeps eligibility step 2 from seeing a stale
	hour. Named here rather than left for a reader to discover.
	"""
	_stage_timer.start()
	_reconcile_removal_work(tick_index)
	if not _planner.run_tick_into(tick_index, _planner_result):
		_last_refusal = StringName(_planner_result.error)
	_close_stage(TICK_STAGE_JOB_PLANNER)


func _extract_presentation(tick_index: int) -> void:
	"""ARCH-SYS-023 PresentationExtract: snapshot the committed tick. Writes no store, ever.

	LAST, because a snapshot taken before the final stage would show a tick that never existed.
	A refusal is recorded rather than fatal: a missed frame is a presentation fault, and the
	simulation it failed to photograph is still correct.
	"""
	_stage_timer.start()
	if not _presentation.capture(tick_index):
		_refused_extract_count += 1
	_close_stage(TICK_STAGE_PRESENTATION)


func _close_stage(stage: int) -> void:
	"""Close the open stage window and fold its cost into this tick's and the run's totals."""
	_stage_usec[stage] = _stage_timer.stop()
	_stage_usec_total[stage] += _stage_usec[stage]
	_stage_measured[stage] += 1


func _commit_commands(tick_index: int) -> void:
	"""ARCH-SYS-002 CommandCommit: drain and commit every player edit due at this tick."""
	_stage_timer.start()
	_commands_committed_last_tick = 0
	_commands_refused_last_tick = 0
	if not _dispatch.commit_tick_into(tick_index, _command_report):
		_last_refusal = _dispatch.last_refusal()
		_close_stage(TICK_STAGE_COMMAND_COMMIT)
		return
	_commands_committed_last_tick = _command_report.committed
	_commands_refused_last_tick = _command_report.refused
	_ensure_command_clock()
	_close_stage(TICK_STAGE_COMMAND_COMMIT)


func _ensure_command_clock() -> void:
	"""Keep the queue stamping `completed_tick+1` from the clock the game is really running on.

	`GameManager.start_game()` REPLACES its `SimClock` instance, so a queue bound once would go on
	reading a clock that had stopped moving and would stamp every later edit with a stale tick.
	The check is a reference comparison per tick and the rebind happens at most once per run.

	IT RUNS AFTER THE DRAIN AND ONLY ON AN EMPTY QUEUE, so no accepted command is ever discarded
	by it: records already in the queue were stamped against the OLD clock's numbering, and
	`commands.rebind_clock()` refuses to re-base them. They are committed at their own due tick
	first, and the rebind takes the next opportunity.
	"""
	var live: SimClockScript = GameManager.clock()
	if live == null or _commands.clock() == live or _commands.pending_count() != 0:
		return
	_commands.rebind_clock(live)


func _record_tick_cost(usec: int) -> void:
	"""Fold one measured tick duration into the running total, count and maximum."""
	_ticks_run += 1
	_tick_usec_total += usec
	if usec > _tick_usec_max:
		_tick_usec_max = usec


func _integrate_interval() -> bool:
	"""ARCH-SYS-003 IntervalIntegrator: one tick of needs, cold, health and status per resident.

	ARCH-SYS-017 CareHealth runs here too rather than in a stage of its own, because `needs.gd`
	integrates health, cold exposure and the incapacitation transitions inside the same sweep.
	A refusal names the row in `needs.last_refused_slot()` and stops the tick: a partial sweep
	must be visible, not averaged away.
	"""
	_stage_timer.start()
	var swept: NeedsScript.OpResult = _residents.tick_needs_all()
	_close_stage(TICK_STAGE_INTERVAL)
	if swept.ok:
		return true
	_refused_tick_count += 1
	_report_first_refusal(swept.error)
	return _refuse(swept.error)


func _age_stocks(tick_index: int) -> void:
	"""ARCH-SYS-004 StockAge, the HOURLY cadence its §5 row states, in the table's own position.

	FOURTH, after ARCH-SYS-003 and before ARCH-SYS-006, which is exactly where §5's table puts
	it. Running it here is also what makes REQ-SET-007's FIRST daily leg land before
	ARCH-TICK-003's season handover: at a midnight tick the clock calls `run_tick()` for that
	tick and only then `run_day_boundary()`, so the aging pass has already consumed the midnight
	crossing by the time the handover runs.

	The predicate is the only per-tick cost: 23 ticks in 24 are not an hour crossing and this
	returns immediately. A refusal is COUNTED rather than fatal, for the same reason as the crop
	hour -- the needs sweep for this tick has already committed.
	"""
	_stage_timer.start()
	_age_stock_hour(tick_index)
	_close_stage(TICK_STAGE_STOCK_AGE)


func _age_stock_hour(tick_index: int) -> void:
	"""The hourly aging pass, STOCK-SEED-R01's one revalidated retry, and its integrity fault.

	THE RETRY IS ATTEMPTED FIRST, AND AGAINST THE FAULTED TICK, NOT THIS ONE. A hold raised at
	the end of tick k stops the clock, so the first tick that reaches here after recovery is
	k+1 -- which is not an hour crossing -- while the hour still owed is k's. Running the retry
	before the predicate is what lets the correct hour be re-derived at the correct tick index,
	with the correct elapsed-interval season, no matter which tick carries it.
	"""
	if _stock_retry_pending and not _retry_stock_hour():
		return
	if not StockAgeScript.is_hour_boundary(tick_index):
		return
	if not _stock_age.run_hour_into(tick_index, _stock_hour):
		_note_stock_hour_refusal(tick_index)
		return
	_note_stock_hour_result(tick_index)


func _retry_stock_hour() -> bool:
	"""STOCK-SEED-R01's ONE revalidated retry of the SAME expiry transaction. True on recovery.

	EXACTLY ONCE, AND THE ENTITLEMENT IS SPENT BEFORE THE ATTEMPT, so a repeated dispatch or a
	re-entrant frame cannot spend it twice. It is keyed to the faulted TRANSACTION, not to a
	sweep counter: a fault at a later hour earns its own single retry, this one never gets two.

	REVALIDATED, NOT REPLAYED: nothing of the failed attempt is captured and re-applied.
	`run_hour_into()` re-runs `_preflight()`, re-resolves both catalog ids by key, re-decodes
	both calendars and re-reads every declared container and lot, so a fault still present
	refuses AGAIN rather than being papered over.

	IT ADDS NO AGE AND DUPLICATES NO SINK OR SOURCE: the hour-level class refuses inside
	`_preflight()`, before StockAge consumes its hour latch and before any container is swept.
	"""
	_stock_retry_pending = false
	_stock_retry_count += 1
	if not _stock_age.run_hour_into(_stock_fault_tick, _stock_hour):
		_refused_stock_hour_count += 1
		_last_refusal = _stock_hour.error
		_halt_stock_integrity()
		return false
	if _stock_hour.refused_lots > 0:
		_last_refusal = _stock_hour.last_lot_refusal
		_halt_stock_integrity()
		return false
	_stock_retry_recovered_count += 1
	_stock_fault_code = REFUSE_NONE
	_release_critical_pause()
	return true


func _note_stock_hour_refusal(tick: int) -> void:
	"""Count an hour that never ran, and raise the fault when it was a ledger or schema failure."""
	_refused_stock_hour_count += 1
	_last_refusal = _stock_hour.error
	if is_stock_integrity_refusal(_stock_hour.error):
		_raise_stock_integrity_fault(tick, _stock_hour.error, true)


func _note_stock_hour_result(tick: int) -> void:
	"""Classify a completed pass: a per-lot refusal is STOCK-SEED-R01's integrity fault too.

	Every path in `stock_age.gd` that increments `refused_lots` is a checked-arithmetic refusal,
	an inventory `begin()` refusal or a poisoned `commit()` -- exactly the ruling's "arithmetic,
	ledger or schema" set -- so the COUNT is the classification and no code list is invented
	here. Decision 0059 leaves the collaborating stores byte identical at each of them.
	"""
	if _stock_hour.refused_lots > 0:
		_raise_stock_integrity_fault(tick, _stock_hour.last_lot_refusal, false)


func _raise_stock_integrity_fault(tick: int, code: StringName, retryable: bool) -> void:
	"""Route one arithmetic, ledger or schema failure to the EXISTING critical-pause path.

	`retryable` is not re-derived from the code: the caller knows which boundary refused. An
	hour-level refusal happens inside `_preflight()`, before StockAge consumes its hour latch,
	so a whole untouched hour is owed and can be re-derived. A PER-LOT refusal has no retryable
	handle in this repository -- `stock_age.gd` reports `refused_lots` and `last_lot_refusal`
	and names no lot ref, and offers no per-lot expiry entry point -- so it halts at once. That
	is a named blocker in the accompanying decision record, not a judgement that a per-lot
	arithmetic failure deserves less than the ruling's retry.

	The first fault wins: a second raise while one is open would re-arm a retry the ruling
	allows exactly once.
	"""
	if _stock_fault_code != REFUSE_NONE:
		return
	_stock_fault_code = code
	_stock_fault_tick = tick
	_stock_fault_count += 1
	_hold_critical_pause()
	if retryable:
		_stock_retry_pending = true
		return
	_halt_stock_integrity()


func _halt_stock_integrity() -> void:
	"""Make the open fault unrecoverable in process: no further tick may run.

	STOCK-SEED-R01: "An unsafe partial world uses the existing recovery path, not a fabricated
	successful tick." Continuing would silently skip an hour of §5.8 aging, and there is no
	second retry to make, so every LATER `run_tick()` refuses with the pause still held.

	THE TICK THAT DECLARES THE HALT STILL COMMITS, exactly as the tick that raised the fault
	does: this stage is fourth, ARCH-SYS-003's needs sweep for this tick has already committed,
	and the queued hold takes effect at the barrier after the tick anyway. Discarding a
	committed sweep to make the refusal land one tick earlier would trade a real half-tick for
	a cosmetic one.

	THE ONLY EXIT IS `reset()` -- a new or loaded settlement. No "clear the fault" call is
	offered, deliberately: that would be the sentinel-shaped escape hatch that lets the skipped
	hour through after all, which is the exact hole this refusal exists to close.
	"""
	if _stock_fault_halted:
		return
	_stock_fault_halted = true
	_hold_critical_pause()
	push_error(("SettlementSystem: stock integrity fault '%s' at hour tick %d is unrecovered "
		+ "(retries attempted: %d); the simulation is halted until the settlement is reset.")
		% [_stock_fault_code, _stock_fault_tick, _stock_retry_count])


func _hold_critical_pause() -> void:
	"""Submit CRITICAL through R07-SCHED-001's queue: the one pause path this repository has.

	NOT A SECOND PAUSE CONCEPT AND NOT A DIRECT `set_pause()`. `sim_clock.gd` owns the reason
	mask and `scheduler_events.gd` owns its producers; a safety hold is reserve-eligible, so a
	queue full of ordinary traffic cannot swallow it, and an identical pending hold coalesces
	rather than consuming a sequence. Submitted from inside tick k the record is stamped k while
	the clock still reads k-1, so the barrier applies it AFTER k commits -- never midway through
	a tick, which is exactly why this does not pump the queue itself.
	A submission this system could not make is recorded in `stock_pause_refusal()`, never
	swallowed: believing a pause is held when it is not is worse than the fault.
	"""
	if not GameManager.scheduler_events().submit_safety_hold_into(
			SimClockScript.CRITICAL, _submit_result):
		_stock_pause_refusal = _submit_result.error
		return
	_stock_pause_refusal = REFUSE_NONE
	_stock_pause_held = true


func _release_critical_pause() -> void:
	"""Clear the CRITICAL hold this system placed, and only once its fault is verifiably gone.

	Reached from exactly one place -- a retry that re-derived the whole hour and committed it --
	because STOCK-SEED-R01 forbids clearing the pause while the failure stands.

	THE BIT IS SHARED AND THAT HAZARD IS REPORTED, NOT PATCHED FROM HERE. REQ-SET-008's overload
	ladder also produces CRITICAL and `sim_clock.gd` offers no sub-reason space or hold count, so
	this clear can lift an overload hold and `acknowledge_without_catchup()` can lift this one.
	A sub-reason space belongs to `sim_clock.gd`/`scheduler_events.gd`; what this file can do, and
	does, is re-assert the hold on every refused tick in `_refuse_while_halted()`.
	"""
	if not _stock_pause_held:
		return
	if not GameManager.scheduler_events().submit_pause_into(SimClockScript.CRITICAL,
			SimClockScript.CRITICAL, SchedulerEventsScript.VALUE_CLEAR, _submit_result):
		_stock_pause_refusal = _submit_result.error
		return
	_stock_pause_refusal = REFUSE_NONE
	_stock_pause_held = false


static func is_stock_integrity_refusal(code: StringName) -> bool:
	"""True when an HOUR-LEVEL StockAge refusal is STOCK-SEED-R01's ledger or schema fault class.

	The three are read from `stock_age.gd`'s own constants rather than written as strings here,
	and they are exactly the three `_preflight()` produces: an unbound lot store, a catalog that
	cannot answer §5.8's shelf lives or resolve spoiled_food and compost, and an inventory
	transaction somebody else left open. INVALID_TICK, NOT_AN_HOUR_BOUNDARY and
	HOUR_ALREADY_RUN are deliberately NOT here: they mean the hour was never owed, they change
	nothing, and pausing the game for a cadence refusal would be a fabricated integrity fault.
	"""
	return code == StockAgeScript.REFUSE_NO_INVENTORY \
		or code == StockAgeScript.REFUSE_NO_ITEM_CATALOG \
		or code == StockAgeScript.REFUSE_TRANSACTION_OPEN


func _integrate_crops(tick_index: int) -> void:
	"""ARCH-SYS-006 CropWeather, HOURLY half: one hour of §5.6 growth, frost and ripe expiry.

	The predicate is the only per-tick cost: 23 ticks in 24 are not an hour crossing and this
	returns immediately. A refusal is COUNTED rather than fatal -- the needs sweep for this tick
	has already committed, and one refused crop hour is not a reason to discard it -- and
	`crop_hour()` carries the reason on its own channel.
	"""
	_stage_timer.start()
	_integrate_crop_hour(tick_index)
	_close_stage(TICK_STAGE_CROP_HOUR)


func _integrate_crop_hour(tick_index: int) -> void:
	"""The hourly crop integration itself, so the measurement above stays one statement wide."""
	if not CropWeatherScript.is_hour_boundary(tick_index):
		return
	if _crop_weather.run_hour_into(tick_index, _crop_hour):
		return
	_refused_crop_hour_count += 1
	_last_refusal = _crop_hour.error


func _select_jobs(tick_index: int) -> void:
	"""ARCH-SYS-008 (activity resolution only) and ARCH-SYS-010 JobSelector.

	§5.3 reevaluates an idle resident every 30 ticks staggered by persistent ID mod 30, and
	`jobs.should_evaluate()` is that predicate -- allocation-free, and false for a resident who
	already holds a job. The activity is resolved immediately before the pass that reads it, so
	eligibility step 2 can never see a stale hour.
	"""
	_stage_timer.start()
	_resolve_and_select(tick_index)
	_close_stage(TICK_STAGE_SELECTION)


func _resolve_and_select(tick_index: int) -> void:
	"""The fused resolve/select pass: one resident is resolved immediately before it is offered."""
	var hour: int = _hour_of(tick_index)
	for index: int in _live_count:
		var slot: int = _live_slots[index]
		if not _jobs.should_evaluate(slot, tick_index):
			continue
		if not _residents.is_alive(slot):
			continue
		if not _schedule.resolve_into(slot, hour, PREPARED_MEAL_REACHABLE, _read):
			continue
		_offer_a_job(slot, tick_index)


func _offer_a_job(resident_slot: int, tick_index: int) -> void:
	"""Nominate one job for an idle resident and bind it if commitment revalidates.

	`evaluate()` returns a NOMINATION; `assign_worker()` re-runs the whole of eligibility before
	it binds. Both refusals are ORDINARY here and neither is an error: with no job source, every
	pass refuses NO_ELIGIBLE_JOB, which is the honest result of an empty queue.
	"""
	var nomination: JobsScript.OpResult = _jobs.evaluate(resident_slot, tick_index)
	if not nomination.ok:
		return
	var bound: JobsScript.OpResult = _jobs.assign_worker(resident_slot, nomination.value)
	if bound.ok:
		_assignment_count += 1
		return
	_refused_assignment_count += 1


func _run_productive_work() -> void:
	"""ARCH-SYS-013 ProductiveWork: one productive tick for every live activity that can take one.

	The walk is over live jobs rather than over workers, because a party must be ticked ONCE
	through its coordinator and a per-worker walk would tick it once per member.

	D6 (decision 0537): a removal work Job that completes here is committed only AFTER the walk,
	because the commit retires the Job's row and the walk is over the live-row index.
	"""
	_stage_timer.start()
	_removal_jobs_finished = 0
	for index: int in _jobs.job_count():
		var live: IntMath.IntResult = _jobs.live_job_at(index)
		if not live.ok:
			continue
		_tick_one_activity(live.value)
	if _removal_jobs_finished > 0:
		_finish_removal_jobs()
	_close_stage(TICK_STAGE_WORK)


func _tick_one_activity(job_slot: int) -> void:
	"""Tick one activity: a party through its coordinator, an ordinary job on its own row.

	A member row is skipped because decision 0017 keeps shared progress on the coordinator alone.
	A refusal is ordinary -- a job in TRAVEL, a job with no worker, a finished job -- and is not
	recorded as a fault; `work.gd` guarantees a refusal carries zero accepted work.

	A BUILD Job is worked ONLY through D6's removal bridge (decision 0537): its milli-WU belong to
	a construction project, and REQ-SET-124's build jobs for new construction do not exist, so a
	BUILD Job the bridge cannot resolve to its linked project is not ticked at all -- worked as an
	ordinary Job it would earn XP for work no project takes. The hourly reconcile retires it.
	"""
	if _jobs.is_member(job_slot):
		return
	if _jobs.is_coordinator(job_slot):
		if _work.tick_party_into(job_slot, _tick_result):
			_accepted_mwu_last_tick += _tick_result.accepted_mwu
		return
	if _jobs.kind_into(job_slot, _read) and _read.value == JobsScript.JOB_KIND_BUILD:
		var project: Vector2i = _demolition_work.project_of_job(job_slot)
		if project != EntityDirectoryScript.NULL_REF:
			_tick_removal_work(job_slot, project)
		return
	if _work.tick_solo_into(job_slot, _tick_result):
		_accepted_mwu_last_tick += _tick_result.accepted_mwu


func _hour_of(tick_index: int) -> int:
	"""Calendar hour 0-23 of the tick being committed, decoded into the reused Calendar.

	The hour of tick k, not of k-1: a schedule slot covers [h:00, h+1:00), so the first tick of
	an hour already belongs to the new slot. This is a per-tick reading of a static table, not an
	accumulated boundary effect, so ARCH-TICK-002's "never age twice at a crossing" does not
	apply to it.
	"""
	SimClockScript.calendar_at_into(tick_index, _calendar)
	return _calendar.hour


func run_day_boundary(absolute_day: int, season: int) -> bool:
	"""REQ-SET-007's daily boundary, in the requirement's own order, running the legs it owns.

	Age stocks (ARCH-SYS-004) is skipped first, then ARCH-TICK-003's season handover, then
	ARCH-SYS-005 Ecology; crops/weather, immigration/departures and progression are skipped after
	it, in that order, because they have no owner (header). Nothing is reordered and no unowned
	leg is faked: `daily_leg_at()` reports what actually ran.
	"""
	_daily_leg_count = 0
	if absolute_day <= 0:
		return _refuse(REFUSE_INVALID_DAY)
	if season < 0 or season >= SEASON_COUNT:
		return _refuse(REFUSE_INVALID_SEASON)
	if not _locate_boundary_tick(absolute_day, season):
		return false
	if not _age_stocks_leg():
		return false
	if not _apply_season_handover(season):
		return false
	if not _update_ecology():
		return false
	if not _advance_crops_and_weather():
		return false
	_run_planner_day()
	_last_refusal = REFUSE_NONE
	return true


func _locate_boundary_tick(absolute_day: int, season: int) -> bool:
	"""Find this day's 00:00 tick and PROVE it decodes back to the day and season handed in.

	The ecology stage is gated on a tick, and the clock hands this callback a day and a season,
	so the tick is recovered by `ecology.gd`'s inverse -- which is itself gated on
	`sim_clock.gd`'s `is_day_boundary()`, the single definition of a crossing -- and then decoded
	AGAIN through the calendar and compared. A wrong inverse, a caller inventing a day, or a
	season that does not belong to that day all refuse here rather than running the ecology stage
	on a tick that is not midnight. Day 1 opens at 06:00 and has no midnight, so it refuses.
	"""
	if not EcologyScript.midnight_tick_of_day_into(absolute_day, _read):
		return _refuse(StringName(_read.error))
	_boundary_tick = _read.value
	SimClockScript.calendar_at_into(_boundary_tick, _calendar)
	if _calendar.absolute_day != absolute_day or _calendar.season != season:
		return _refuse(REFUSE_CALENDAR_MISMATCH)
	return true


func _age_stocks_leg() -> bool:
	"""ARCH-SYS-004 StockAge: REQ-SET-007's FIRST leg, BEFORE ARCH-TICK-003's season handover.

	ARCH-TICK-002 forbids "a second age pass just because the same tick is both hourly and
	daily", and a midnight tick IS an hour crossing, so this does not age a second time: when
	`run_tick()` has already consumed this exact tick the leg is recorded and nothing else
	happens. It runs the pass itself only when nothing else has -- a boundary driven directly,
	with no tick path behind it -- so the leg is genuinely executed in either case rather than
	logged on trust.

	The pass reads the ELAPSED interval's season from the calendar itself, which is the other
	half of ARCH-TICK-003: aging must not see the new day's season, and `_apply_season_handover()`
	below is the very next statement.

	STOCK-SEED-R01 reaches this leg by the same two helpers the tick path uses, so a boundary
	driven with no tick path behind it raises the same integrity fault and the same one retry
	rather than a quieter refusal. A boundary run while the fault is already unrecoverable
	refuses before aging anything.
	"""
	if _stock_fault_halted:
		return _refuse(REFUSE_STOCK_INTEGRITY_HALT)
	if _stock_age.last_hour_tick() != _boundary_tick:
		if not _stock_age.run_hour_into(_boundary_tick, _stock_hour):
			_note_stock_hour_refusal(_boundary_tick)
			return _refuse(_stock_hour.error)
		_note_stock_hour_result(_boundary_tick)
	_record_daily_leg(LEG_STOCK_AGE)
	return true


func _apply_season_handover(season: int) -> bool:
	"""ARCH-TICK-003's handover between aging and ecology: REQ-SET-143's winter multiplier."""
	var applied: ResidentsScript.OpResult = _residents.set_winter(season == SEASON_WINTER)
	if not applied.ok:
		return _refuse(applied.error)
	_record_daily_leg(LEG_SEASON_HANDOVER)
	return true


func _update_ecology() -> bool:
	"""ARCH-SYS-005 Ecology: REQ-SET-007's second leg, on the new calendar day (ARCH-TICK-003).

	One call. Fish recovery and the daily fishing quota reset, forage regrowth and decision 0030
	§4.4's quota midnight, every live hive's completed day, and the resource nodes whose regrowth
	date has arrived -- all inside `ecology.gd`, which refuses a replayed day rather than
	applying it twice.
	"""
	if not _ecology.run_day_into(_boundary_tick, _ecology_day):
		return _refuse(_ecology_day.error)
	_record_daily_leg(LEG_ECOLOGY)
	return true


func _advance_crops_and_weather() -> bool:
	"""ARCH-SYS-006 CropWeather, MIDNIGHT half: REQ-SET-007's third leg, after ARCH-SYS-005's.

	The eligibility crossings ARCH-SYS-005 just committed are handed straight over: `ecology.gd`
	refreshed the ORCHARD side of decision 0044's pollination links inside `orchard_hive.gd`, and
	the FARM side needs the plot->tile join only ARCH-SYS-006 can make. Nothing runs between the
	two legs, so that refresh is still synchronous with the change that caused it.
	"""
	if not _crop_weather.run_day_into(
			_boundary_tick, _ecology_day.hive_eligibility_crossings, _crop_day):
		return _refuse(_crop_day.error)
	_record_daily_leg(LEG_CROP_WEATHER)
	return true


func _run_planner_day() -> void:
	"""ARCH-SYS-009's own daily maintenance. NOT a sixth REQ-SET-007 leg, and not logged as one.

	REQ-SET-007 names five legs and job planning is not among them, so this is deliberately
	absent from `daily_leg_at()`: putting it there would make the leg log claim a requirement
	step that the requirement does not contain. What it does is the planner's own midnight --
	settle yesterday's unserved daily services, then mark every owner and every designation dirty
	so the next tick reconciles against the new day's quota. It runs AFTER ARCH-SYS-005 reset
	those quotas, because released quota is R06-JOB-002's trigger and reconciling before the
	reset would find nothing released.

	A refusal is COUNTED, not fatal: the day's ecology and crop legs have already committed.
	"""
	_planner_day = _planner.run_day_boundary(_boundary_tick)
	if _planner_day.ok:
		_planner_day_count += 1
		return
	_refused_planner_day_count += 1
	_last_refusal = REFUSE_PLANNER_DAY


func _record_daily_leg(leg: int) -> void:
	"""Append one executed REQ-SET-007 leg to this boundary's order log."""
	_daily_legs[_daily_leg_count] = leg
	_daily_leg_count += 1


# --- readers -----------------------------------------------------------------------------------

func population() -> int:
	"""Resident rows this settlement holds, including a row whose resident has died."""
	return _live_count


func living_count() -> int:
	"""Residents the needs store still counts as living."""
	return _residents.living_count()


func job_queue_length() -> int:
	"""Live Job rows. Zero until something creates a job; nothing in this milestone does."""
	return _jobs.job_count()


func ticks_run() -> int:
	"""Settlement ticks executed since the last reset(), refused ticks included."""
	return _ticks_run


func refused_tick_count() -> int:
	"""Ticks whose interval integration refused, so a partial sweep is never silent."""
	return _refused_tick_count


func assignment_count() -> int:
	"""Workers bound to a job by the selection stage since the last reset()."""
	return _assignment_count


func refused_assignment_count() -> int:
	"""Nominations that failed revalidation at the commitment point since the last reset()."""
	return _refused_assignment_count


func accepted_mwu_last_tick() -> int:
	"""Milli-work-units accepted across every activity during the most recent tick."""
	return _accepted_mwu_last_tick


func last_tick_usec() -> int:
	"""Measured duration of the most recent settlement tick, in host microseconds."""
	return _tick_timer.get_last_usec()


func max_tick_usec() -> int:
	"""Longest measured settlement tick since the last reset(), in host microseconds."""
	return _tick_usec_max


func mean_tick_usec() -> IntMath.IntResult:
	"""Mean measured tick duration in microseconds; REFUSES before the first tick.

	A mean over zero ticks has no value, and answering 0 would be a measurement-shaped sentinel.
	"""
	var out: IntMath.IntResult = IntMath.IntResult.new()
	if _ticks_run <= 0:
		out.refuse(String(REFUSE_NO_TICK_MEASURED))
		return out
	IntMath.floor_div_into(_tick_usec_total, _ticks_run, out)
	return out


func is_winter() -> bool:
	"""True while REQ-SET-143's winter hunger multiplier is in force."""
	return _residents.is_winter()


func daily_leg_count() -> int:
	"""REQ-SET-007 legs the most recent day boundary actually executed; 0 before the first."""
	return _daily_leg_count


func daily_leg_at(index: int) -> IntMath.IntResult:
	"""The `index`-th leg the most recent boundary executed, in execution order, or a refusal.

	A refusal rather than a sentinel: "no leg ran" and "leg 0 ran" are different answers and a
	returned 0 would be indistinguishable from LEG_STOCK_AGE, which this system never runs.
	"""
	var out: IntMath.IntResult = IntMath.IntResult.new()
	if index < 0 or index >= _daily_leg_count:
		out.refuse(String(REFUSE_INVALID_INDEX))
		return out
	out.succeed(_daily_legs[index])
	return out


func last_ecology_day() -> int:
	"""Absolute day ARCH-SYS-005 last consumed; 0 before the first midnight. See `ecology.gd`."""
	return _ecology.last_day_run()


func ecology_day() -> EcologyScript.DayResult:
	"""The most recent ecology day's counts. Inspect `.ok` before any field; see `ecology.gd`."""
	return _ecology_day


func crop_weather() -> CropWeatherScript:
	"""ARCH-SYS-006's crop and weather stores. A world generator places its plots here."""
	return _crop_weather


func farming() -> FarmingScript:
	"""The §4.2 FarmPlot store and §2's TileHistory ledger, composed under ARCH-SYS-006."""
	return _crop_weather.farming()


func weather() -> WeatherScript:
	"""The §4.2 single Weather row this settlement schedules and refreshes."""
	return _crop_weather.weather()


func rng() -> RngScript:
	"""The settlement's one ARCH-RNG-002 stream set. UNSEEDED until a world generator seeds it."""
	return _rng


func crop_weather_day() -> CropWeatherScript.DayResult:
	"""The most recent crop/weather day. Inspect `.ok` before any field; see `crop_weather.gd`."""
	return _crop_day


func crop_hour() -> CropWeatherScript.HourResult:
	"""The most recent hourly crop integration. Inspect `.ok` before any field."""
	return _crop_hour


func refused_crop_hour_count() -> int:
	"""Hour crossings whose crop integration refused, so a skipped hour is never silent."""
	return _refused_crop_hour_count


func stock_age() -> StockAgeScript:
	"""ARCH-SYS-004's aging stage. A building layer declares its storage classes here."""
	return _stock_age


func inventory() -> InventoryScript:
	"""The settlement's own InventoryLot/InventoryContainer store, the one ARCH-SYS-004 ages."""
	return _inventory


func item_definitions() -> ItemDefinitionsScript:
	"""The §4.3 item catalog registered into this settlement's inventory."""
	return _item_definitions


func stock_hour() -> StockAgeScript.HourResult:
	"""The most recent hourly aging pass. Inspect `.ok` before any field."""
	return _stock_hour


func refused_stock_hour_count() -> int:
	"""Hour crossings whose aging pass refused, so a skipped hour is never silent."""
	return _refused_stock_hour_count


func stock_integrity_fault() -> StringName:
	"""The open STOCK-SEED-R01 fault's refusal code, or REFUSE_NONE while none is open.

	REFUSE_NONE is the ABSENCE of a fault, not a fault whose reason is unknown: every raise
	carries the owning module's own code, so this never answers an invented string.
	"""
	return _stock_fault_code


func stock_integrity_fault_tick() -> IntMath.IntResult:
	"""The hour crossing the open fault belongs to. REFUSES when no fault is open.

	It refuses rather than answering 0 or -1, because tick 0 is a real tick and a sentinel here
	would be read as "the fault is at the start of the game".
	"""
	var out: IntMath.IntResult = IntMath.IntResult.new()
	if _stock_fault_code == REFUSE_NONE:
		out.refuse(String(REFUSE_STOCK_NO_FAULT))
		return out
	out.succeed(_stock_fault_tick)
	return out


func is_stock_integrity_halted() -> bool:
	"""True while a stock integrity fault has outlived its one retry and every tick refuses."""
	return _stock_fault_halted


func is_stock_retry_pending() -> bool:
	"""True while the faulted hour's ONE revalidated retry is still owed and unspent."""
	return _stock_retry_pending


func stock_integrity_fault_count() -> int:
	"""Stock integrity faults raised since the last reset()."""
	return _stock_fault_count


func stock_retry_count() -> int:
	"""Retries ATTEMPTED since the last reset(). Never exceeds the faults raised."""
	return _stock_retry_count


func stock_retry_recovered_count() -> int:
	"""Retries that re-derived the faulted hour and committed it, clearing the pause."""
	return _stock_retry_recovered_count


func is_critical_pause_held() -> bool:
	"""True while this system holds an unmatched CRITICAL hold on the shared pause mask."""
	return _stock_pause_held


func stock_pause_refusal() -> StringName:
	"""Why the most recent CRITICAL hold or clear could not be submitted, or REFUSE_NONE."""
	return _stock_pause_refusal


func refused_extract_count() -> int:
	"""Ticks whose ARCH-SYS-023 snapshot refused, so a missed frame is never silent."""
	return _refused_extract_count


func refused_planner_day_count() -> int:
	"""Midnights whose ARCH-SYS-009 maintenance refused, so a skipped one is never silent."""
	return _refused_planner_day_count


func planner_day_count() -> int:
	"""Midnights on which ARCH-SYS-009's own daily maintenance actually ran and succeeded.

	Counted rather than assumed: with no FarmPlot and no designation the planner's midnight has
	nothing visible to do, so "it ran" would otherwise be indistinguishable from "it was skipped".
	"""
	return _planner_day_count


func tick_stage_measured_count(stage: int) -> IntMath.IntResult:
	"""How many times one stage has been measured since the last reset().

	Every dispatched stage closes its window exactly once per tick, so this equals `ticks_run()`
	for every stage. A stage that stopped being dispatched, or whose window was closed against
	another stage's index, shows up here as a count that no longer matches.
	"""
	var out: IntMath.IntResult = IntMath.IntResult.new()
	if not is_tick_stage(stage):
		out.refuse(String(REFUSE_INVALID_INDEX))
		return out
	out.succeed(_stage_measured[stage])
	return out


func job_planner() -> JobPlannerScript:
	"""ARCH-SYS-009's producer. The store DESIGNATE_ZONE enables standing demand in."""
	return _planner


func presentation() -> PresentationExtractScript:
	"""ARCH-SYS-023's read-only snapshot. It exposes no store and can write to none."""
	return _presentation


func tick_stage_count() -> int:
	"""How many §5 stages this node measures on the tick path."""
	return TICK_STAGE_COUNT


func is_tick_stage(stage: int) -> bool:
	"""True when this index names one of the measured tick stages."""
	return stage >= 0 and stage < TICK_STAGE_COUNT


func tick_stage_name(stage: int) -> StringName:
	"""The ARCH-SYS system a measured stage dispatches, or the empty name for an unknown index."""
	if not is_tick_stage(stage):
		return REFUSE_NONE
	return TICK_STAGE_KEYS[stage]


func tick_stage_usec_at(stage: int) -> IntMath.IntResult:
	"""Microseconds the MOST RECENT tick spent in one stage, or a refusal for an unknown index.

	A measurement, not a budget: nothing here compares it to REQ-SET-163, which is stated for 256
	residents on a named machine that this has not been run on.
	"""
	var out: IntMath.IntResult = IntMath.IntResult.new()
	if not is_tick_stage(stage):
		out.refuse(String(REFUSE_INVALID_INDEX))
		return out
	out.succeed(_stage_usec[stage])
	return out


func mean_tick_stage_usec(stage: int) -> IntMath.IntResult:
	"""Mean microseconds per tick in one stage since the last reset(). REFUSES before tick one.

	A mean over zero ticks has no value, and 0 would be a measurement-shaped sentinel -- the same
	rule `mean_tick_usec()` follows.
	"""
	var out: IntMath.IntResult = IntMath.IntResult.new()
	if not is_tick_stage(stage):
		out.refuse(String(REFUSE_INVALID_INDEX))
		return out
	if _ticks_run <= 0:
		out.refuse(String(REFUSE_NO_TICK_MEASURED))
		return out
	IntMath.floor_div_into(_stage_usec_total[stage], _ticks_run, out)
	return out


func last_refusal() -> StringName:
	"""Reason the most recent refused operation was refused; empty after a successful one."""
	return _last_refusal


func directory() -> EntityDirectoryScript:
	"""The allocator behind every settlement reference."""
	return _directory


func ecology() -> EcologyScript:
	"""ARCH-SYS-005's four stores. A world generator and ARCH-SYS-006 reach the ecology here."""
	return _ecology


func residents() -> ResidentsScript:
	"""The settlement's population. EconomySystem BORROWS this as its food-days divisor."""
	return _residents


func needs() -> NeedsScript:
	"""The GDD §5.2 needs, health and cold store, shared with the residents store."""
	return _needs


func priorities() -> PrioritiesScript:
	"""The per-resident job priority and work-policy store."""
	return _priorities


func schedule() -> ScheduleScript:
	"""The 24-hour schedule store and its §5.3 activity resolution."""
	return _schedule


func jobs() -> JobsScript:
	"""The Job and JobAgent store and its §5.3 selection pass."""
	return _jobs


func work() -> WorkScript:
	"""The §5.2 work-unit model and decision 0017's party acceptance."""
	return _work


func gear() -> GearScript:
	"""The one Gear owner sharing this settlement's Inventory, Directory, Residents and Work."""
	return _gear


func haul_carry() -> HaulCarryScript:
	"""The one carry service over the real stock, claims, resident satchels and finite ground piles."""
	return _haul_carry


func commands() -> CommandsScript:
	"""ARCH-CMD-001's ordered next-tick queue. A UI submits here; nothing else edits the stores."""
	return _commands


func command_dispatch() -> CommandDispatchScript:
	"""ARCH-SYS-002's commit stage, WITH the ecology bound: all seven implemented kinds commit here.

	`_bind_ecology_to_commands()` calls `bind_ecology()` during composition, so DESIGNATE_ZONE and
	SET_POLICY reach `forage.gd` and `job_planner.gd` instead of refusing COMMAND_STORE_NOT_BOUND.
	The other seventeen ARCH-CMD-003 kinds still refuse COMMAND_UNSUPPORTED_FEATURE and name the
	store they are waiting for.
	"""
	return _dispatch


func commands_committed_last_tick() -> int:
	"""Player commands committed by the most recent CommandCommit stage."""
	return _commands_committed_last_tick


func commands_refused_last_tick() -> int:
	"""Player commands the most recent CommandCommit stage refused, with a documented result id."""
	return _commands_refused_last_tick


func world() -> WorldInitScript:
	"""REQ-SET-009's generator, composed over this settlement's own stores.

	`is_published()` on it answers whether a world has been generated, and its tile readers answer
	what is under a tile. It is a reader here: `create_generated_settlement()` is the only thing
	in this node that calls `generate()`.
	"""
	return _world


func reservations() -> ReservationsScript:
	"""The global reservation pool. Empty: no job exists to claim an input (header)."""
	return _reservations


func buildings() -> BuildingsScript:
	"""GDD §4.2's Building, Room and Furniture rows, over THIS settlement's one directory.

	A generated settlement holds §5.9's starter colony: seven buildings, four rooms and thirty-one
	furniture (decision 0533). Every placement allocates out of the same allocator every other
	settlement reference lives in, so a `Furniture.user` can name a resident this store's
	`residents()` owns and the mask, the tile maps and the directory cannot disagree.
	"""
	return _buildings


func transforms() -> TransformsScript:
	"""ARCH-SYS-001's ONE authoritative pose store, bound to this settlement's one directory.

	THE SETTLEMENT OWNS IT; PRESENTATION BORROWS IT. `resident_stage.gd` takes this exact object
	and reads it through `presentation_interpolate_into()`, which fills a caller-owned float
	record and can change no authoritative field. No renderer may construct a second
	`transforms.gd`: an authoritative-size private pose store is 3151872 bytes of duplicate state
	and a second answer to where a resident is. When movement is composed it becomes the sole
	per-tick writer of this same instance, under ARCH-SYS-001's single-writer discipline.
	"""
	return _transforms


func construction() -> ConstructionScript:
	"""REQ-SET-124-128/137's project lifecycle, over THIS settlement's one Building store.

	Empty until something places a blueprint and opens a project: composition is not construction,
	and the starter colony stands ACTIVE with no project behind it. What the composition buys
	is that `Building.construction` and this store's rows name each other through the same
	allocator, so a project cannot outlive, or be orphaned by, the building it is building.
	"""
	return _construction


# --- REQ-SET-128: the composed demolition gate (INV-GOODS-R01) ---------------------------------

func request_demolition(building_ref: Vector2i) -> DemolitionReport:
	"""REQ-SET-128's composed gate, then blocker 1's *admit*, in one call with no yield.

	`preview_demolition()` runs first and decides everything a refusal can depend on in the
	affected stores. Only when it passes does *admit* run (decision 0534): it proves the store
	transition, the return's output capacity and the admission record can all be written BEFORE
	its first write, then reserves the capacity, publishes the demolition project (BUILD-C4-R01's
	snapshot is taken inside that same write) and advances the building's destination revision.

	`report.ok` means a demolition project now exists and the building is DEMOLISHING. Every
	refusal -- the preview's or admit's -- leaves Building, Construction, Inventory, the directory
	and the admission record byte-identical. Removing the building is D5's composed completion.

	D6 (decision 0537): an admission satisfies any "evacuate, then demolish" order on the
	building, and its BUILD work Job is posted by the next reconcile, before the next selection.
	"""
	preview_demolition(building_ref)
	if not _demolition.ok:
		return _demolition
	var code: StringName = _admit_demolition(building_ref)
	_demolition.error = code
	_demolition.ok = code == REFUSE_NONE
	if _demolition.ok:
		_demolition_work.drop_intent(building_ref)
		_removal_work_dirty = true
	return _demolition


func preview_demolition(building_ref: Vector2i) -> DemolitionReport:
	"""REQ-SET-128 in full, read-only: prove the endpoints, then recheck goods, occupants, footprint.

	CHANGES NOTHING ON ANY PATH: the five stages run in the header's order and stop at the first
	refusal, and the occupant recheck is deliberately AFTER the endpoint proof. Then the furniture
	rule (decision 0535), a read-only fact *admit* would refuse on, so a preview that passes is
	one *admit* can act on. `report.ok` here means only that *admit* may run.
	"""
	_demolition.reset()
	var code: StringName = _refuse_demolition_subject(building_ref)
	if code == REFUSE_NONE:
		code = _gate_stages_refusal(building_ref)
	if code == REFUSE_NONE:
		code = _furniture_project_refusal(building_ref)
	_demolition.error = code
	_demolition.ok = code == REFUSE_NONE
	return _demolition


func _gate_stages_refusal(building_ref: Vector2i) -> StringName:
	"""Stages 2-5 in order: endpoints, goods, occupants, footprint. Shared with #6's commit.

	The commit (decision 0535) runs these again after its own stage-1 variant, because stage 1
	refuses the DEMOLISHING building it is completing. Its own project is then simply one more
	endpoint: it has no material container and nothing delivered, so the walk passes it.
	"""
	var code: StringName = _walk_endpoints(building_ref, ENDPOINT_STAGE_PROVE)
	if code == REFUSE_NONE:
		code = _scan_demolition_goods(building_ref)
	if code == REFUSE_NONE:
		code = _recheck_demolition_residents(building_ref)
	if code == REFUSE_NONE:
		code = _footprint_containment_refusal(building_ref)
	return code


func _refuse_demolition_subject(building_ref: Vector2i) -> StringName:
	"""Stage 1: the subject must be a live ACTIVE building that carries no project yet."""
	if not _buildings.is_live_building(building_ref):
		return REFUSE_DEMOLITION_STALE_BUILDING
	if _buildings.construction_ref_of_building(building_ref) != EntityDirectoryScript.NULL_REF:
		return REFUSE_DEMOLITION_IN_PROGRESS
	if _buildings.state_of_building(building_ref).value != ConstructionScript.STATE_ACTIVE:
		return REFUSE_DEMOLITION_NOT_ACTIVE
	return REFUSE_NONE


func _walk_endpoints(building_ref: Vector2i, stage: int) -> StringName:
	"""Visit every affected endpoint of one building, in one deterministic order, once per stage.

	ONE definition of the affected set, run twice. The proof stage and the goods stage cannot
	disagree about which endpoints exist, because neither of them owns a list -- both ARE this
	walk. Rooms come in the building's chain order and furniture in each room's, so the stranded
	list a notice shows is stable across two calls that changed nothing.
	"""
	var code: StringName = _visit_endpoint(building_ref, stage)
	if code != REFUSE_NONE:
		return code
	for room_row: int in _buildings.rooms_of_building(building_ref):
		var room_ref: Vector2i = _buildings.room_ref_of_row(room_row)
		code = _visit_endpoint(room_ref, stage)
		if code != REFUSE_NONE:
			return code
		for furniture_row: int in _buildings.furniture_rows_in_room(room_ref):
			code = _visit_endpoint(_buildings.furniture_ref_of_row(furniture_row), stage)
			if code != REFUSE_NONE:
				return code
	return REFUSE_NONE


func _visit_endpoint(subject_ref: Vector2i, stage: int) -> StringName:
	"""Visit one affected subject, then whatever construction project is bound to that subject."""
	var code: StringName = _visit_owner(subject_ref, stage)
	if code != REFUSE_NONE:
		return code
	var project: Vector2i = _construction.project_of_subject(subject_ref)
	if project == EntityDirectoryScript.NULL_REF:
		return REFUSE_NONE
	code = _visit_owner(project, stage)
	if code != REFUSE_NONE:
		return code
	return _visit_material_container(project, stage)


func _visit_owner(owner_ref: Vector2i, stage: int) -> StringName:
	"""Prove one endpoint owner, or scan every container Inventory keys to it.

	A ref a store hands back must still be live in the ONE directory. A store that returns a ref
	the directory has retired is a binding this gate cannot prove -- not an owner with nothing
	in it -- so it refuses as a missing containment contract and counts no goods.

	THE SCAN REFUSAL IS A GUARD AND IS CURRENTLY UNREACHABLE, WHICH IS WHY IT STAYS. The query
	refuses a malformed owner and an undersized buffer; the owner has just been proved live in
	the directory, and `_demolition_pairs` is sized from `owner_query_cells()` -- the store's own
	published maximum -- so neither can happen as this file stands. Dropping the branch would
	silently read a refused query as "this owner has no goods", which is the one reading
	INV-GOODS-R01 exists to forbid, and a later caller with its own buffer would inherit it.
	"""
	if not _directory.is_valid(owner_ref):
		return REFUSE_DEMOLITION_MISSING_CONTAINMENT
	if stage == ENDPOINT_STAGE_PROVE:
		_demolition.endpoint_owner_count += 1
		return REFUSE_NONE
	if not _inventory.containers_by_owner_into(owner_ref, _demolition_pairs, _demolition_read):
		return REFUSE_DEMOLITION_SCAN  # guard, not a reachable state: see the docstring
	if stage == ENDPOINT_STAGE_CONTAIN:
		return _owned_containers_on_footprint(_demolition_read.value)
	if stage == ENDPOINT_STAGE_DESTROY:
		return _destroy_scanned_containers(_demolition_read.value)
	return _accumulate_scanned_containers(_demolition_read.value)


func _visit_material_container(project_ref: Vector2i, stage: int) -> StringName:
	"""Prove or scan a project's `material_container`, which is an INVENTORY-CONTAINER handle.

	THE SECOND REFERENCE DOMAIN, KEPT SEPARATE ON PURPOSE. `construction.gd` range-validates this
	pair and holds no Inventory with which to attest it, so validating it as a directory ref
	would accept a stale handle whose two numbers happened to match a live entity. Here it is
	validated as what it is, against the store that issued it.
	"""
	var handle: Vector2i = _construction.material_container_ref_of(project_ref)
	if handle == EntityDirectoryScript.NULL_REF:
		return _unbound_material_refusal(project_ref)
	if stage == ENDPOINT_STAGE_DESTROY:
		return _destroy_affected_container(handle)
	if not _inventory.is_container_valid(handle):
		return REFUSE_DEMOLITION_MISSING_CONTAINMENT
	if stage == ENDPOINT_STAGE_PROVE:
		return REFUSE_NONE
	if stage == ENDPOINT_STAGE_CONTAIN:
		return _on_footprint_refusal(handle)
	return _accumulate_container(handle)


func _unbound_material_refusal(project_ref: Vector2i) -> StringName:
	"""Refuse a project that has taken delivery but names no container it was delivered into.

	REQ-SET-124 records a delivery only AFTER the hauling owner has physically moved goods into
	`material_container`. A nonzero delivered line with no bound container therefore describes
	real goods at an endpoint this gate cannot name: a missing binding, not an empty store. A
	project that has taken nothing is no endpoint at all and passes.
	"""
	if not _construction.purpose_into(project_ref, _demolition_read):
		return REFUSE_DEMOLITION_MISSING_CONTAINMENT
	var purpose: int = _demolition_read.value
	if not _construction.type_id_into(project_ref, _demolition_read):
		return REFUSE_DEMOLITION_MISSING_CONTAINMENT
	if not _construction.bill_size_into(purpose, _demolition_read.value, _demolition_read):
		return REFUSE_DEMOLITION_MISSING_CONTAINMENT
	var lines: int = _demolition_read.value
	for index: int in lines:
		if not _construction.delivered_milli_into(project_ref, index, _demolition_read):
			return REFUSE_DEMOLITION_MISSING_CONTAINMENT
		if _demolition_read.value > 0:
			return REFUSE_DEMOLITION_MISSING_CONTAINMENT
	return REFUSE_NONE


func _scan_demolition_goods(building_ref: Vector2i) -> StringName:
	"""Stage 3: re-walk the proved endpoints, counting live lots and outstanding capacity claims.

	Stranded stock refuses before an outstanding claim because a lot is a thing that must be
	hauled and a claim is a thing its owner must release; neither is folded into the other, and
	both totals stand in the report whichever of them refused.
	"""
	_demolition_seen.fill(0)
	var code: StringName = _walk_endpoints(building_ref, ENDPOINT_STAGE_SCAN)
	if code != REFUSE_NONE:
		return code
	if _demolition.stranded_lot_count > 0:
		return REFUSE_DEMOLITION_STORED_GOODS
	if _demolition.outstanding_reserved_mass_g > 0:
		return REFUSE_DEMOLITION_CAPACITY_CLAIM
	return REFUSE_NONE


func _accumulate_scanned_containers(pair_count: int) -> StringName:
	"""Fold every container the last owner query wrote into the report, each one exactly once."""
	for index: int in pair_count:
		var container_ref: Vector2i = Vector2i(_demolition_pairs[index * 2],
			_demolition_pairs[index * 2 + 1])
		var code: StringName = _accumulate_container(container_ref)
		if code != REFUSE_NONE:
			return code
	return REFUSE_NONE


func _accumulate_container(container_ref: Vector2i) -> StringName:
	"""Count one container's live lots and its outstanding capacity claim, at most once.

	The seen mask is what makes "at most once" true across the two ways one container can be
	reached: keyed to an endpoint owner, and named by a project's `material_container` handle.
	`reserved_mass_g` is UNDELIVERED HEADROOM and is reported separately from the lots -- it is
	not a lot, and no lot is invented to account for it.
	"""
	if _demolition_seen[container_ref.x] == 1:
		return REFUSE_NONE
	_demolition_seen[container_ref.x] = 1
	_demolition.scanned_container_count += 1
	var reserved: int = _inventory.container_reserved_mass_g(container_ref)
	if reserved > 0:
		_demolition.claiming_container_count += 1
		if not IntMath.checked_add_into(_demolition.outstanding_reserved_mass_g, reserved,
				_demolition_read):
			return REFUSE_DEMOLITION_OVERFLOW
		_demolition.outstanding_reserved_mass_g = _demolition_read.value
	return _accumulate_container_lots(container_ref)


func _accumulate_container_lots(container_ref: Vector2i) -> StringName:
	"""Walk one container's lot list, bounded by its own live lot count, counting each lot once.

	A lot with `reserved_milli > 0` is counted ONCE and not twice: the reservation is a claim on
	that lot, not extra goods beside it.

	The overflow branch is the same kind of guard as `_visit_owner()`'s: 16384 lot rows cannot
	currently sum an int64 past its limit, and the total is still summed with a checked add
	rather than left to wrap silently if that ever changes.
	"""
	var lot_ref: Vector2i = _inventory.container_first_lot(container_ref)
	for _index: int in _inventory.container_lot_count(container_ref):
		if lot_ref == InventoryScript.NULL_REF:
			break
		_demolition.record_lot(lot_ref)
		if not IntMath.checked_add_into(_demolition.stranded_quantity_milli,
				_inventory.lot_quantity_milli(lot_ref), _demolition_read):
			return REFUSE_DEMOLITION_OVERFLOW
		_demolition.stranded_quantity_milli = _demolition_read.value
		lot_ref = _inventory.container_next_lot(lot_ref)
	return REFUSE_NONE


func _recheck_demolition_residents(building_ref: Vector2i) -> StringName:
	"""Stage 4: re-read `construction.gd`'s OWN occupant and furniture-user counts.

	AFTER the endpoint proof, never before it. The proof walks the very rooms and furniture this
	count is taken over, and a count taken first is a count taken against a set this gate had not
	yet established it could see. No yield and no mutation separates the two.
	"""
	_demolition.occupant_count = _construction.occupant_count_of_building(building_ref)
	if _demolition.occupant_count > 0:
		return ConstructionScript.REFUSE_OCCUPANTS_PRESENT
	_demolition.furniture_user_count = _construction.furniture_user_count_of_building(
		building_ref)
	if _demolition.furniture_user_count > 0:
		return ConstructionScript.REFUSE_FURNITURE_IN_USE
	return REFUSE_NONE


func _footprint_containment_refusal(building_ref: Vector2i) -> StringName:
	"""Stage 5 (DEMO-CONTAIN-R01 #3a/#3c/#5/#7): the owner scan and the tile scan must agree.

	The footprint (door tiles included, #5) is marked by the same call that yields the refund
	seeds. First every container the owner scan reaches -- the building's, its rooms', its
	furniture's and their projects', plus each material handle -- must be anchored ON it. Then
	every container anchored on it must be one of those, or a ground pile, whose lots and claims
	join the goods totals: an anchored ownerless container refuses (#7), one owned by anybody else
	refuses as a disagreement, and nothing on the footprint is silently omitted.
	"""
	_demolition_footprint.fill(0)
	if not _ground_piles.refund_seeds_into(building_ref, _demolition_footprint,
			_demolition_seeds, _demolition_read):
		return REFUSE_DEMOLITION_FOOTPRINT
	_demolition_seed_count = _demolition_read.value
	var code: StringName = _walk_endpoints(building_ref, ENDPOINT_STAGE_CONTAIN)
	if code == REFUSE_NONE:
		code = _scan_footprint_anchors()
	if code != REFUSE_NONE:
		return code
	if _demolition.stranded_lot_count > 0:
		return REFUSE_DEMOLITION_STORED_GOODS
	if _demolition.outstanding_reserved_mass_g > 0:
		return REFUSE_DEMOLITION_CAPACITY_CLAIM
	return REFUSE_NONE


func _owned_containers_on_footprint(pair_count: int) -> StringName:
	"""Every container the last owner query wrote must be anchored on the footprint."""
	for index: int in pair_count:
		var code: StringName = _on_footprint_refusal(Vector2i(_demolition_pairs[index * 2],
			_demolition_pairs[index * 2 + 1]))
		if code != REFUSE_NONE:
			return code
	return REFUSE_NONE


func _on_footprint_refusal(container_ref: Vector2i) -> StringName:
	"""Refuse an affected container anchored off the footprint or nowhere (#3a, #3c).

	Read through `container_anchor_tile_into()` (decision 0531): its plain twin answers -1 for a
	stale ref, which would read as "unplaced" when the truth is "no such container".
	"""
	if not _inventory.container_anchor_tile_into(container_ref, _demolition_read):
		return REFUSE_DEMOLITION_MISSING_CONTAINMENT
	var tile: int = _demolition_read.value
	if tile != InventoryScript.UNPLACED_TILE and _demolition_footprint[tile] != 0:
		return REFUSE_NONE
	_demolition.blocking_container = container_ref
	return REFUSE_DEMOLITION_OFF_FOOTPRINT


func _scan_footprint_anchors() -> StringName:
	"""The tile scan: classify every container anchored on the footprint."""
	if not _inventory.containers_anchored_in_into(_demolition_footprint, _demolition_pairs,
			_demolition_read):
		return REFUSE_DEMOLITION_SCAN  # guard: the mask and buffer are sized from the store
	var found: int = _demolition_read.value
	_demolition.anchored_container_count = found
	for index: int in found:
		var code: StringName = _classify_anchored(Vector2i(_demolition_pairs[index * 2],
			_demolition_pairs[index * 2 + 1]))
		if code != REFUSE_NONE:
			return code
	return REFUSE_NONE


func _classify_anchored(container_ref: Vector2i) -> StringName:
	"""Agreed (seen by the owner scan), a ground pile (counted), or a refusal by name.

	The seen mask was filled by stage 3's scan of exactly the endpoints stage 2 proved, and
	nothing has written since, so slot equality is container identity here.
	"""
	if _demolition_seen[container_ref.x] == 1:
		return REFUSE_NONE
	_demolition.blocking_container = container_ref
	if not InventoryScript.is_well_formed_owner(_inventory.container_owner(container_ref)):
		return REFUSE_DEMOLITION_ANCHORED_ORPHAN
	if not _inventory.is_ground_pile(container_ref):
		return REFUSE_DEMOLITION_FOREIGN_CONTAINER
	_demolition.blocking_container = InventoryScript.NULL_REF
	return _accumulate_container(container_ref)


# --- blocker 1: *admit* (decision 0534) ---------------------------------------------------------

func _admit_demolition(building_ref: Vector2i) -> StringName:
	"""Prove every write, then reserve, publish, record and advance -- in that order.

	Every check runs before the first write: the store transition (`demolition_open_refusal()`),
	the admission record, the open inventory transaction, and the output plan -- a surviving store
	with room for the whole return, or else a rolled-back ground-pile placement that proves the
	#9 fallback can take it.
	"""
	var code: StringName = _construction.demolition_open_refusal(building_ref)
	if code == REFUSE_NONE:
		code = _admissions.admit_refusal(building_ref)
	if code == REFUSE_NONE and _inventory.is_transaction_open():
		code = REFUSE_DEMOLITION_TRANSACTION
	if code == REFUSE_NONE:
		code = _plan_demolition_output(building_ref)
	if code != REFUSE_NONE:
		return code
	return _commit_demolition_admission(building_ref)


func _plan_demolition_output(building_ref: Vector2i) -> StringName:
	"""Choose where the combined 50% return goes, writing nothing: one surviving store, else piles.

	The combined return is the building's own half plus every piece of furniture's (decision
	0536), so the reservation covers all of it, as the furniture rule requires.
	"""
	if not _construction.demolition_return_preview_into(building_ref, _demolition_keys,
			_demolition_milli, _demolition_read):
		return StringName(_demolition_read.error)
	return _plan_output_for(building_ref, _demolition_read.value)


func _plan_output_for(building_ref: Vector2i, lines: int) -> StringName:
	"""Turn `lines` manifest lines into specs, then pick a surviving store or prove ground piles."""
	var code: StringName = _compile_return_specs(lines)
	if code != REFUSE_NONE or _demolition_spec_rows == 0:
		return code
	var store: Vector2i = _find_output_store(building_ref)
	if store != InventoryScript.NULL_REF:
		_demolition.output_container = store
		return REFUSE_NONE
	_demolition.output_to_ground_piles = true
	if _ground_piles.preflight_lots_from_seeds(_demolition_seeds, _demolition_seed_count,
			_demolition_footprint, _demolition_specs, _demolition_place):
		return REFUSE_NONE
	return REFUSE_DEMOLITION_NO_OUTPUT


func _compile_return_specs(lines: int) -> StringName:
	"""Turn the manifest into ground-pile spec rows and total its capacity charge in grams.

	One row per nonzero line, the inventory's unset attributes, age 0: a return is new material.
	The charge is each line's own `ceil(q * m / 1000)`, which is what one lot of it debits.
	Resized here, on a cold path, because the placement helper reads every row it is given.
	"""
	var rows: int = 0
	for index: int in lines:
		rows += 1 if _demolition_milli[index] > 0 else 0
	_demolition_spec_rows = rows
	_demolition_specs.resize(rows * GroundPilesScript.SPEC_STRIDE)
	_demolition_specs.fill(0)
	_return_charge_g = 0
	var row: int = 0
	for index: int in lines:
		if _demolition_milli[index] <= 0:
			continue
		var code: StringName = _add_return_spec(row, index)
		if code != REFUSE_NONE:
			return code
		row += 1
	return REFUSE_NONE


func _add_return_spec(row: int, line: int) -> StringName:
	"""Write one spec row and add its lot's capacity debit to the planned reservation."""
	var item: int = _item_definitions.compiled_id(
		ConstructionScript.MATERIAL_KEYS[_demolition_keys[line]])
	if item < 0 or not _inventory.is_item_registered(item):
		return REFUSE_DEMOLITION_RETURN_ITEM
	var base: int = row * GroundPilesScript.SPEC_STRIDE
	_demolition_specs[base + GroundPilesScript.SPEC_ITEM] = item
	_demolition_specs[base + GroundPilesScript.SPEC_QUANTITY] = _demolition_milli[line]
	if not IntMath.inventory_capacity_debit_g_into(_demolition_milli[line],
			_inventory.item_mass_g(item), _demolition_read):
		return REFUSE_DEMOLITION_OVERFLOW
	_return_charge_g += _demolition_read.value
	return REFUSE_NONE


func _find_output_store(building_ref: Vector2i) -> Vector2i:
	"""The lowest-slot surviving store that can take the WHOLE return, or the null ref.

	One bounded anchor query over every tile off this footprint. A candidate is placed, owned by
	a different ACTIVE building (a DEMOLISHING one's stores are about to go), reachable, not a
	ground pile (#9's piles are the fallback, never the reservation), admits every returned item
	and has free capacity for the whole planned charge. Brendan's ruling R1 (decision 0534).
	"""
	for tile: int in _demolition_outside.size():
		_demolition_outside[tile] = 1 - _demolition_footprint[tile]
	if not _inventory.containers_anchored_in_into(_demolition_outside, _demolition_pairs,
			_demolition_read):
		return InventoryScript.NULL_REF
	for index: int in _demolition_read.value:
		var candidate: Vector2i = Vector2i(_demolition_pairs[index * 2],
			_demolition_pairs[index * 2 + 1])
		if _is_output_store(candidate, building_ref):
			return candidate
	return InventoryScript.NULL_REF


func _is_output_store(container_ref: Vector2i, building_ref: Vector2i) -> bool:
	"""Whether one surviving container may hold this demolition's whole return."""
	var owner_ref: Vector2i = _inventory.container_owner(container_ref)
	if owner_ref == building_ref or _inventory.is_ground_pile(container_ref):
		return false
	if not _directory.is_valid_of_kind(owner_ref, EntityDirectoryScript.KIND_BUILDING):
		return false
	if _buildings.state_of_building(owner_ref).value != ConstructionScript.STATE_ACTIVE:
		return false
	if not _inventory.container_reachable(container_ref):
		return false
	if _inventory.container_free_mass_g(container_ref) < _return_charge_g:
		return false
	var filters: int = _inventory.container_filters(container_ref)
	for row: int in _demolition_spec_rows:
		var item: int = _demolition_specs[row * GroundPilesScript.SPEC_STRIDE]
		if (filters >> _inventory.item_category(item)) & 1 != 1:
			return false
	return true


func _commit_demolition_admission(building_ref: Vector2i,
		piece_ref: Vector2i = EntityDirectoryScript.NULL_REF) -> StringName:
	"""The writes, after every proof: reserve, publish, commit, record (revision +1).

	One inventory transaction holds the reservation and the transition, so a transition that
	still refused rolls it back; other refusals are guards (`_undo_admission()`). A `piece_ref`
	publishes that piece's removal instead, recorded on its building's row (decision 0536).
	"""
	var store: Vector2i = _demolition.output_container
	var charge: int = _return_charge_g
	var grams: int = charge if store != InventoryScript.NULL_REF else 0
	_demolition.output_container = InventoryScript.NULL_REF
	_demolition.output_reserved_g = 0
	if not _inventory.begin().ok:
		return REFUSE_DEMOLITION_TRANSACTION
	if grams > 0 and not _inventory.reserve_container_mass(store, grams).ok:
		_inventory.abort()
		return REFUSE_DEMOLITION_NO_OUTPUT
	var opened: ConstructionScript.OpResult = _open_removal_project(building_ref, piece_ref)
	if not opened.ok:
		_inventory.abort()
		return opened.error
	var committed: InventoryScript.OpResult = _inventory.commit()
	var code: StringName = committed.error if not committed.ok \
		else _admissions.record(building_ref, opened.ref, store, grams, charge)
	if code != REFUSE_NONE:
		_undo_admission(opened.ref, store, grams if committed.ok else 0)
		return code
	_report_admission(building_ref, opened.ref, store, grams)
	return REFUSE_NONE


func _report_admission(building_ref: Vector2i, project: Vector2i, store: Vector2i,
		grams: int) -> void:
	"""Fill the report with what admit wrote: the project, the claim and the new revision."""
	_demolition.project_ref = project
	_demolition.output_container = store
	_demolition.output_reserved_g = grams
	_demolition.destination_revision = _admissions.destination_revision_of(building_ref)


func _open_removal_project(building_ref: Vector2i, piece_ref: Vector2i) -> ConstructionScript.OpResult:
	"""The store transition admit publishes: the building's demolition, or one piece's removal."""
	if piece_ref == EntityDirectoryScript.NULL_REF:
		return _construction.open_demolition(building_ref)
	return _construction.open_furniture_removal(piece_ref)


func _undo_admission(project_ref: Vector2i, store: Vector2i, grams: int) -> void:
	"""Unreachable guard: retire a just-published demolition and release its reservation.

	`close_demolition_refund()` returns the building to ACTIVE and frees the row; the directory
	slot's generation has advanced, which is the one trace an allocator must leave.
	"""
	var undone: bool = _construction.begin_refund(project_ref).ok \
		and _construction.close_demolition_refund(project_ref).ok
	if grams > 0:
		undone = _inventory.release_container_mass(store, grams).ok and undone
	if not undone:
		push_error("SettlementSystem: a demolition admission could not be undone (%s)" % project_ref)


func cancel_demolition(building_ref: Vector2i) -> StringName:
	"""Cancel an admitted demolition: release its reserved return capacity, then retire it.

	The release comes FIRST and is the coordinator's, because construction sees no inventory and
	a project retired with its claim still held would strand that headroom (decision 0534, review
	H1); `close_refund()` refuses a demolition by name (0536). Every check runs before the first
	write; the building returns to ACTIVE, the record is cleared and the revision advances.
	"""
	var project: Vector2i = _construction.project_of_building(building_ref)
	var code: StringName = _cancel_refusal(building_ref, project,
		ConstructionScript.PURPOSE_DEMOLISH)
	if code != REFUSE_NONE:
		return code
	code = _cancel_admitted(building_ref, project)
	_demolition_work.retire_job_of(building_ref)
	return code


func _cancel_admitted(building_ref: Vector2i, project: Vector2i) -> StringName:
	"""Release the proved claim, retire the removal through the coordinator's door, clear the record."""
	var grams: int = _admissions.unreleased_reserved_g_of(building_ref)
	var done: bool = grams == 0 or _inventory.release_container_mass(
		_admissions.unreleased_output_of(building_ref), grams).ok
	done = _construction.begin_refund(project).ok and done
	done = _construction.close_demolition_refund(project).ok and done
	if not done:
		push_error("SettlementSystem: a proved cancellation refused a write (%s)" % project)
	return _admissions.release(building_ref)


func _cancel_refusal(building_ref: Vector2i, project: Vector2i, purpose: int) -> StringName:
	"""Why a cancellation would refuse right now, or REFUSE_NONE. Writes nothing."""
	if not _construction.purpose_into(project, _demolition_read) \
			or _demolition_read.value != purpose:
		return REFUSE_DEMOLITION_NOT_ADMITTED
	if not _construction.phase_into(project, _demolition_read) \
			or _demolition_read.value == ConstructionScript.PHASE_REFUNDING:
		return REFUSE_DEMOLITION_CANCEL_PHASE
	if _admissions.project_of(building_ref) != project:
		return REFUSE_DEMOLITION_NOT_ADMITTED
	return _claim_release_refusal(building_ref)


func _claim_release_refusal(building_ref: Vector2i) -> StringName:
	"""The shared proof before a recorded claim is released: no caller transaction, claim held.

	Inventory keeps one anonymous `reserved_mass_g` per container, so "held" can only mean the
	store still carries AT LEAST the recorded grams; whose grams they are is the record's word.
	"""
	if _inventory.is_transaction_open():
		return REFUSE_DEMOLITION_TRANSACTION
	var grams: int = _admissions.unreleased_reserved_g_of(building_ref)
	if grams > 0 and _inventory.container_reserved_mass_g(
			_admissions.unreleased_output_of(building_ref)) < grams:
		return REFUSE_DEMOLITION_CLAIM_MISSING
	return _admissions.release_refusal(building_ref)


func release_stranded_reservation(building_ref: Vector2i) -> StringName:
	"""Release a recorded claim stranded by a write made around the coordinator (review M-A).

	Two shapes: a project retired WITHOUT its claim (a store-level `close_demolition_refund()` or
	`retire_demolition()` called around the coordinator), or -- decision 0536 -- a piece's
	removal still live whose piece was removed around it, which nothing could complete or cancel.
	The latter's project is retired first (nothing is returned: its piece is gone). The claim is
	released from the recorded store and the record cleared. Refuses NOT_STRANDED otherwise.
	"""
	var project: Vector2i = _admissions.project_of(building_ref)
	var orphaned: bool = _is_orphaned_removal(project)
	if not orphaned and (project != EntityDirectoryScript.NULL_REF
			or _admissions.unreleased_reserved_g_of(building_ref) == 0):
		return REFUSE_DEMOLITION_NOT_STRANDED
	var code: StringName = _claim_release_refusal(building_ref)
	if code != REFUSE_NONE:
		return code
	var grams: int = _admissions.unreleased_reserved_g_of(building_ref)
	var done: bool = grams == 0 or _inventory.release_container_mass(
		_admissions.unreleased_output_of(building_ref), grams).ok
	if orphaned:
		done = _retire_orphaned_removal(project) and done
	if not done:
		push_error("SettlementSystem: a proved stranded release refused (%s)" % building_ref)
	_demolition_work.retire_job_of(building_ref)
	return _admissions.release(building_ref)


func _is_orphaned_removal(project: Vector2i) -> bool:
	"""A live piece-removal project whose piece no longer exists (removed around the coordinator)."""
	if not _construction.purpose_into(project, _demolition_read) \
			or _demolition_read.value != ConstructionScript.PURPOSE_REMOVE_FURNITURE:
		return false
	return not _buildings.is_live_furniture(_construction.subject_ref_of(project))


func _retire_orphaned_removal(project: Vector2i) -> bool:
	"""Retire an orphaned removal through the coordinator's cancellation door (returns nothing)."""
	if not _construction.phase_into(project, _demolition_read):
		return false
	if _demolition_read.value != ConstructionScript.PHASE_REFUNDING \
			and not _construction.begin_refund(project).ok:
		return false
	return _construction.close_demolition_refund(project).ok


# --- D5: the composed completion (DEMO-CONTAIN-R01 #6, decision 0535) ---------------------------

func complete_demolition(building_ref: Vector2i) -> DemolitionReport:
	"""DEMO-CONTAIN-R01 #6: commit one finished, admitted demolition in one call with no yield.

	Proves everything first: this coordinator admitted the building's project, its work is done
	and its claim still held; the gate's stages 2-5 hold again; the furniture rule; and the 50%
	return can be placed now. Then it writes in #6's order: (1) destroy the affected containers,
	(2) every piece of furniture, (3) rooms, (4) the building, (5) the combined
	return, (6) retire the project. A refusal of the proofs or of the commit's first,
	inventory-only block writes nothing and leaves the project PHASE_WORK_DONE: commit-pending,
	and a retry costs nothing (ECON-003). Later refusals are unreachable guards (decision 0535).
	"""
	_demolition.reset()
	var project: Vector2i = _construction.project_of_building(building_ref)
	var row: int = _demolition_work.row_of(building_ref)
	var code: StringName = _commit_refusal(building_ref, project)
	if code == REFUSE_NONE:
		code = _commit_demolition(building_ref, project)
	_demolition.error = code
	_demolition.ok = code == REFUSE_NONE
	if _demolition.ok:
		_demolition_work.retire_job_at(row)
	return _demolition


func _commit_refusal(building_ref: Vector2i, project: Vector2i) -> StringName:
	"""Every proof #6's commit needs, in order, writing nothing."""
	var code: StringName = _commit_subject_refusal(building_ref, project)
	if code == REFUSE_NONE:
		code = _gate_stages_refusal(building_ref)
	if code == REFUSE_NONE:
		code = _commit_output_refusal(building_ref, project)
	return code


func _commit_subject_refusal(building_ref: Vector2i, project: Vector2i) -> StringName:
	"""Stage 1's commit-time variant: the coordinator's own admitted demolition, its work done.

	`construction.demolition_commit_refusal()`'s codes are re-raised, not re-spelled. The claim
	proof is cancellation's: no caller transaction, the store still holding the recorded grams.
	"""
	if not _buildings.is_live_building(building_ref):
		return REFUSE_DEMOLITION_STALE_BUILDING
	if project == EntityDirectoryScript.NULL_REF or _admissions.project_of(building_ref) != project:
		return REFUSE_DEMOLITION_NOT_ADMITTED
	var code: StringName = _construction.demolition_commit_refusal(project)
	if code != REFUSE_NONE:
		return code
	return _claim_release_refusal(building_ref)


func _commit_output_refusal(building_ref: Vector2i, project: Vector2i) -> StringName:
	"""The return's proofs: the furniture rule, the snapshot's manifest, and its placement now.

	A store return is proved by releasing the claim and creating every lot in a rolled-back
	transaction, after the recorded grams are proved equal to the snapshot's own charge; a
	ground-pile return by #9's rolled-back preflight. Either failing is NO_OUTPUT_CAPACITY and the
	demolition stays commit-pending (decision 0534's ruling R2).
	"""
	var code: StringName = _furniture_project_refusal(building_ref)
	if code == REFUSE_NONE:
		code = _commit_return_refusal(building_ref, project)
	return code


func _commit_return_refusal(building_ref: Vector2i, project: Vector2i) -> StringName:
	"""The project's own manifest, its charge against admission's, and its placement now.

	Shared by a demolition's commit and a piece's removal (decision 0536). The refund seeds and
	footprint mask the pile proof reads must already be built for `building_ref`.
	"""
	var code: StringName = _compile_project_return(project)
	if code == REFUSE_NONE and _admissions.admitted_charge_g_of(building_ref) \
			!= _return_charge_g:
		code = REFUSE_DEMOLITION_RESERVATION_MISMATCH
	if code != REFUSE_NONE or _demolition_spec_rows == 0:
		return code
	var store: Vector2i = _admissions.output_container_of(building_ref)
	if store == InventoryScript.NULL_REF:
		return _preflight_pile_return()
	# A guard: record() makes a store's reserved grams equal its charge, which was just compared.
	var grams: int = _admissions.output_reserved_g_of(building_ref)
	if grams != _return_charge_g:
		return REFUSE_DEMOLITION_RESERVATION_MISMATCH
	return _preflight_store_return(store, grams)


func _preflight_pile_return() -> StringName:
	"""#9's rolled-back placement from the refund seeds stage 5 just rebuilt, footprint excluded."""
	if _ground_piles.preflight_lots_from_seeds(_demolition_seeds, _demolition_seed_count,
			_demolition_footprint, _demolition_specs, _demolition_place):
		return REFUSE_NONE
	return REFUSE_DEMOLITION_NO_OUTPUT


func _furniture_project_refusal(building_ref: Vector2i) -> StringName:
	"""Refuse while any piece in the building still has a live project of its own (decision 0536).

	Every other piece is taken down WITH the building and returns 50% of its type's bill (P1). A
	piece still under construction, or already being removed on its own, is not: it settles
	through its own project first. All such pieces are counted and the first is named.
	"""
	for room_row: int in _buildings.rooms_of_building(building_ref):
		var room_ref: Vector2i = _buildings.room_ref_of_row(room_row)
		for furniture_row: int in _buildings.furniture_rows_in_room(room_ref):
			var piece: Vector2i = _buildings.furniture_ref_of_row(furniture_row)
			if _construction.project_of_subject(piece) == EntityDirectoryScript.NULL_REF:
				continue
			if _demolition.blocked_furniture_count == 0:
				_demolition.blocking_furniture = piece
			_demolition.blocked_furniture_count += 1
	if _demolition.blocked_furniture_count > 0:
		return REFUSE_DEMOLITION_FURNITURE_UNDER_CONSTRUCTION
	return REFUSE_NONE


func _compile_project_return(project: Vector2i) -> StringName:
	"""Read the admitted project's own manifest (its snapshot, already halved) into spec rows."""
	if not _construction.demolition_return_into(project, _demolition_keys, _demolition_milli,
			_demolition_read):
		return StringName(_demolition_read.error)
	return _compile_return_specs(_demolition_read.value)


func _preflight_store_return(store: Vector2i, grams: int) -> StringName:
	"""Release the claim and create every return lot in the store, then roll it all back."""
	if not _inventory.begin().ok:
		return REFUSE_DEMOLITION_TRANSACTION  # guard: the claim proof refused an open one
	var code: StringName = _inventory.release_container_mass(store, grams).error
	if code == REFUSE_NONE:
		code = _create_return_lots(store)
	_inventory.abort()
	return REFUSE_NONE if code == REFUSE_NONE else REFUSE_DEMOLITION_NO_OUTPUT


func _create_return_lots(store: Vector2i) -> StringName:
	"""One new lot per return line in `store`, with the spec row's attributes (all unset, age 0)."""
	for row: int in _demolition_spec_rows:
		var base: int = row * GroundPilesScript.SPEC_STRIDE
		var made: InventoryScript.OpResult = _inventory.create_lot(store,
			_demolition_specs[base + GroundPilesScript.SPEC_ITEM],
			_demolition_specs[base + GroundPilesScript.SPEC_QUANTITY],
			_demolition_specs[base + GroundPilesScript.SPEC_QUALITY],
			_demolition_specs[base + GroundPilesScript.SPEC_PROVENANCE],
			_demolition_specs[base + GroundPilesScript.SPEC_RECIPE],
			_demolition_specs[base + GroundPilesScript.SPEC_AGE],
			_demolition_specs[base + GroundPilesScript.SPEC_AGE_REMAINDER])
		if not made.ok:
			return made.error
	return REFUSE_NONE


func _commit_demolition(building_ref: Vector2i, project: Vector2i,
		piece_ref: Vector2i = EntityDirectoryScript.NULL_REF) -> StringName:
	"""#6's writes, after every proof. Only `_open_commit()` can still refuse cleanly.

	Inventory's steps share ONE transaction: (1) the destroyed stores, the released claim and (5)
	the return. The admission record is released BEFORE the building row goes, because it is
	keyed by that row (decision 0534), and that is where the destination revision advances. Any
	later refusal is a guard the proofs make unreachable; `_abandon_commit()` aborts Inventory,
	re-records the admission while the building row stands, and logs. With a `piece_ref` it is that
	piece's removal (decision 0536): its stores, the pantry capacity it carried, then the piece.
	"""
	var grams: int = _admissions.unreleased_reserved_g_of(building_ref)
	var store: Vector2i = _admissions.unreleased_output_of(building_ref)
	var charge: int = _admissions.admitted_charge_g_of(building_ref)
	var code: StringName = _open_commit(building_ref, piece_ref, store, grams)
	if code != REFUSE_NONE:
		return code
	_demolition.destination_revision = _admissions.destination_revision_of(building_ref)
	code = _remove_subject(building_ref, project, piece_ref)
	if code == REFUSE_NONE:
		code = _place_return(store)
	if code == REFUSE_NONE:
		code = _commit_and_declare()
	if code != REFUSE_NONE:
		_abandon_commit(building_ref, project, store, grams, charge, code)
		return code
	code = _construction.retire_demolition(project).error
	if code != REFUSE_NONE:
		push_error("SettlementSystem: a committed removal's project would not retire (%s)" % code)
		return code
	_demolition.project_ref = project
	_demolition.output_container = store
	_demolition.output_reserved_g = grams
	return REFUSE_NONE


func _abandon_commit(building_ref: Vector2i, project: Vector2i, store: Vector2i, grams: int,
		charge: int, code: StringName) -> void:
	"""Unreachable guard, BEFORE the commit and after the record's release: undo what can be.

	The abort restores Inventory, the claim's grams included, and while the BUILDING row stands
	the admission is recorded again: for a demolition that keeps it reachable by cancellation or
	a retry; for a piece already removed it is exactly the orphaned-removal shape
	`release_stranded_reservation()` recovers. Removed furniture, rooms or a removed building
	cannot be restored (Buildings has no transaction), and the abort brings back a removed
	piece's stores and shelf capacity, which no door repairs (decisions 0535, 0536; reviews M1).
	"""
	_inventory.abort()
	_demolition.removed_furniture_count = 0
	var recorded: StringName = &"BUILDING_GONE"
	if _buildings.is_live_building(building_ref):
		recorded = _admissions.record(building_ref, project, store, grams, charge)
	_demolition.destroyed_container_count = 0
	_demolition.removed_room_count = 0
	_demolition.returned_lot_count = 0
	_demolition.destination_revision = _admissions.destination_revision_of(building_ref)
	push_error("SettlementSystem: a proved demolition commit refused a write (%s); re-record: '%s'"
		% [code, recorded])


func _open_commit(building_ref: Vector2i, piece_ref: Vector2i, store: Vector2i,
		grams: int) -> StringName:
	"""Open the transaction, (1) destroy the affected stores, release the claim and the record.

	The only block of the commit that can still refuse cleanly: inventory is rolled back and the
	record is released last, so a refusal here leaves every store as it was. A piece's removal
	destroys only the piece's own stores (and its removal project's, by handle).
	"""
	if not _inventory.begin().ok:
		return REFUSE_DEMOLITION_TRANSACTION  # guard: the claim proof refused an open one
	var code: StringName = _walk_endpoints(building_ref, ENDPOINT_STAGE_DESTROY) \
		if piece_ref == EntityDirectoryScript.NULL_REF \
		else _visit_endpoint(piece_ref, ENDPOINT_STAGE_DESTROY)
	if code == REFUSE_NONE and grams > 0:
		code = _inventory.release_container_mass(store, grams).error
	if code == REFUSE_NONE:
		code = _admissions.release(building_ref)
	if code != REFUSE_NONE:
		_inventory.abort()
		_demolition.destroyed_container_count = 0
	return code


func _destroy_scanned_containers(pair_count: int) -> StringName:
	"""Step (1) for one owner: destroy every container the last owner query wrote."""
	for index: int in pair_count:
		var code: StringName = _destroy_affected_container(Vector2i(
			_demolition_pairs[index * 2], _demolition_pairs[index * 2 + 1]))
		if code != REFUSE_NONE:
			return code
	return REFUSE_NONE


func _destroy_affected_container(container_ref: Vector2i) -> StringName:
	"""Destroy one affected container, proved empty and on the footprint by stages 3 and 5.

	A project's material container is reached twice, through its owner and by handle; the
	second visit finds it already gone, and that is the only way one can be gone here.
	"""
	if not _inventory.is_container_valid(container_ref):
		return REFUSE_NONE
	var destroyed: InventoryScript.OpResult = _inventory.destroy_container(container_ref)
	if not destroyed.ok:
		return destroyed.error
	_demolition.destroyed_container_count += 1
	return REFUSE_NONE


func _remove_subject(building_ref: Vector2i, project: Vector2i, piece_ref: Vector2i) -> StringName:
	"""The subject's step: the whole structure, or one piece and the pantry capacity it carried."""
	if piece_ref == EntityDirectoryScript.NULL_REF:
		return _remove_structure(building_ref, project)
	if _removal_pantry_g > 0:
		var reduced: InventoryScript.OpResult = _inventory.reduce_container_capacity(
			_removal_pantry_store, _removal_pantry_g)
		if not reduced.ok:
			return reduced.error
	var removed: ConstructionScript.OpResult = _construction.remove_demolished_subject(project)
	_demolition.removed_furniture_count = 1 if removed.ok else 0
	return removed.error


func _remove_structure(building_ref: Vector2i, project: Vector2i) -> StringName:
	"""Steps (2)-(4): every piece of furniture, every room, then the building."""
	var code: StringName = _remove_all_furniture(building_ref)
	if code != REFUSE_NONE:
		return code
	for room_row: int in _buildings.rooms_of_building(building_ref):
		var removed: BuildingsScript.OpResult = _buildings.remove_room(
			_buildings.room_ref_of_row(room_row))
		if not removed.ok:
			return removed.error
		_demolition.removed_room_count += 1
	return _construction.remove_demolished_subject(project).error


func _remove_all_furniture(building_ref: Vector2i) -> StringName:
	"""Step (2): take every piece out. Each one's 50% is already in the combined return (0536)."""
	for room_row: int in _buildings.rooms_of_building(building_ref):
		for furniture_row: int in _buildings.furniture_rows_in_room(
				_buildings.room_ref_of_row(room_row)):
			var removed: BuildingsScript.OpResult = _buildings.remove_furniture(
				_buildings.furniture_ref_of_row(furniture_row))
			if not removed.ok:
				return removed.error
			_demolition.removed_furniture_count += 1
	return REFUSE_NONE


func _place_return(store: Vector2i) -> StringName:
	"""Step (5), inside the commit's transaction: into the released claim's store, else piles.

	The piles start from the refund seeds and exclude the footprint mask stage 5 built BEFORE
	the building row went (decision 0532), with the same placement the proof rolled back.
	"""
	if _demolition_spec_rows == 0:
		return REFUSE_NONE
	if store != InventoryScript.NULL_REF:
		var code: StringName = _create_return_lots(store)
		_demolition.returned_lot_count = _demolition_spec_rows if code == REFUSE_NONE else 0
		return code
	_demolition.output_to_ground_piles = true
	if not _ground_piles.place_lots_from_seeds_in_transaction(_demolition_seeds,
			_demolition_seed_count, _demolition_footprint, _demolition_specs, _demolition_place):
		return _demolition_place.error
	_demolition.returned_lot_count = _demolition_place.lots_created
	return REFUSE_NONE


func _commit_and_declare() -> StringName:
	"""Commit the transaction, then declare the new piles' storage class. Step (6) follows it."""
	var committed: InventoryScript.OpResult = _inventory.commit()
	if not committed.ok:
		return committed.error
	if _demolition.output_to_ground_piles and not _ground_piles.declare_placed_piles():
		push_error("SettlementSystem: a placed demolition return's pile class was refused")
	return REFUSE_NONE


# --- decision 0536: one piece of furniture taken out of a standing building (P2) ----------------

func preview_furniture_removal(piece_ref: Vector2i) -> DemolitionReport:
	"""The single-piece gate, read-only: the piece, its building, its goods, and #3b's capacity.

	The piece is live and in an ACTIVE building; no resident uses it and it carries no project
	of its own; its own stores (and any its project names) hold no goods and no claim; and, when
	it is a shelf in a pantry room, the building's pantry store still fits its contents and
	reservations at the capacity left without it (DEMO-CONTAIN-R01 #3b). CHANGES NOTHING.
	"""
	_demolition.reset()
	var code: StringName = _removal_subject_refusal(piece_ref)
	if code == REFUSE_NONE:
		code = _removal_goods_refusal(piece_ref)
	if code == REFUSE_NONE:
		code = _pantry_shelf_refusal(piece_ref)
	_demolition.error = code
	_demolition.ok = code == REFUSE_NONE
	return _demolition


func request_furniture_removal(piece_ref: Vector2i) -> DemolitionReport:
	"""The preview, then *admit* in the same call: reserve the piece's 50%, publish its removal.

	D4's admit with the piece as subject: the store transition, the building row's admission
	record (one admission per building -- decision 0536), no caller transaction and an output
	plan are all proved before the first write; the return goes to another building's store,
	else onto ground piles from the building's refund seeds (ruling R1/R2 unchanged).
	"""
	preview_furniture_removal(piece_ref)
	if not _demolition.ok:
		return _demolition
	var code: StringName = _admit_furniture_removal(piece_ref, _building_of_piece(piece_ref))
	_demolition.error = code
	_demolition.ok = code == REFUSE_NONE
	_removal_work_dirty = _removal_work_dirty or _demolition.ok
	return _demolition


func complete_furniture_removal(piece_ref: Vector2i) -> DemolitionReport:
	"""Commit one finished, admitted piece removal with no yield: D5's commit with a piece subject.

	Proves the admitted project, its work and its claim, the preview's checks again and the
	return's placement; then, in one inventory transaction, destroys the piece's stores, releases
	the claim and the record, lowers the pantry capacity it carried (#3b), removes the piece,
	places its 50% and retires the project. Refusals write nothing and stay commit-pending.
	"""
	_demolition.reset()
	var building: Vector2i = _building_of_piece(piece_ref)
	var project: Vector2i = _construction.project_of_subject(piece_ref)
	var code: StringName = _removal_commit_refusal(piece_ref, building, project)
	if code == REFUSE_NONE:
		code = _commit_demolition(building, project, piece_ref)
	_demolition.error = code
	_demolition.ok = code == REFUSE_NONE
	if _demolition.ok:
		_demolition_work.retire_job_of(building)
	return _demolition


func cancel_furniture_removal(piece_ref: Vector2i) -> StringName:
	"""Cancel an admitted piece removal: release its claim, retire it, clear the record. Free (R5)."""
	if not _buildings.is_live_furniture(piece_ref):
		return REFUSE_REMOVAL_STALE_PIECE
	var building: Vector2i = _building_of_piece(piece_ref)
	var project: Vector2i = _construction.project_of_subject(piece_ref)
	var code: StringName = _cancel_refusal(building, project,
		ConstructionScript.PURPOSE_REMOVE_FURNITURE)
	if code != REFUSE_NONE:
		return code
	code = _cancel_admitted(building, project)
	_demolition_work.retire_job_of(building)
	return code


func _building_of_piece(piece_ref: Vector2i) -> Vector2i:
	"""The building a piece's room belongs to, or the null ref for a stale piece."""
	return _buildings.room_building_ref_of(_buildings.room_ref_of_furniture(piece_ref))


func _removal_subject_refusal(piece_ref: Vector2i) -> StringName:
	"""A live piece in an ACTIVE building, unused, with no project of its own."""
	if not _buildings.is_live_furniture(piece_ref):
		return REFUSE_REMOVAL_STALE_PIECE
	var state: BuildingsScript.OpResult = _buildings.state_of_building(_building_of_piece(piece_ref))
	if not state.ok or state.value != ConstructionScript.STATE_ACTIVE:
		return REFUSE_REMOVAL_BUILDING_NOT_ACTIVE
	if _construction.project_of_subject(piece_ref) != EntityDirectoryScript.NULL_REF:
		_demolition.blocking_furniture = piece_ref
		_demolition.blocked_furniture_count = 1
		return REFUSE_DEMOLITION_FURNITURE_UNDER_CONSTRUCTION
	return _removal_user_refusal(piece_ref)


func _removal_user_refusal(piece_ref: Vector2i) -> StringName:
	"""REQ-SET-128's resident half for one piece: construction's own FURNITURE_IN_USE code."""
	if _buildings.user_ref_of_furniture(piece_ref) == EntityDirectoryScript.NULL_REF:
		return REFUSE_NONE
	_demolition.furniture_user_count = 1
	return ConstructionScript.REFUSE_FURNITURE_IN_USE


func _removal_goods_refusal(piece_ref: Vector2i) -> StringName:
	"""Prove the piece's endpoints, then count its stores' lots and claims (stage 2-3 for one piece)."""
	var code: StringName = _visit_endpoint(piece_ref, ENDPOINT_STAGE_PROVE)
	if code != REFUSE_NONE:
		return code
	_demolition_seen.fill(0)
	code = _visit_endpoint(piece_ref, ENDPOINT_STAGE_SCAN)
	if code != REFUSE_NONE:
		return code
	if _demolition.stranded_lot_count > 0:
		return REFUSE_DEMOLITION_STORED_GOODS
	if _demolition.outstanding_reserved_mass_g > 0:
		return REFUSE_DEMOLITION_CAPACITY_CLAIM
	return REFUSE_NONE


func _pantry_shelf_refusal(piece_ref: Vector2i) -> StringName:
	"""DEMO-CONTAIN-R01 #3b: a shelf's 50000 g leaves its pantry store; refuse if that overflows.

	#3b's own words: "A shelf adds 50,000 g of capacity to the Building-owned pantry container".
	So a shelf in a PANTRY room carries it -- the kitchen's fifth shelf does not (R-BUILD-DOM-004)
	-- whether or not the room is yet VALID, because that is how the capacity was granted: D3
	gives the starter pantry its 200000 g from its four shelves while no system yet marks any room
	valid (decision 0536, review H2). The pantry store is the building's main store: its one owned
	container anchored at its origin tile (#3a). Its contents plus reservations must fit what is
	left; the reduction itself is the commit's.
	"""
	_removal_pantry_store = InventoryScript.NULL_REF
	_removal_pantry_g = 0
	var room: Vector2i = _buildings.room_ref_of_furniture(piece_ref)
	if _buildings.type_of_room(room).value != BuildingsScript.ROOM_TYPE_PANTRY:
		return REFUSE_NONE
	var by_g: int = _buildings.definitions().shelf_capacity_g_of(
		_buildings.type_id_of_furniture(piece_ref).value)
	if by_g == 0:
		return REFUSE_NONE
	var store: Vector2i = _main_store_of(_buildings.room_building_ref_of(room))
	if store == InventoryScript.NULL_REF:
		return REFUSE_REMOVAL_PANTRY_STORE
	var held: int = _inventory.container_used_mass_g(store) \
		+ _inventory.container_reserved_mass_g(store)
	if _inventory.container_max_mass_g(store) - by_g < held:
		_demolition.blocking_container = store
		return REFUSE_REMOVAL_PANTRY_OVER_CAPACITY
	_removal_pantry_store = store
	_removal_pantry_g = by_g
	return REFUSE_NONE


func _main_store_of(building_ref: Vector2i) -> Vector2i:
	"""The building's ONE owned container anchored at its origin tile (#3a), else the null ref."""
	var origin: int = _buildings.origin_tile_of_building(building_ref).value
	if not _inventory.containers_by_owner_into(building_ref, _demolition_pairs, _demolition_read):
		return InventoryScript.NULL_REF  # guard: the owner is live and the buffer the store's own
	var found: Vector2i = InventoryScript.NULL_REF
	for index: int in _demolition_read.value:
		var container: Vector2i = Vector2i(_demolition_pairs[index * 2],
			_demolition_pairs[index * 2 + 1])
		if _inventory.container_anchor_tile(container) != origin:
			continue
		if found != InventoryScript.NULL_REF:
			return InventoryScript.NULL_REF
		found = container
	return found


func _admit_furniture_removal(piece_ref: Vector2i, building_ref: Vector2i) -> StringName:
	"""Prove the transition, the building row's record, no transaction and an output plan; write."""
	var code: StringName = _construction.furniture_removal_open_refusal(piece_ref)
	if code == REFUSE_NONE:
		code = _admissions.admit_refusal(building_ref)
	if code == REFUSE_NONE and _inventory.is_transaction_open():
		code = REFUSE_DEMOLITION_TRANSACTION
	if code == REFUSE_NONE:
		code = _plan_removal_output(piece_ref, building_ref)
	if code != REFUSE_NONE:
		return code
	return _commit_demolition_admission(building_ref, piece_ref)


func _plan_removal_output(piece_ref: Vector2i, building_ref: Vector2i) -> StringName:
	"""The piece's 50% (its type's bill, P1), placed exactly as a demolition's would be."""
	var code: StringName = _mark_refund_seeds(building_ref)
	if code != REFUSE_NONE:
		return code
	if not _construction.furniture_removal_return_preview_into(piece_ref, _demolition_keys,
			_demolition_milli, _demolition_read):
		return StringName(_demolition_read.error)
	return _plan_output_for(building_ref, _demolition_read.value)


func _mark_refund_seeds(building_ref: Vector2i) -> StringName:
	"""Rebuild the footprint mask and the refund seeds for one standing building."""
	_demolition_footprint.fill(0)
	if not _ground_piles.refund_seeds_into(building_ref, _demolition_footprint,
			_demolition_seeds, _demolition_read):
		return REFUSE_DEMOLITION_FOOTPRINT
	_demolition_seed_count = _demolition_read.value
	return REFUSE_NONE


func _removal_commit_refusal(piece_ref: Vector2i, building_ref: Vector2i,
		project: Vector2i) -> StringName:
	"""Every proof a piece's commit needs, writing nothing: subject, the gate again, the return."""
	if not _buildings.is_live_furniture(piece_ref):
		return REFUSE_REMOVAL_STALE_PIECE
	if project == EntityDirectoryScript.NULL_REF or _admissions.project_of(building_ref) != project:
		return REFUSE_DEMOLITION_NOT_ADMITTED
	var code: StringName = _construction.demolition_commit_refusal(project)
	if code == REFUSE_NONE:
		code = _claim_release_refusal(building_ref)
	if code == REFUSE_NONE:
		code = _removal_user_refusal(piece_ref)
	if code == REFUSE_NONE:
		code = _removal_goods_refusal(piece_ref)
	if code == REFUSE_NONE:
		code = _pantry_shelf_refusal(piece_ref)
	if code == REFUSE_NONE:
		code = _mark_refund_seeds(building_ref)
	if code == REFUSE_NONE:
		code = _commit_return_refusal(building_ref, project)
	return code


# --- D6: demolition work under BUILD and the evacuation intent (decision 0537) ------------------

func order_evacuate_then_demolish(building_ref: Vector2i) -> DemolitionReport:
	"""Blocker 4's "evacuate, then demolish": admit now, or record the order and retry later.

	`request_demolition()` runs first. If it admits, the order is already satisfied and its report
	is returned. If it refuses because the building's stores hold goods or carry a claim -- stage
	3 or 5, `DEMOLITION_BLOCKED_STORED_GOODS` / `DEMOLITION_BLOCKED_CAPACITY_CLAIM` -- the intent
	is recorded (`evacuation_ordered`) and the refusal, with its exact stranded lots, stays in the
	report for the notice. Any other refusal is returned unchanged and records nothing.

	THE ORDER POSTS NO HAUL JOB (decision 0537): physical hauling is task 06.4, which does not
	exist. The hourly reconcile retries *admit* once the footprint's containers report empty,
	however they were emptied.
	"""
	request_demolition(building_ref)
	if _demolition.ok or not is_evacuable_refusal(_demolition.error):
		return _demolition
	_demolition.evacuation_ordered = _demolition_work.order_intent(building_ref) == REFUSE_NONE
	return _demolition


static func is_evacuable_refusal(code: StringName) -> bool:
	"""The two goods-stage refusals (stages 3 and 5) an evacuation order may wait out."""
	return code == REFUSE_DEMOLITION_STORED_GOODS or code == REFUSE_DEMOLITION_CAPACITY_CLAIM


func cancel_evacuation(building_ref: Vector2i) -> StringName:
	"""Withdraw a building's "evacuate, then demolish" order. Nothing else changes."""
	return _demolition_work.cancel_intent(building_ref)


func has_evacuation_intent(building_ref: Vector2i) -> bool:
	"""Whether a live building carries an "evacuate, then demolish" order still waiting."""
	return _demolition_work.has_intent(building_ref)


func demolition_work() -> DemolitionWorkScript:
	"""D6's store: the evacuation intents and the removal work Jobs' links (decision 0537)."""
	return _demolition_work


func evacuation_retry_count() -> int:
	"""How many deferred admits the hourly reconcile has attempted since the last reset."""
	return _evacuation_retry_count


func removal_commit_retry_count() -> int:
	"""How many commit-pending removals the hourly reconcile has retried since the last reset."""
	return _removal_commit_retry_count


func _tick_removal_work(job_slot: int, project: Vector2i) -> void:
	"""One productive tick of a removal work Job, credited to its project in the same tick.

	Validate, then consume (decision 0059): the project must take the credit and hold exactly
	the Job's outstanding work BEFORE `work.gd` consumes any, so the credit after it cannot
	refuse. The credit is what the Job's own remainder actually lost, not the tick result's
	acceptance, so a tick `work.gd` refused after consuming still reaches the project. Outside
	JOB_STATE_WORK this costs one read beyond `project_of_job()`; nothing moves a Job there yet but
	movement, which is not composed (header).
	"""
	if not _jobs.state_into(job_slot, _read) or _read.value != JobsScript.JOB_STATE_WORK:
		return
	if _demolition_work.work_refusal(job_slot, project) != REFUSE_NONE:
		return
	_jobs.remaining_mwu_into(job_slot, _read)
	var before: int = _read.value
	_work.tick_solo_into(job_slot, _tick_result)
	_jobs.remaining_mwu_into(job_slot, _read)
	var consumed: int = before - _read.value
	if consumed <= 0:
		return
	var left: int = _read.value
	var code: StringName = _demolition_work.credit_work(project, consumed)
	if code != REFUSE_NONE:
		push_error("SettlementSystem: a proved demolition work credit refused (%s)" % code)
	_accepted_mwu_last_tick += consumed
	if left == 0:
		_finish_spent_job(job_slot)


func _finish_spent_job(job_slot: int) -> void:
	"""A removal Job with no work left is COMPLETE, whatever `work.gd`'s tick did afterwards.

	`work.gd` writes COMPLETE only on a tick it finishes cleanly; a refusal after its consume (an
	XP overflow, say) would leave the Job in WORK at 0, and nothing would commit the project.
	"""
	if not _jobs.state_into(job_slot, _read) or _read.value != JobsScript.JOB_STATE_COMPLETE:
		_jobs.set_state(job_slot, JobsScript.JOB_STATE_COMPLETE)
	_removal_jobs_finished += 1


func _finish_removal_jobs() -> void:
	"""Retire every removal work Job the walk completed, then commit its removal.

	The commit is the coordinator's own (`complete_demolition()` / `complete_furniture_removal()`),
	never a store door. A refusal leaves the project PHASE_WORK_DONE, commit-pending, and the
	hourly reconcile retries it (ECON-003: no cost).
	"""
	for row: int in BuildingsScript.BUILDING_CAPACITY:
		var project: Vector2i = _demolition_work.finished_project_at(row)
		if project == EntityDirectoryScript.NULL_REF:
			continue
		_demolition_work.retire_job_at(row)
		_commit_removal(project)
	_removal_jobs_finished = 0


func _commit_removal(project: Vector2i) -> void:
	"""Commit one finished removal through the door its purpose names."""
	var subject: Vector2i = _construction.subject_ref_of(project)
	if not _construction.purpose_into(project, _read):
		return
	if _read.value == ConstructionScript.PURPOSE_DEMOLISH:
		complete_demolition(subject)
	elif _read.value == ConstructionScript.PURPOSE_REMOVE_FURNITURE:
		complete_furniture_removal(subject)


func _reconcile_removal_work(tick_index: int) -> void:
	"""Post missing work Jobs, then -- on an hour crossing -- retry commits and evacuations.

	Runs in ARCH-SYS-009's slot, before selection, so a Job posted here can be offered this
	tick. It returns at once unless an admission marked it dirty or the hour turned; the two
	retries scan stores (the commit's proofs, the footprint's anchors), so they keep the hourly
	cadence decision 0537 proposes (P1) rather than running every tick. It runs BEFORE the job
	planner, so a deferred admit or commit lands where a player's command would have.
	"""
	var hourly: bool = StockAgeScript.is_hour_boundary(tick_index)
	if not hourly and not _removal_work_dirty:
		return
	_removal_work_dirty = false
	if hourly:
		_retire_orphaned_removal_jobs()
	for row: int in BuildingsScript.BUILDING_CAPACITY:
		_reconcile_removal_row(row, tick_index, hourly)


func _retire_orphaned_removal_jobs() -> void:
	"""Hourly: retire every BUILD Job no row links and no live non-removal project requests.

	Every linked Job is reached by the row walk; this catches the rest (a Job whose destroy was
	refused, or one restored without its project), which `_tick_one_activity()` never ticks.
	Walked from the end, because a retirement shifts only the live rows already visited. Once an
	hour, O(live Jobs), allocation-free (`live_job_at_into()`).
	"""
	var index: int = _jobs.job_count() - 1
	while index >= 0:
		if _jobs.live_job_at_into(index, _read) \
				and _demolition_work.is_orphaned_removal_job(_read.value):
			_demolition_work.retire_job(_read.value)
		index -= 1


func _reconcile_removal_row(row: int, tick_index: int, hourly: bool) -> void:
	"""One Building row: forget a gone building's state, keep an admission worked, retry an order.

	A row with no order, no Job link and no admission record -- almost every row -- costs three
	array reads and is skipped.
	"""
	if _demolition_work.is_quiet_row(row) and not _admissions.is_recorded_at(row):
		return
	var building: Vector2i = _buildings.building_ref_of_row(row)
	var ordered: Vector2i = _demolition_work.intent_building_at(row)
	if ordered != EntityDirectoryScript.NULL_REF and ordered != building:
		_demolition_work.drop_intent_at(row)
	if building == EntityDirectoryScript.NULL_REF:
		_demolition_work.retire_job_at(row)
		return
	var project: Vector2i = _admissions.project_of(building)
	if project != EntityDirectoryScript.NULL_REF:
		_reconcile_admitted(row, project, tick_index, hourly)
		return
	_demolition_work.retire_job_at(row)
	if hourly and _demolition_work.has_intent(building) and _evacuation_sources_empty(building):
		_evacuation_retry_count += 1
		request_demolition(building)


func _reconcile_admitted(row: int, project: Vector2i, tick_index: int, hourly: bool) -> void:
	"""Keep exactly one workable Job on an admitted removal; retry its commit once work is done.

	A Job the player cancelled (CANCEL_JOB cancels the Job, not the demolition), a paused
	project's Job (REQ-SET-137 releases its workers) and a Job out of step are retired; a
	workable project with no Job gets a fresh one carrying the project's own remainder.
	"""
	if not _construction.phase_into(project, _read):
		return
	if _read.value == ConstructionScript.PHASE_WORK_DONE:
		_demolition_work.retire_job_at(row)
		if hourly:
			_removal_commit_retry_count += 1
			_commit_removal(project)
		return
	if _demolition_work.linked_job_is_stale(row, project):
		_demolition_work.retire_job_at(row)
	_demolition_work.post_job(project, tick_index)


func _evacuation_sources_empty(building_ref: Vector2i) -> bool:
	"""Whether every container anchored on the building's footprint holds no lot and no claim.

	The sources' report the retry waits for. Stage 5 requires every container the gate's owner
	scan reaches to be anchored on the footprint, so this one tile scan sees a superset of the
	gate's sources, and only an empty answer is worth the full *admit*. Satchels are unplaced
	and never seen (#3d). Cold: one bounded anchor scan per waiting order per hour.
	"""
	_demolition_footprint.fill(0)
	if not _ground_piles.refund_seeds_into(building_ref, _demolition_footprint,
			_demolition_seeds, _demolition_read):
		return false
	if not _inventory.containers_anchored_in_into(_demolition_footprint, _demolition_pairs,
			_demolition_read):
		return false
	for index: int in _demolition_read.value:
		var container: Vector2i = Vector2i(_demolition_pairs[index * 2],
			_demolition_pairs[index * 2 + 1])
		if _inventory.container_lot_count(container) > 0 \
				or _inventory.container_reserved_mass_g(container) > 0:
			return false
	return true


func demolition_admissions() -> DemolitionAdmissionsScript:
	"""The coordinator's admission record and per-building destination revision (decision 0534)."""
	return _admissions


func building_definitions() -> BuildingDefinitionsScript:
	"""The immutable §4.1/§4.2/§4.3 facts the building store validates against.

	Borrowed from the store rather than composed a second time, so `base_store_g_of()` and the
	unlock ordinals a caller reads are the ones `place_building()` itself enforced.
	"""
	return _buildings.definitions()


func _report_first_refusal(code: StringName) -> void:
	"""Push the first tick refusal of a run to the log, once, so a stuck loop is not silent.

	Once, deliberately: a refusal that recurs every tick would push 30 errors a second and bury
	the failure it is reporting. The count stays exact in `refused_tick_count()`.
	"""
	if _reported_refusal:
		return
	_reported_refusal = true
	push_error("SettlementSystem: interval integration refused '%s' at resident row %d" % [
		code, _needs.last_refused_slot()])


func _refuse(code: StringName) -> bool:
	"""Record a refusal code and return false, so callers can `return _refuse(...)`."""
	_last_refusal = code
	return false

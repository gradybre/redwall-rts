extends Node
## Boot scene: wires the HUD to UIManager, generates the settlement and its starter colony, opens
## the starter stores on that colony's buildings and seeds them, and attaches the resident crowd.

const HudScript := preload("res://scripts/ui/hud.gd")
const ResidentStageScript := preload("res://scripts/presentation/resident_stage.gd")
const StarterColonyScript := preload("res://scripts/core/starter_colony.gd")

@onready var _hud: HudScript = $UI/HUD as HudScript
@onready var _resident_stage: ResidentStageScript = \
	$World/Entities/ResidentStage as ResidentStageScript


func _ready() -> void:
	"""Reset autoload state, register the HUD, seed the stores, and start play.

	EntityManager, EconomySystem and SettlementSystem are autoloads and outlive this scene, so a
	reload would otherwise inherit the previous run's entities, stores and settlement.

	EconomySystem is reset BEFORE SettlementSystem: its reset drops the borrowed residents
	binding, so the old settlement is unbound before it is cleared, never after.
	"""
	if not SettlementSystem.prepare_world_reset():
		push_error("Settlement restart refused: %s" % SettlementSystem.last_refusal())
		return
	EntityManager.clear()
	EconomySystem.reset()
	if not SettlementSystem.reset():
		push_error("Settlement reset refused: %s" % SettlementSystem.last_refusal())
		return
	if _hud == null:
		push_error("main.tscn has no HUD at UI/HUD; the interface will not update.")
	UIManager.register_hud(_hud)
	if _generate_initial_world():
		_seed_stores()
	_attach_resident_stage()
	GameManager.start_game()
	UIManager.push_alert("Mossflower stirs.")
	print("[Main] boot complete: %s  food-days %s  ready %d NP  fuel-days %s" % [
		GameManager.get_state_name(),
		EconomySystem.food_days_text(),
		EconomySystem.ready_nutrition_points(),
		EconomySystem.fuel_days_text(),
	])


func _generate_initial_world() -> bool:
	"""Run REQ-SET-009 whole: generate §5.1's world WITH its cohort, then bind the food divisor.

	ONE CALL, NOT TWO. Booting used to spawn the cohort alone, so the running game had twelve
	residents and no world -- no trees, no basins, no estuary, and an unseeded RNG. §5.1 states a
	single initialization contract and `SettlementSystem.create_generated_settlement()` is the
	single operation that satisfies it; a partial one is refused whole and leaves an empty
	settlement rather than a world with nobody in it or a cohort with nowhere to stand.

	THE SEED IS §5.1's OWN, NOT ONE CHOSEN HERE. §5.1 authors exactly one: "A fixed-seed tutorial
	uses seed 20260905", which is `WorldInit.TUTORIAL_WORLD_SEED` and the default below. A player
	seed would come from the New Settlement form, which UI §4 specifies and which does not exist;
	no substitute default is invented for it.

	The item catalog comes from EconomySystem, which has already loaded and validated it in
	`reset()` above. The generator binds its seventeen resource ids by key against that same
	registry, so the world's trees, forage and fish are the compiled catalog's items and not a
	second opinion about them.

	A refused generation unbinds the food-days divisor explicitly. Leaving an earlier run's cohort
	bound after a scene reload would divide this run's stores by the previous run's population,
	which is a wrong number on screen rather than an absent one. It also leaves the stores closed:
	they are owned by the starter colony's buildings (decision 0533), so a refused generation has
	nothing to own them, and false tells `_ready()` not to seed.
	"""
	if not SettlementSystem.create_generated_settlement(EconomySystem.definitions()):
		EconomySystem.bind_residents(null)
		push_error("Initial settlement could not be created: %s" % SettlementSystem.last_refusal())
		return false
	EconomySystem.bind_residents(SettlementSystem.residents())
	return true


func _attach_resident_stage() -> void:
	"""Bind the crowd renderer to the cohort AND to the settlement's own pose store.

	Not in the stage's own `_ready()`: Godot readies children before parents, so that runs before
	`_generate_initial_world()` above and would bind an empty settlement. A refusal is reported
	rather than swallowed, because an unbound crowd and a settlement with nobody in it draw the
	same empty ground.

	BOTH STORES COME FROM THE SETTLEMENT (INIT-POSE-R01). The renderer is handed
	`SettlementSystem.transforms()` -- the one directory-bound Transform store the generation
	transaction placed §5.1's twelve into -- rather than constructing a presentation-private one
	of its own. A generation that refused leaves nobody placed, and the crowd draws nothing.
	"""
	if _resident_stage == null:
		push_error("main.tscn has no ResidentStage at World/Entities; residents will not be drawn.")
		return
	if not _resident_stage.attach(SettlementSystem.residents(), SettlementSystem.transforms()):
		push_error("Resident crowd could not attach: %s" % _resident_stage.last_refusal())
		return
	print("[Main] resident crowd attached: mesh %s" % _resident_stage.mesh_source())


func _exit_tree() -> void:
	"""Release the HUD, the crowd and the borrowed residents binding before this scene is freed.

	The settlement itself is NOT cleared here. It is authoritative state owned by an autoload and
	this scene is one view of it; the next boot resets it before creating a new cohort.
	"""
	UIManager.unregister_hud()
	EconomySystem.bind_residents(null)
	if _resident_stage != null:
		_resident_stage.detach()


func _unhandled_input(event: InputEvent) -> void:
	"""Toggle the player pause reason on UI §5's `time_pause` action.

	UI §5 puts pause on Space with world focus (and Ctrl+Space outside text/rebind contexts).
	Escape is NOT pause: it is `ui_cancel`, which dismisses exactly one layer, falling through
	to `open_menu` once the dismissal stack is empty. The prototype bound pause to a `cancel`
	action on Escape; that was a wrong behaviour, not merely a wrong name.
	"""
	if event.is_action_pressed(&"time_pause"):
		GameManager.toggle_pause()
		get_viewport().set_input_as_handled()


func _seed_stores() -> void:
	"""Open the starter stores on the colony's buildings, then deposit GDD §5.1's inventory.

	Answer #7 / decision 0533: the pantry is owned by the hall and the material store by the four
	open stockpiles, each anchored at its origin tile, so the stores can only open after the
	colony stands. The inventory list itself is `EconomySystem.INITIAL_INVENTORY_U`, deposited in
	§5.9's fill order by `seed_initial_inventory()`.

	The stores open in the SETTLEMENT's inventory (decision 0534): EconomySystem adopts it first,
	so the demolition gate and section 7 see the starter stock. A refused adoption leaves the
	stores closed rather than opening them in a second inventory nobody else can see.
	"""
	var binding: StarterColonyScript.StoreBinding = StarterColonyScript.StoreBinding.new()
	if not SettlementSystem.starter_store_binding_into(binding):
		push_error("Starter stores have no colony to bind to: %s" % SettlementSystem.last_refusal())
		return
	if not EconomySystem.bind_inventory(SettlementSystem.inventory()) \
			or not EconomySystem.open_and_seed_starter_stores(binding):
		push_error("Starter stores could not open and seed: %s" % EconomySystem.last_refusal())
